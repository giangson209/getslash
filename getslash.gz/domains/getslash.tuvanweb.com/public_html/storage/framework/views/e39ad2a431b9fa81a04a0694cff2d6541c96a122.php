
<?php $__env->startSection('main'); ?>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Tin tức</a></li>
				</ul>
			</div>
		</div>
	</section>
	
	<section id="news" class="pb-80">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-9">
						<div class="list-news">
							<?php if(!empty($dataPostFirst)): ?>
								<div class="item-big">
									<div class="avarta">
										<a title="<?php echo e(@$dataPostFirst->name); ?>" href="<?php echo e(route('home.post.single', $dataPostFirst->slug)); ?>">
											<img data-src="<?php echo e(@$dataPostFirst->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($dataPostFirst->name); ?>">
										</a>
									</div>
									<div class="info">
										<div class="date-view">
											<ul class="list-inline">
												<li class="list-inline-item">
													<div class="date"><?php echo e(@$dataPostFirst->created_at->format('d/m/yy')); ?></div>
												</li>
												<li class="list-inline-item">
													<div class="view"><i class="fa fa-eye"></i><?php echo e(!empty($dataPostFirst->view_count) ? $dataPostFirst->view_count : 0); ?> lượt xem</div>
												</li>
											</ul>
										</div>
										<h1><a title="<?php echo e($dataPostFirst->name); ?>" href="<?php echo e(route('home.post.single', $dataPostFirst->slug)); ?>"><?php echo e($dataPostFirst->name); ?></a></h1>
										<div class="desc">
											<?php echo e(@$data[0]->desc); ?>

										</div>
									</div>
								</div>
							<?php endif; ?>
							<div class="new-small">
								<?php if(count($data)): ?>
									<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="item">
											<div class="avarta">
												<a title="<?php echo e(@$item->name); ?>" href="<?php echo e(route('home.post.single', @$item->slug)); ?>">
													<img data-src="<?php echo e(@$item->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e(@$item->name); ?>">
												</a>
											</div>
											<div class="info">
												<h3><a title="<?php echo e(@$item->name); ?>" href="<?php echo e(route('home.post.single', @$item->slug)); ?>"><?php echo e(@$item->name); ?></a></h3>
												<div class="date-view">
													<ul class="list-inline">
														<li class="list-inline-item">
															<div class="date"><?php echo e(@$item->created_at->format('d/m/yy')); ?></div>
														</li>
														<li class="list-inline-item">
															<div class="view"><i class="fa fa-eye"></i><?php echo e(!empty(@$item->view_count) ? @$item->view_count : 0); ?> lượt xem</div>
														</li>
													</ul>
												</div>
												<div class="desc">
													<?php echo e(@$item->desc); ?>

												</div>
												<div class="readmore"><a title="Xem thêm" href="<?php echo e(route('home.post.single', @$item->slug)); ?>">Xem thêm</a></div>
											</div>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								<div class="item">
									<div class="pagination">
										<ul class="list-inline text-center">
											<?php echo $data->links(); ?>

										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="side-news">
							<?php echo $__env->make('frontend.teamplate.parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/frontend/pages/archives-news.blade.php ENDPATH**/ ?>