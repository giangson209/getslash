
<?php $__env->startSection('main'); ?>
	<h1 style="display: none;"><?php echo $dataContent->title_h1; ?></h1>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Khuyến mãi</a></li>
				</ul>
			</div>
		</div>
	</section>

	<?php
		if (!empty($dataContent->content)) {
            $list_category = json_decode($dataContent->content);
        }
	?>

	<section id="product" class="pt-20">
		<div class="container">
			<div class="content">
				<div class="tab-hot-sale slide-hot">
					<ul class="tabs">
						<li class="">
							<a class="tab-prd active" href="javascript:0" data-tab="tab-1-1" >Nổi bật</a>
						</li>
						<?php if(!empty($list_category->category)): ?>
							<?php $__currentLoopData = $list_category->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $cate = \App\Models\Categories::find($value->category_id); ?>
								<li class="">
									<a class="tab-prd category-link" href="<?php echo e(route('home.flash-sale.category', $cate->slug)); ?>" data-tab="tab-2-<?php echo e($loop->index + 1); ?>" data-id="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</ul>
					<div class="tab-content">
						<div class="tab-pane pane-prd active" id="tab-1-1">
							<div class="list-product prd-list">
								<div class="row list-products-hot">
									<?php if(count($products_flash_sale)): ?>
										<?php $__currentLoopData = $products_flash_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-lg-3 col-sm-3 col-6">
												<?php $__env->startComponent('frontend.components.product-style-2', ['item'=> $item]); ?>
							    
												<?php echo $__env->renderComponent(); ?>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<div class="col-sm-12">
											<div class="alert alert-success" role="alert">
											  	Không có sản phẩm nào phù hợp.
											</div>
										</div>
									<?php endif; ?>
								</div>
								<?php if(count($products_flash_sale)): ?>
									<div class="row">
										<div class="col-md-12">
											<div class="load-more text-center pt-50 pb-50" style="background: #f9f9f9;">
												<a title="Xem Thêm" href="javascript:;" class="loadMoreHot">Xem thêm</a>
												<input type="hidden" value="20">
											</div>
										</div>
									</div>
								<?php endif; ?>
							</div>
						</div>
						<?php if(!empty($list_category->category)): ?>
							<?php $__currentLoopData = $list_category->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $cate = \App\Models\Categories::find($value->category_id); ?>
								<div class="tab-pane pane-prd" id="tab-2-<?php echo e($loop->index + 1); ?>">
									<div class="list-product prd-list">
										<div class="row list-product-category-<?php echo e($cate->id); ?>">
											
										</div>
										<div class="row">
											<div class="col-md-12">
												<div class="load-more text-center pt-50 pb-50" style="background: #f9f9f9;">
													<a title="Xem Thêm" href="javascript:;" class="loadMoreCategory" data-category="<?php echo e($cate->id); ?>">Xem thêm</a>
													<input type="hidden" value="20">
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php echo $__env->make('frontend.teamplate.parts.tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	<?php echo $__env->make('frontend.teamplate.parts.modal-emty-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script>
		jQuery(document).ready(function($) {
			$('.category-link').click(function(event) {
				var id_tab = $(this).data('id');
				var classSelected = '.list-product-category-'+id_tab;
				if(isEmpty($(classSelected))){
					getProducts(id_tab, classSelected);
				}
			});

			$('body').on('click', '.loadMoreHot', function(event) {
				var offset = parseInt($(this).next().val());
				var btn = $(this);
				$('.loadingcover').show();
				$.get('<?php echo e(route('home.load.products.ajax')); ?>', { id_category: 'hot', offset : offset } , function(data) {
					$('.loadingcover').hide();
					btn.next().val(offset + 20);
					if(data.trim() != ''){
						$('.list-products-hot').append(data);
					}else{
						btn.remove();
						$('#exampleModal').modal('show'); 
					}
				});
			});
			$('body').on('click', '.loadMoreCategory', function(event) {
				var offset = parseInt($(this).next().val());
				var id = $(this).data('category');
				var classSelected = '.list-product-category-'+id;
				var btn = $(this);
				$('.loadingcover').show();
				$.get('<?php echo e(route('home.load.products.ajax')); ?>', { id_category: id, offset : offset } , function(data) {
					$('.loadingcover').hide();
					btn.next().val(offset + 20);
					if(data.trim() != ''){
						$(classSelected).append(data);
					}else{
						btn.remove();
						$('#exampleModal').modal('show'); 
					}
				});
			});
			


		});	
		function isEmpty( el ){
		    return !$.trim(el.html())
		}

		function getProducts($id, $classSelected) {
			$('.loadingcover').show();
			$.get('<?php echo e(route('home.load.products.ajax')); ?>', { id_category : $id } ,function(data) {
				$('.loadingcover').hide();
				if(data.trim() != ''){
					$($classSelected).html(data);
				}else{
					$($classSelected).html('<div class="col-sm-12"><div class="alert alert-success" role="alert">Không có sản phẩm nào phù hợp.</div></div>');
				}
			});
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bephungphu/public_html/resources/views/frontend/pages/flash-sale.blade.php ENDPATH**/ ?>