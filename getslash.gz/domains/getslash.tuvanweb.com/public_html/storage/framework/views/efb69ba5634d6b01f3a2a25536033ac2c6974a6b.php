
<?php $__env->startSection('main'); ?>
    <section class="banner">
        <div class="slide-banner">
            <div class="item-banner">
                <div class="avarta">
                    <?php if(!empty($dataSeo) && !empty($dataSeo->banner)): ?>
                        <img src="<?php echo e($dataSeo->banner); ?>" class="img-fluid w-100" alt="">
                    <?php else: ?>
                        <img src="<?php echo e(__BASE_URL__); ?>/images/bn-blog.jpg" class="img-fluid w-100" alt="">
                    <?php endif; ?>
                </div>
                <div class="caption">
                    <div class="container">
                        <h3 class="text-uppercase "><?php echo e(!empty($category) ? $category->{ 'name_'.locale() } : (!empty($dataSeo) ? @$dataSeo->content->name : 'Blog')); ?></h3>
                        <h1>Here we share our ideas.</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="blog-cate">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="list-blog">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-blog">
                            <div class="avarta">
                                <a href="<?php echo e(route('pages.post.single', $item->slug)); ?>">
                                    <img src="<?php echo e($item->image); ?>" class="img-fluid" alt="">
                                </a>
                            </div>
                            <div class="info">
                                <div class="date-time"><?php echo e($item->created_at->format('F jS, Y')); ?></div>
                                <h3><a href="<?php echo e(route('pages.post.single', $item->slug)); ?>"><?php echo e($item->{ 'name_'.locale() }); ?></a></h3>
                                <div class="desc">
                                    <?php echo e($item->{ 'desc_'.locale() }); ?>

                                </div>
                                <div class="view-more">
                                    <a href="<?php echo e(route('pages.post.single', $item->slug)); ?>"><?php echo app('translator')->getFromJson('site.view_more'); ?>
                                        <img src="<?php echo e(__BASE_URL__); ?>/images/more.svg" class="img-fluid" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="pagination w-100">
                        <ul class="list-inline w-100 text-center">
                            <?php echo $data->links(); ?>

                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <?php echo $__env->make('frontend.pages.blog.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/frontend/pages/blog/index.blade.php ENDPATH**/ ?>