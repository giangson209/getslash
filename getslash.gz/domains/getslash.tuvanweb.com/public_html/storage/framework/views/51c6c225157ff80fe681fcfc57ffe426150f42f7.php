<?php SEO::setTitle(404); ?>

<?php $__env->startSection('main'); ?>
    <section class="error">
        <div class="container">
            <div class="content-error text-center">
                <div class="avarta-err"><img src="<?php echo e(__BASE_URL__); ?>/images/404.jpg" class="img-fluid" alt=""></div>
                <h1>Oops! Page Not Found :(</h1>
                <div class="go-home"><a href="<?php echo e(url('/')); ?>" class="text-uppercase">reload</a></div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/errors/404.blade.php ENDPATH**/ ?>