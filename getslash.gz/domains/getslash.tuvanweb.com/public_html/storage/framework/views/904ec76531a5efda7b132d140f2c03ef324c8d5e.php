<?php $id = isset($id) ? $id : (int) round(microtime(true) * 1000); ?>
<tr>
	<td class="index"><?php echo e($index); ?></td>
	<td>
		<input type="text" name="products_version[<?php echo e($id); ?>][name]" class="form-control" required="" value="<?php echo e(@$value->name); ?>">
	</td>
	<td>
		<input type="number" name="products_version[<?php echo e($id); ?>][value]" min="0" class="form-control" required="" value="<?php echo e(@$value->value); ?>">
	</td>
    <td style="text-align: center;">
        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
            <i class="fa fa-minus"></i>
        </a>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\hungphu\resources\views/backend/repeater/row-products-vesion.blade.php ENDPATH**/ ?>