<div class="item <?php echo e(@$class); ?>">
	<div class="avarta">
		<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single-project', $item->slug)); ?>">
			<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>">
		</a>
	</div>
	<div class="info">
		<h3>
			<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single-project', $item->slug)); ?>">
				<?php echo e($item->name); ?>

			</a>
		</h3>
		<ul>
			<li>
				<div class="date"><?php echo e($item->created_at->format('d/m/yy')); ?></div>
			</li>
			<li>
				<?php if(\Request::route()->getName() == 'home.category-project'): ?>
					<div class="cate"><?php echo e($info->name); ?></div>
				<?php else: ?>
					<div class="cate"><?php echo e(@$item->category()->first()->name); ?></div>
				<?php endif; ?>
			</li>
		</ul>
	</div>
</div><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/components/project.blade.php ENDPATH**/ ?>