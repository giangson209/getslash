
<?php $__env->startSection('main'); ?>
    <main class="page-wrapper bg-gray">
        <section class="news pd-60">
            <div class="container">
                <h1 class="title title-lg"><?php echo e(!empty($category) ? $category->name : 'Tin tức'); ?></h1>
                <div class="row">
                    <?php if(count($data)): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="news-item">
                                    <a href="<?php echo e($item->url); ?>" title="" class="news-image zoom">
                                        <img src="<?php echo e($item->image); ?>" alt="">
                                    </a>
                                    <div class="news-cache">
                                        <h4><a href="<?php echo e($item->url); ?>" title=""><?php echo e($item->name); ?></a> </h4>
                                        <div class="desc"><?php echo e($item->desc); ?></div>
                                        <a href="<?php echo e($item->url); ?>" title="" class="text-blue font-oswald">Xem thêm</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-sm-12">
                            <div class="alert alert-success" role="alert">
                                Nội dung đang được cập nhật.
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="pagination mgt-30">
                    <ul class="list-inline w-100 text-right">
                        <?php echo $data->links(); ?>

                    </ul>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/home-tech/resources/views/frontend/pages/blog/archive.blade.php ENDPATH**/ ?>