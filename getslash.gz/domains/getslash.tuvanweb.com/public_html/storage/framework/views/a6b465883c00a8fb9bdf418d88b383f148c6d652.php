<?php $__env->startSection('main'); ?>
	
	<section id="banner">
		<div class="slide-banner">
			<?php if(!empty($slider)): ?>
				<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<div class="avarta">
							<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>">
						</div>
						<div class="caption">
							<div class="container">
								<div class="content text-center">
									<h2 class="jose"><a href="<?php echo e($item->link); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h2>
									<p><?php echo $item->decs; ?></p>
									<div class="btn-view">
										<a href="<?php echo e($item->link); ?>" title="<?php echo e($item->name); ?>">Xem Chi tiết</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</section>

	<?php if(!empty($content->content)){
		$content = json_decode($content->content);
	} ?>
	
	<section class="box-why pt-100">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase jose"><h2><?php echo e(@$content->sec_why->title); ?></h2></div>
				<div class="list-why">
					<div class="row">
						<?php if(!empty($content->sec_why->content)): ?>
							<?php $__currentLoopData = $content->sec_why->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4 col-sm-6">
									<div class="item">
										<div class="icon">
											<img src="<?php echo e(@$value->icon); ?>" class="img-fluid" 
											alt="<?php echo e(@$value->title); ?>">
										</div>
										<div class="info">
											<h3><?php echo e(@$value->title); ?></h3>
											<p><?php echo e(@$value->desc); ?></p>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section id="box-service" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase jose"><h2><?php echo e(@$content->sec_services->title); ?></h2></div>
				<div class="list-service">
					<div class="row">

						<div class="col-md-4 col-sm-4">
							<div class="item text-center">
								<a href="<?php echo e(@$content->sec_services->service_1->link); ?>" title="<?php echo e(@$content->sec_services->service_1->title); ?>"></a>
								<div class="icon">
									<img src="<?php echo e(@$content->sec_services->service_1->icon); ?>" class="img-fluid icon-show" alt="<?php echo e(@$content->sec_services->service_1->title); ?>">
									<img src="<?php echo e(@$content->sec_services->service_1->icon_white); ?>" class="img-fluid icon-hdd" alt="<?php echo e(@$content->sec_services->service_1->title); ?>">
								</div>
								<div class="info">
									<h3><?php echo e(@$content->sec_services->service_1->title); ?></h3>
									<div class="desc">
										<?php echo e(@$content->sec_services->service_1->desc); ?>

									</div>
								</div>
							</div>
						</div>

						<div class="col-md-4 col-sm-4">
							<div class="item text-center">
								<a href="<?php echo e(@$content->sec_services->service_2->link); ?>" title="<?php echo e(@$content->sec_services->service_2->title); ?>"></a>
								<div class="icon">
									<img src="<?php echo e(@$content->sec_services->service_2->icon); ?>" class="img-fluid icon-show" alt="<?php echo e(@$content->sec_services->service_2->title); ?>">
									<img src="<?php echo e(@$content->sec_services->service_2->icon_white); ?>" class="img-fluid icon-hdd" alt="<?php echo e(@$content->sec_services->service_2->title); ?>">
								</div>
								<div class="info">
									<h3><?php echo e(@$content->sec_services->service_2->title); ?></h3>
									<div class="desc">
										<?php echo e(@$content->sec_services->service_2->desc); ?>

									</div>
								</div>
							</div>
						</div>

						<div class="col-md-4 col-sm-4">
							<div class="item text-center">
								<a href="<?php echo e(@$content->sec_services->service_3->link); ?>" title="<?php echo e(@$content->sec_services->service_3->title); ?>"></a>
								<div class="icon">
									<img src="<?php echo e(@$content->sec_services->service_3->icon); ?>" class="img-fluid icon-show" alt="<?php echo e(@$content->sec_services->service_3->title); ?>">
									<img src="<?php echo e(@$content->sec_services->service_3->icon_white); ?>" class="img-fluid icon-hdd" alt="<?php echo e(@$content->sec_services->service_3->title); ?>">
								</div>
								<div class="info">
									<h3><?php echo e(@$content->sec_services->service_3->title); ?></h3>
									<div class="desc">
										<?php echo e(@$content->sec_services->service_3->desc); ?>

									</div>
								</div>
							</div>
						</div>

						
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="feed-back" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase jose"><h2>Website tiêu biểu của khách hàng</h2></div>
				<div class="list-feedback">
					<div class="row">
						<?php if(!empty($projects)): ?>
							<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4 col-sm-4">
									<div class="item">
										<div class="avarta">
											<a href="<?php echo e($item->link); ?>" target="_blank" title="<?php echo e($item->name); ?>">
												<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" 
												alt="<?php echo e($item->name); ?>">
											</a>
										</div>
										<div class="info">
											<h3><a href="<?php echo e($item->link); ?>" 
												target="_blank" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h3>
											<div class="link-demo"><span>Link: <a href="<?php echo e($item->link); ?>" 
												target="_blank" title="<?php echo e($item->name); ?>"><?php echo e($item->link); ?></a></span></div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<div class="col-md-12">
							<div class="btn-view text-center">
								<a href="<?php echo e(route('home.projects')); ?>" title="Xem toàn bộ">Xem toàn bộ</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="box-news" class="pt-100 pb-100" style="background: #fafafa">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase jose"><h2>Tin tức nổi bật</h2></div>
				<div class="list-news">
					<div class="row">
						<?php if(!empty($postHots)): ?>
							<?php $__currentLoopData = $postHots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-3 col-sm-6">
									<div class="item">
										<div class="avarta">
											<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" 
												title="<?php echo e($item->name); ?>">
												<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>">
											</a>
										</div>
										<div class="info">
											<div class="date">
												<?php echo e($item->created_at->format('d/m/Y')); ?>

											</div>
											<h3>
												<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>">
													<?php echo e($item->name); ?>

												</a>
											</h3>
											<div class="desc">
												<?php echo e(text_limit($item->desc, 12)); ?>...
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<div class="col-md-12">
							<div class="btn-view text-center">
								<a href="<?php echo e(route('home.posts')); ?>" title="Xem thêm">Xem thêm</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="partner" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="list-partner text-center">
					<div class="row">
						<?php if($partner): ?>
							<?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-2">
									<div class="item">
										<a href="<?php echo e($item->link); ?>" target="_blank" title="<?php echo e($item->name); ?>">
											<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($item->name); ?>">
										</a>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>