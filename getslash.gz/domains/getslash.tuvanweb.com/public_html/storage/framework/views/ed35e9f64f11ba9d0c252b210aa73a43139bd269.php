<div class="item">
	<div class="avarta">
		<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>">
			<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" alt="<?php echo e($item->name); ?>">
		</a>
		<?php if($item->CheckApplyGift()): ?>
			<div class="icon-sale">
				<img data-src="<?php echo e(__BASE_URL__); ?>/images/gift.png" class="img-fluid lazyload" alt="Quà tặng"><span>Quà tặng</span>
			</div>
		<?php endif; ?>
	</div>
	<div class="info">
		<h3><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
		<div class="price">
			<?php if(!is_null($item->sale_price)): ?>
				<span><?php echo e(number_format($item->sale_price,0, '.', '.')); ?>đ</span>
				<del><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</del><label>(<?php echo e($item->sale); ?>%)</label>
			<?php else: ?>
				<span><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</span>
			<?php endif; ?>
		</div>
		<div class="desc">
			<?php echo $item->sort_desc; ?>

		</div>
		<div class="add-cart">
			<a title="Thêm vào giỏ hàng" href="<?php echo e(route('home.get-add-cart', [ 'id' => $item->id, 'qty' => 1, 'redirect' => 1 ])); ?>">Thêm vào giỏ hàng <i class="fa fa-shopping-cart"></i></a>
		</div>
	</div>
</div><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/frontend/components/product-style-3.blade.php ENDPATH**/ ?>