
<?php $__env->startSection('main'); ?>
    <main class="page-wrapper bg-white">
        <section class="payment">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="payment-left pd-60">
                            <h1 class="title title-lg">thanh toán</h1>
                            <form class="payment-form" action="<?php echo e(route('home.check-out.post')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="text" placeholder="Họ tên" name="name" class="form-control" required>
                                <input type="email" placeholder="Email" name="email" class="form-control" required>
                                <input type="text" placeholder="Số điện thoại" name="phone" class="form-control" required>
                                <input type="text" placeholder="Địa chỉ nhận hàng" name="address" class="form-control" required>
                                <div class="payment-method">
                                    <h4>Hình thức thanh toán</h4>
                                    <div class="list-method-pay">
                                        <div class="item active">
                                            <div class="title-method">
                                                <input type="radio" id="sx-1" name="radio-group" checked="">
                                                <label for="sx-1">COD ( Thanh toán khi nhận hàng )</label>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="title-method">
                                                <input type="radio" id="sx-2" name="radio-group">
                                                <label for="sx-2">Thẻ ATM nội địa / Internet Banking </label>
                                            </div>
                                            <div class="item-method-pay">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <p style="margin-bottom: 10px; font-weight: bolder; color: red">Chức năng này đang được phát triển</p>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-1" checked="" name="radio-group-pay" style="">
                                                            <label for="bank-1"><img src="<?php echo e(__BASE_URL__); ?>/images/b1.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-2" name="radio-group-pay" style="">
                                                            <label for="bank-2"><img src="<?php echo e(__BASE_URL__); ?>/images/b2.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-1" checked="" name="radio-group-pay" style="">
                                                            <label for="bank-1"><img src="<?php echo e(__BASE_URL__); ?>/images/b1.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-2" name="radio-group-pay" style="">
                                                            <label for="bank-2"><img src="<?php echo e(__BASE_URL__); ?>/images/b2.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-1" checked="" name="radio-group-pay" style="">
                                                            <label for="bank-1"><img src="<?php echo e(__BASE_URL__); ?>/images/b1.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-2" name="radio-group-pay" style="">
                                                            <label for="bank-2"><img src="<?php echo e(__BASE_URL__); ?>/images/b2.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-1" checked="" name="radio-group-pay" style="">
                                                            <label for="bank-1"><img src="<?php echo e(__BASE_URL__); ?>/images/b1.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <div class="pay">
                                                            <input type="radio" class="d-none" id="bank-2" name="radio-group-pay" style="">
                                                            <label for="bank-2"><img src="<?php echo e(__BASE_URL__); ?>/images/b2.png" class="img-fluid" alt=""></label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mgt-30"><button type="submit" class="btn-submit">Thanh toán</button> </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="payment-right pd-60">
                            <h2>đơn hàng của bạn</h2>
                            <div class="right-item">
                                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row" style="margin-bottom: 20px">
                                        <div class="col-md-4">
                                            <a href="<?php echo e(route('home.single.product', $item->options->slug)); ?>" title="" class="zoom">
                                                <img src="<?php echo e($item->options->image); ?>" alt="">
                                            </a>
                                        </div>
                                        <div class="col-md-8">
                                            <h4><a href="<?php echo e(route('home.single.product', $item->options->slug)); ?>" title=""><?php echo e($item->name); ?></a> </h4>
                                            <p>Số lượng: <?php echo e($item->qty); ?></p>
                                            <p>Giá: <?php echo e(number_format($item->price * $item->qty , 0, '.', '.')); ?> VND</p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="flex-center-between total">
                                <span>Tổng tiền:</span>
                                <span class="text-blue"><?php echo e(number_format(Cart::total(), 0, '.', '.')); ?> VND</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/home-tech/resources/views/frontend/pages/products/check-out.blade.php ENDPATH**/ ?>