<?php $__env->startSection('main'); ?>
	<section class="breadcrumbs pb-40">
		<div class="container">
			<ul class="list-inline">
				<li class="list-inline-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i><span>/</span></a></li>
				<li class="list-inline-item"><a href="<?php echo e(route('home.list.product')); ?>">Sản phẩm<span>/</span></a></li>
				<li class="list-inline-item"><a href="javascript:void(0)"><?php echo e($data->name); ?></a></li>
			</ul>
		</div>
	</section>
	<section class="news pb-100">
		<div class="container">
			<div class="row">
				<div class="col-md-9">
					<div class="preview pb-60">
						<div class="row">
							<div class="col-md-7 col-sm-6">
								<div class="slide-thumb">
									<div class="slider-for">
	                                    <div class="carousel-item">
	                                        <img class="" src="<?php echo e($data->image); ?>" class="img-fluid" width="100%" alt="Third slide">
	                                    </div>
	                                    <?php if(count($data->ProductImage()->where('type', 'more_image_product')->get())): ?>
	                                    	<?php $__currentLoopData = $data->ProductImage()->where('type', 'more_image_product')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                    		<div class="carousel-item">
			                                        <img class="" src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="Third slide">
			                                    </div>
	                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                    <?php endif; ?>
	                                </div>
	                                <div class="slider-nav">
	                                    <div class="clc">
	                                     	<div class="item"><img class="" src="<?php echo e($data->image); ?>" width="100%" alt="Third slide"></div>
	                                    </div>
	                                    <?php if(count($data->ProductImage()->where('type', 'more_image_product')->get())): ?>
	                                    	<?php $__currentLoopData = $data->ProductImage()->where('type', 'more_image_product')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                    		<div class="clc">
			                                     	<div class="item">
			                                     		<img class="" src="<?php echo e($item->image); ?>" width="100%" alt="Third slide">
			                                     	</div>
			                                    </div>
	                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                                    <?php endif; ?>
	                                </div>
								</div>
							</div>
							<div class="col-md-5 col-sm-6">
								<div class="info-preview">
									<h1 class="text-uppercase"><?php echo e($data->name); ?></h1>
									<div class="code">Mã sản phẩm: <?php echo e($data->sku); ?></div>
									<div class="price">
										<?php if(!empty($data->sale)): ?>
											<span>Giá:</span><label><?php echo e(number_format($data->sale_price,0, '.','.')); ?>đ</label> 
											<del><?php echo e(number_format($data->regular_price,0, '.','.')); ?>đ</del>
										<?php else: ?>
											<span>Giá:</span><label><?php echo e(number_format($data->regular_price,0, '.','.')); ?>đ</label>
										<?php endif; ?>
										
									</div>
									<div class="desc">
										<?php echo $data->sort_desc; ?>

									</div>
									<form action="<?php echo e(route('home.post-add-cart')); ?>" method="POST" id="addCartForm">
										<?php echo csrf_field(); ?>
										<input type="hidden" name="product_id" value="<?php echo e($data->id); ?>">
										<div class="btn-nb">
											<ul class="list-inline"> 
												<li class="list-inline-item"><span>Số lượng: </span></li>
												<li class="list-inline-item">
													<div class="quantity">
					                                    <div class="number-spinner">
					                                    	<span class="ns-btn b-up">
					                                            <a data-dir="dwn"><span class="icon-minus">-</span></a>
					                                      	</span>
					                                      	<input type="text" class="pl-ns-value" name="qty" min="1" value="1" maxlength="5" readonly>
					                                      	<span class="ns-btn">
					                                            <a data-dir="up"><span class="icon-plus">+</span></a>
					                                      	</span>
					                                    </div>
					                                </div>
												</li>
											</ul>
											<input type="hidden" name="redirect_page" value="back" id="redirect">
											<input type="hidden" name="price" value="<?php echo e(!empty($data->sale) ? $data->sale_price : $data->regular_price); ?>">
										</div>
										<div class="btn-preview">
											<ul class="text-center">
												<li><a href="javascript:;" class="add-cart">Thêm vào giỏ</a></li>
												<li><a href="javascript:;" class="buy-now">Mua ngay</a></li>
											</ul>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div class="detail" style="background: #fff;padding: 50px 25px;margin-bottom: 50px;">
						<div class="info-detail">
							<div class="desc-detail"><span>Mô tả sản phẩm</span></div>
							<?php echo $data->content; ?>

						</div>
					</div>
					<?php if(count($product_same_category)): ?>
						
						<div class="other">
							<div class="title-other">SẢN PHẨM LIÊN QUAN</div>
							<div class="slide-news-other">
								<?php $__currentLoopData = $product_same_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="item-slide">
										<div class="prd-sale">
											<div class="avarta">
												<a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
													<img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
												</a>
											</div>
											<div class="info">
												<h4><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h4>
												<div class="s-bott">
													<div class="price">
														<?php if(!empty($item->sale)): ?>
															<del><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</del>
															<p><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</p>
														<?php else: ?>
															<p><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</p>
														<?php endif; ?>
													</div>
													<?php if(!empty($item->sale)): ?>
														<div class="per-sale"><span>-<?php echo e($item->sale); ?>% <br>SALE</span></div>
													<?php endif; ?>
													
												</div>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>

					<?php endif; ?>
				</div>
				<div class="col-md-3">
					<?php $product_sale = \App\Models\Products::where('sale', '!=', 0)->take(5)->get(); ?>
					<?php if(count($product_sale)): ?>
						<div class="side-bar">
							<div class="title-bar text-center text-uppercase">Sản phẩm khuyến mãi</div>
							<div class="list-prd-sale">
								<?php $__currentLoopData = $product_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="prd-sale">
										<div class="avarta">
											<a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
												<img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
											</a>
										</div>
										<div class="info">
											<h4><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h4>
											<div class="s-bott">
												<div class="price">
													<del><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</del>
													<p><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</p>
												</div>
												<div class="per-sale"><span>-<?php echo e($item->sale); ?>% <br>SALE</span></div>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script>
		function submitForm($redirect = 'back') {
			$('#redirect').val($redirect);
			$('form#addCartForm').submit();
		}
		jQuery(document).ready(function($) {
			$('.add-cart').click(function(event) {
				submitForm('back');
			});

			$('.buy-now').click(function(event) {
				submitForm('check-out');
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/frontend/pages/products/single-product.blade.php ENDPATH**/ ?>