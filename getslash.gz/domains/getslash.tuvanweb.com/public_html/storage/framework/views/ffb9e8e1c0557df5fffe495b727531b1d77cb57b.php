 
<?php $__env->startSection('controller','Menu danh mục'); ?>
<?php $__env->startSection('controller_route', route('setting.menu-category')); ?>
<?php $__env->startSection('action','Chỉnh sửa'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="row">
					<div class="col-sm-6">
						<form action="<?php echo e(route('setting.menu-category.move.post')); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<div class="form-group">
								<label for="">Parent ID Menu cũ</label>
								<input type="text" name="parent_id_old" class="form-control">
							</div>
							<div class="form-group">
								<label for="">Loại</label>
								<select name="type" id="" class="form-control">
									<option value="category">Category</option>
									<option value="brand">Brand</option>
								</select>
							</div>
							<div class="form-group">
								<label for="">Parent ID Menu Mới</label>
								<input type="text" name="parent_id_new" class="form-control">
							</div>
							<button class="btn btn-primary">Lưu lại</button>
						</form>
					</div>
				</div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bephungphu/public_html/resources/views/backend/menu-category/move.blade.php ENDPATH**/ ?>