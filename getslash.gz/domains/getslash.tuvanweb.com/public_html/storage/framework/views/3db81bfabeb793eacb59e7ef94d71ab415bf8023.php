
<?php $__env->startSection('main'); ?>
	<section id="breadcrumbs">
		<div class="avarta">
			<img src="<?php echo e(__BASE_URL__); ?>/images/bread.png" class="img-fluid" width="100%" alt="Banner">
		</div>
		<div class="info">
			<div class="container">
				<div class="content text-center">
					<h2 class="text-uppercase">Giỏ hàng</h2>
					<ul class="list-inline">
						<li class="list-inline-item"><a href="<?php echo e(url('/')); ?>" title="Trang chủ">Trang chủ</a></li>
						<li class="list-inline-item"><a href="javascript:0">Giỏ hàng + thanh toán</a></li>
					</ul>
				</div>
			</div>
		</div>
	</section>	

	<?php if(Cart::count()): ?>

		<section id="cart" class="pt-100 pb-100">
			<div class="container">
				<div class="content max-cart">
					<div class="title-cart text-center jose">Giỏ hàng</div>
					<div class="scr-cart">
						<div class="list-cart">
							<div class="cart-title">
								<div class="cart-head jose">STT</div>
								<div class="cart-head jose">Sản phẩm</div>
								<div class="cart-head jose">Giá</div>
								<div class="cart-head jose text-center">Xóa</div>
							</div>
							<div class="content-cart">
								<?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($item->options->type == 'ssl' || $item->options->type == 'vps'): ?>
										<div class="item-cart">
											<div class="item">
												<div class="info-cart"><?php echo e($loop->index + 1); ?></div>
												<div class="info-cart">
													<?php if($item->options->type == 'vps'): ?>
														<a href="javascript:0" class="link-info">VPS <?php echo e($item->name); ?></a>	
													<?php else: ?>
														<a href="javascript:0" class="link-info"><?php echo e($item->name); ?></a>	
													<?php endif; ?>
												</div>
												<div class="info-cart">
													<div class="price">
														<span><?php echo e(number_format($item->price*$item->qty)); ?>đ</span>
													</div>
												</div>
												<div class="info-cart">
													<div class="remove text-center">
														<a href="javascript:0" class="btnRemove" data-id="<?php echo e($item->rowId); ?>">
															<img src="<?php echo e(__BASE_URL__); ?>/images/remove.png" alt="remove">
														</a>
													</div>
												</div>
											</div>
										</div>
									<?php elseif($item->options->type == 'email' || $item->options->type == 'hosting'): ?>
										<div class="item-cart">
											<div class="item">
												<div class="info-cart"><?php echo e($loop->index + 1); ?></div>
												<div class="info-cart">
													<a href="javascript:0" class="link-info"><?php echo e($item->name); ?></a>
													<div class="sub-cart sub-link" style="display: block;">
														<ul>
															<li><?php echo e($item->options->meta); ?> Tháng</li>
														</ul>
													</div>	
												</div>
												<div class="info-cart">
													<div class="price">
														<span><?php echo e(number_format($item->price*$item->qty)); ?>đ</span>
													</div>
												</div>
												<div class="info-cart">
													<div class="remove text-center">
														<a href="javascript:0" class="btnRemove" data-id="<?php echo e($item->rowId); ?>">
															<img src="<?php echo e(__BASE_URL__); ?>/images/remove.png" alt="remove">
														</a>
													</div>
												</div>
											</div>
										</div>
									<?php elseif($item->options->type == 'additional-vps' || $item->options->type == 'additional-hosting'): ?>
										<?php echo $__env->make('frontend.teamplate.cart.additional-vps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									<?php elseif($item->options->type == 'website'): ?>
										<?php echo $__env->make('frontend.teamplate.cart.website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
					<div class="btn-ctn">
						<div class="row">
							<div class="col-md-7">
								<ul class="list-inline">
									
								</ul>
							</div>
							<div class="col-md-5">
								<div class="total">Tổng: <?php echo e(number_format(Cart::total())); ?>đ</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section id="payment" class="pt-100 pb-100" style="background: #fafafa;">
			<div class="container">
				<form action="<?php echo e(route('home.check-out.post')); ?>" class="check-out" method="POST" id="check-out">
					<?php echo csrf_field(); ?>
					<?php echo $__env->make('frontend.teamplate.cart.check-out', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</form>
			</div>
		</section>

	<?php else: ?>

	<section id="cart" class="pt-100 pb-100">
		<div class="row no-item-cart">
			<div class="col-sm-4"></div>
			<div class="col-sm-4 text-center">
				<h2 class="message">Bạn chưa chọn dịch vụ nào.</h2>
				<div class="btn-view" style="margin-top: 20px">
					<a href="<?php echo e(url('/')); ?>" title="Về trang chủ" tabindex="-1">Về trang chủ</a>
				</div>
			</div>
			<div class="col-sm-4"></div>
		</div>
	</section>

	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
	<script>
		jQuery(document).ready(function($) {
			$('.btnRemove').click(function(event) {
				var link = '<?php echo e(route('home.cart.delete')); ?>?id='+$(this).attr('data-id');
				$.confirm({
					icon: 'fa fa-question-circle',
				    title: 'Xác nhận',
				    content: 'Bạn có chắc chắn muốn xóa sản phẩm này ra khỏi giỏ hàng ?',
				    buttons: {
				        cancel : {
				        	text: 'Hủy bỏ',
				        	action: function(){
				                //window.location.href = link;
				            }
				        },
				        somethingElse: {
				            text: 'Xác nhận',
				            btnClass: 'btn-blue',
				            keys: ['enter', 'shift'],
				            action: function(){
				                window.location.href = link;
				            }
				        }
				    }
				});
			});
		});
	</script>


    <script>
        jQuery(document).ready(function($) {
            $('.type').click(function(event) {
                $('#typePay').val($(this).attr("data-type"));
                console.log($('#typePay').val());
            });
            $('.idBank').click(function(event) {
                $('#id_bank').val($(this).attr("data-id"));
            });
            $('#province').change(function(event) {
                districtid = $(this).val();
                $.ajax({
                    url: '<?php echo e(route('get.province')); ?>',
                    type: 'GET',
                    data: {
                        districtid: districtid,
                        rand: (new Date()).getTime(),
                    },
                })
                .done(function(data) {
                    $('#district').html(data)
                })
            });
        });
    </script>
    <script type="text/javascript" src="<?php echo e(asset('public/vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
	<?php echo $jsValidator->selector('#check-out'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/pages/cart.blade.php ENDPATH**/ ?>