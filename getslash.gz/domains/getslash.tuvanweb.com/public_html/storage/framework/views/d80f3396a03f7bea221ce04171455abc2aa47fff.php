<?php $__env->startSection('controller','Trang'); ?>
<?php $__env->startSection('controller_route',route('pages.list')); ?>
<?php $__env->startSection('action','Danh sách'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo e(route('pages.build.post')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input name="type" value="<?php echo e($data->type); ?>" type="hidden">

	               	<div class="row">
						<div class="col-sm-12">
							<div class="form-group">
								<label for="">Trang</label>
								<input type="text" class="form-control" value="<?php echo e($data->name_page); ?>" disabled="">
				 				
								<?php if(\Route::has($data->route)): ?>
									<h5>
										<a href="<?php echo e(route($data->route)); ?>" target="_blank">
					                        <i class="fa fa-hand-o-right" aria-hidden="true"></i>
					                        Link: <?php echo e(route($data->route)); ?>

					                    </a>
									</h5>
				                <?php endif; ?>
							</div>
							
						</div>
					</div>
					<div class="nav-tabs-custom">
				        <ul class="nav nav-tabs">
				        	<li class="active">
				            	<a href="#about" data-toggle="tab" aria-expanded="true">Về chúng tôi</a>
				            </li>
				            <li class="">
				            	<a href="#histrory" data-toggle="tab" aria-expanded="true">Lịch sử phát triển</a>
				            </li>
				            <li class="">
				            	<a href="#tamnhin" data-toggle="tab" aria-expanded="true">Tầm nhìn - sứ mệnh - giá trị cốt lõi</a>
				            </li>
				            <li class="">
				            	<a href="#seo" data-toggle="tab" aria-expanded="true">Cấu hình trang</a>
				            </li>
				        </ul>
				    </div>
				    <?php if(!empty($data->content)){
				    	$content = json_decode($data->content);

				    } ?>
				    <div class="tab-content">
						
						<div class="tab-pane active" id="about">
							<div class="row">
								<div class="col-sm-2">
									<div class="form-group">
			                           <label>Hình ảnh</label>
			                           <div class="image">
			                               <div class="image__thumbnail">
			                                   <img src="<?php echo e(!empty($content->about->image) ?  $content->about->image : __IMAGE_DEFAULT__); ?>"  
			                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                   <input type="hidden" value="<?php echo e(@$content->about->image); ?>" name="content[about][image]"  />
			                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
			                               </div>
			                           </div>
			                       </div>
								</div>
								<div class="col-sm-10">
									<div class="form-group">
										<label for="">Tiêu đề</label>
										<input type="text" name="content[about][title]" value="<?php echo e(@$content->about->title); ?>" class="form-control">
									</div>
									<div class="form-group">
										<label for="">Nội dung</label>
										<textarea class="content" name="content[about][desc]"><?php echo @$content->about->desc; ?></textarea>
									</div>
								</div>
							</div>
						</div>

						<div class="tab-pane" id="histrory">
							<div class="row">
								<div class="col-sm-12">
									<div class="form-group">
										<label for="">Tiêu đề</label>
										<input type="text" name="content[history][title]" value="<?php echo e(@$content->history->title); ?>" class="form-control">
									</div>
								</div>
								
								<div class="col-sm-12">
									<div class="repeater" id="repeater">
						                <table class="table table-bordered table-hover histrory">
						                    <thead>
							                    <tr>
							                    	<th style="width: 30px;">STT</th>
							                    	<th>Nội dung</th>
							                    	<th width="20px"></th>
							                    </tr>
						                	</thead>
						                    <tbody id="sortable">
						                    	<?php if(!empty($content->history->content)): ?>
													<?php $__currentLoopData = $content->history->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													    <?php $index = $loop->index + 1 ; ?>
														<?php echo $__env->make('backend.repeater.row-histrory', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
											</tbody>
						                </table>
						                <div class="text-right">
						                    <button class="btn btn-primary" 
								            	onclick="repeater(event,this,'<?php echo e(route('get.layout')); ?>','.index', 'histrory', '.histrory')">Thêm
								            </button>
						                </div>
						            </div>
								</div>

							</div>
						</div>

						<div class="tab-pane" id="tamnhin">
							<div class="row">
								<div class="col-sm-4">
									<label for="" class="text-center text-uppercase" style="display: block;">Tầm nhìn</label>
									<div class="form-group">
										<label for="">Tiêu đề</label>
										<input type="text" name="content[vision][title]" value="<?php echo e(@$content->vision->title); ?>" class="form-control">
									</div>
									<div class="form-group">
										<label for="">Nội dung</label>
										<textarea class="content" name="content[vision][content]"><?php echo @$content->vision->content; ?></textarea>
									</div>
								</div>
								<div class="col-sm-4">
									<label for="" class="text-center text-uppercase" style="display: block;">Sứ mệnh</label>
									<div class="form-group">
										<label for="">Tiêu đề</label>
										<input type="text" name="content[mission][title]" value="<?php echo e(@$content->mission->title); ?>" class="form-control">
									</div>
									<div class="form-group">
										<label for="">Nội dung</label>
										<textarea class="content" name="content[mission][content]"><?php echo @$content->mission->content; ?></textarea>
									</div>
								</div>
								<div class="col-sm-4">
									<label for="" class="text-center text-uppercase" style="display: block;">Giá trị cốt lõi</label>
									<div class="form-group">
										<label for="">Tiêu đề</label>
										<input type="text" name="content[core_values][title]" value="<?php echo e(@$content->core_values->title); ?>" class="form-control">
									</div>
									<div class="form-group">
										<label for="">Nội dung</label>
										<textarea class="content" name="content[core_values][content]"><?php echo @$content->core_values->content; ?></textarea>
									</div>
								</div>
							</div>
						</div>

			            <div class="tab-pane" id="seo">
							<div class="row">
								<div class="col-sm-2">
									<div class="form-group">
			                           <label>Hình ảnh</label>
			                           <div class="image">
			                               <div class="image__thumbnail">
			                                   <img src="<?php echo e($data->image ?  $data->image : __IMAGE_DEFAULT__); ?>"  
			                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                   <input type="hidden" value="<?php echo e(@$data->image); ?>" name="image"  />
			                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
			                               </div>
			                           </div>
			                       </div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
			                           <label>Banner</label>
			                           <div class="image">
			                               <div class="image__thumbnail">
			                                   <img src="<?php echo e($data->banner ?  $data->banner : __IMAGE_DEFAULT__); ?>"  
			                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                   <input type="hidden" value="<?php echo e(@$data->banner); ?>" name="banner"  />
			                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
			                               </div>
			                           </div>
			                       </div>
								</div>
								<div class="col-sm-8">
									<div class="form-group">
										<label for="">Tiêu đề trang</label>
										<input type="text" name="meta_title" class="form-control" value="<?php echo e(@$data->meta_title); ?>">
									</div>
									<div class="form-group">
										<label for="">Mô tả trang</label>
										<textarea name="meta_description" 
										class="form-control" rows="5"><?php echo @$data->meta_description; ?></textarea>
									</div>
									<div class="form-group">
										<label for="">Từ khóa</label>
										<input type="text" name="meta_keyword" class="form-control" value="<?php echo @$data->meta_keyword; ?>">
									</div>
									
									<div class="form-group">
										<label for="">Tiêu đề thẻ H1 ẩn</label>
										<input type="text" name="title_h1" class="form-control" value="<?php echo @$data->title_h1; ?>">
									</div>

								</div>
							</div>
			            </div>
			           <button type="submit" class="btn btn-primary">Lưu lại</button>
			        </div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/backend/pages/layout/about.blade.php ENDPATH**/ ?>