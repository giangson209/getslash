<?php $id = isset($id) ? $id : (int) round(microtime(true) * 1000); ?>
<tr>
	<td class="index"><?php echo e($index); ?></td>
	<td>
       <div class="image">
           <div class="image__thumbnail">
               <img src="<?php echo e(!empty(@$value->icon) ? @$value->icon :  __IMAGE_DEFAULT__); ?>"  
               data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
               <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
                <i class="fa fa-times"></i></a>
               <input type="hidden" value="<?php echo e(@$value->icon); ?>" name="content[whychoose][list][<?php echo e($id); ?>][icon]"  />
               <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
           </div>
       </div>
    </td>
	<td>
        <div class="form-group">
            <label for="">Tiêu đề</label>
            <input type="text" class="form-control" name="content[whychoose][list][<?php echo e($id); ?>][title]" value="<?php echo e(@$value->title); ?>">
        </div>
        <div class="form-group">
            <label for="">Nội dung</label>
            <textarea rows="6" class="form-control" name="content[whychoose][list][<?php echo e($id); ?>][content]"><?php echo e(@$value->content); ?></textarea>
        </div>
    </td>
    <td style="text-align: center;">
        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
            <i class="fa fa-minus"></i>
        </a>
    </td>
</tr><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/backend/repeater/row-whychoose.blade.php ENDPATH**/ ?>