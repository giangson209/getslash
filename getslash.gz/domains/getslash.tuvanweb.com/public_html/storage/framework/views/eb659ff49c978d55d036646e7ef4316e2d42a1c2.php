<footer>
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="item-ft">
                        <h3>Liên kết MXH</h3>
                        <div class="social">
                            <ul>
                                <?php if(!empty($site_info->social)): ?>
                                    <?php $__currentLoopData = $site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($item->link); ?>" title=""><i class="<?php echo e($item->icon); ?>" aria-hidden="true"></i><?php echo e($item->name); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="item-ft">
                        <h3><?php echo e(@$site_info->col_footer_1->title); ?></h3>
                        <?php echo @$site_info->col_footer_1->value; ?>

                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="item-ft">
                        <h3><?php echo e(@$site_info->col_footer_2->title); ?></h3>
                        <?php echo @$site_info->col_footer_2->value; ?>

                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="item-ft">
                        <h3>Fanpage</h3>
                        <div class="fanp">
                           <?php echo @$site_info->code_facebook; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="revs text-center text-uppercase">
        <div class="container">
            <p><?php echo e(@$site_info->name_company); ?></p>
            <p><?php echo e(@$site_info->address); ?></p>
            <p><?php echo e(@$site_info->hotline); ?></p>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/frontend/teamplate/footer.blade.php ENDPATH**/ ?>