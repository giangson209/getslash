<header>
    <div class="header-menu">
        <div class="container">
            <div class="content">
                <div class="row">
                    <div class="col-md-3">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>" title="<?php echo e(@$site_info->site_title); ?>">
                                <img src="<?php echo e(@$site_info->logo); ?>" class="img-fluid" 
                                alt="<?php echo e(@$site_info->site_title); ?>">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="right">
                            <ul>
                                <?php if(!empty($listMenu)): ?>
                                    <?php $__currentLoopData = $listMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="<?php echo e($item->class); ?>">
                                            <a href="<?php echo e(url($item->url)); ?>" title="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <li><a href="<?php echo e(route('home.cart')); ?>" title="Giỏ hàng">
                                    <i class="fa fa-shopping-cart"></i><span><?php echo e(Cart::count()); ?></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
    <div class="menu-mobile d-none">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-6 col-sm-6">
                    <div class="logo"> 
                        <a title="<?php echo e(@$site_info->site_title); ?>" href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(@$site_info->logo); ?>" class="img-fluid avarta-logo" 
                            alt="<?php echo e(@$site_info->site_title); ?>">
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-6 col-sm-6">
                    <div class="right">
                        <div class="cart">
                            <a title="Giỏ hàng" href="<?php echo e(route('home.cart')); ?>"><i class="fa fa-shopping-cart"></i><span><?php echo e(Cart::count()); ?></span></a>
                        </div>
                        <div class="header">
                            <a title="" href="#menu"><i class="fa fa-bars"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav id="menu">
            <ul>
                <?php if(!empty($listMenu)): ?>
                    <?php $__currentLoopData = $listMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php echo e($item->class); ?>">
                            <a href="<?php echo e(url($item->url)); ?>" title="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header> <?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/teamplate/header.blade.php ENDPATH**/ ?>