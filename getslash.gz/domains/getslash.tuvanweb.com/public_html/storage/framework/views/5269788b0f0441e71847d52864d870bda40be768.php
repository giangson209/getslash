<?php if(count($menuCategory)): ?>
    <?php $__currentLoopData = $menuCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>">
                <img data-src="<?php echo e($item->icon); ?>" class="img-fluid lazyload" alt="<?php echo e($item->title); ?>"><?php echo e($item->title); ?>

            </a>
            <?php if(count($item->get_child_cate())): ?>
                <div class="mega-menu">
                    <div class="row">
                        <?php $category_menu = App\Models\CategoryMenu::where('parent_id', $item->id)->whereType('category')->orderBy('position', 'asc')->get(); ?>
                        <?php if(count($category_menu)): ?>
                            <div class="col-md-3">
                                <div class="item">
                                    <div class="mega-tt">Loại sản phẩm</div>
                                    <ul>
                                        <?php $__currentLoopData = $category_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <li><a title="<?php echo e($value->title); ?>" href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php $brand_menu = App\Models\CategoryMenu::where('parent_id', $item->id )->whereType('brand')->orderBy('position', 'asc')->get(); ?>
                        <?php if(count($brand_menu)): ?>
                            <div class="col-md-9">
                                <div class="item">
                                    <div class="mega-tt">Thương hiệu</div>
                                    <div class="mega-right">
                                        <ul>
                                            <?php $__currentLoopData = $brand_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a title="<?php echo e($value->title); ?>" href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </li>
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/teamplate/parts-header/category-list.blade.php ENDPATH**/ ?>