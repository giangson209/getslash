<?php if(count($data)): ?>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="item">
            <div class="avarta">
            	<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>">
            		<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" alt="<?php echo e($item->name); ?>">
            	</a>
            </div>
            <div class="info">
                <h3><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
                <div class="price">
                	<?php if(!is_null($item->sale_price)): ?>
			 			<span><?php echo e(number_format($item->sale_price,0, '.', '.')); ?>đ</span>
						<del><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</del><label>-(<?php echo e($item->sale); ?>%)</label>
					<?php else: ?>
						<span><?php echo e(number_format($item->sale_price,0, '.', '.')); ?>đ</span>
					<?php endif; ?>
                </div>
            </div>
        </div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/frontend/components/loop-search.blade.php ENDPATH**/ ?>