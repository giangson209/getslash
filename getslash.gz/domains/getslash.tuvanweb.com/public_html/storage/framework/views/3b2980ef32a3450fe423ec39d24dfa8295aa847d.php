
<?php $__env->startSection('controller', 'Danh mục tin tức' ); ?>
<?php $__env->startSection('controller_route', route('categories-post.index')); ?>
<?php $__env->startSection('action', 'Danh sách'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
        	<div class="col-sm-5">
	        	<form action="<?php echo updateOrStoreRouteRender( @$module['action'], $module['module'], @$data); ?>" method="POST">
	        		<?php echo csrf_field(); ?>
					<?php if(isUpdate(@$module['action'])): ?>
				        <?php echo e(method_field('put')); ?>

				    <?php endif; ?>
	        		<div class="nav-tabs-custom">
		                <ul class="nav nav-tabs">
		                    <li class="active">
		                        <a href="#activity" data-toggle="tab" aria-expanded="true">Danh mục</a>
		                    </li>
		                    <li class="">
		                    	<a href="#setting" data-toggle="tab" aria-expanded="true">Cấu hình seo</a>
		                    </li>
		                </ul>
		                <div class="tab-content">
		                    <div class="tab-pane active" id="activity">
								<div class="form-group">
									<label for="">Tên danh mục Tiếng Việt</label>
									<input type="text" class="form-control" name="name_vi" id="name" value="<?php echo e(old('name_vi')); ?>">
								</div>
								<div class="form-group">
									<label for="">Tên danh mục Tiếng Anh</label>
									<input type="text" class="form-control" name="name_en" value="<?php echo e(old('name_en')); ?>">
								</div>
								<div class="form-group">
									<label for="">Đường dẫn tĩnh</label>
									<input type="text" class="form-control" name="slug" id="slug" value="<?php echo e(old('slug')); ?>">
								</div>
		                    </div>
		                    <div class="tab-pane" id="setting">
		                    	<div class="row">
		                    		<div class="col-sm-12">
		                    			<div class="form-group">
		                    				<label for="">Hình ảnh</label>
		                    				 <div class="image">
					                            <div class="image__thumbnail">
					                                <img src="<?php echo e(__IMAGE_DEFAULT__); ?>"
					                                     data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                <input type="hidden" value="<?php echo e(old('image')); ?>" name="image"/>
					                                <div class="image__button" onclick="fileSelect(this)">
					                                	<i class="fa fa-upload"></i>
					                                    Upload
					                                </div>
					                            </div>
					                        </div>
		                    			</div>
		                    		</div>
		                    		<div class="col-sm-12">
		                    			 <div class="form-group">
				                            <label>Title SEO</label>
				                            <input type="text" class="form-control" name="meta_title" value="<?php echo old('meta_title'); ?>">
				                        </div>

				                        <div class="form-group">
				                            <label>Meta Description</label>
				                            <textarea name="meta_description" id="" class="form-control" rows="5"><?php echo old('meta_description'); ?></textarea>
				                        </div>

				                        <div class="form-group">
				                            <label>Meta Keyword</label>
				                            <input type="text" class="form-control" name="meta_keyword" value="<?php echo old('meta_keyword'); ?>">
				                        </div>
		                    		</div>
		                    	</div>
		                    </div>
		                    <button type="submit" class="btn btn-primary">Lưu lại</button>
		                </div>
		            </div>
	        	</form>
	        </div>
	        <div class="col-sm-7">
	        	<div class="box box-primary">
	                <div class="box-body">
	                    <table id="example1" class="table table-bordered table-striped table-hover">
	                        <thead>
	                            <tr>
	                                <th style="width: 15px"><input type="checkbox" name="chkAll" id="chkAll"></th>
	                                <th style="width: 15px">STT</th>
	                                <th>Tiêu đề</th>
	                                <th>Đường dẫn</th>
	                                <th style="width: 150px">Thao tác</th>
	                            </tr>
	                        </thead>
	                        <tbody>
	                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <tr>
	                                    <td><input type="checkbox" name="chkItem[]" value="<?php echo e($item->id); ?>"></td>
	                                    <td><?php echo e($loop->index + 1); ?></td>
	                                    <td><?php echo e($item->name_vi); ?></td>
	                                    <td><?php echo e($item->slug); ?></td>
	                                    <td>
	                                    	<a href="<?php echo e(url('category/'.$item->slug)); ?>" target="_blank">
	                                    		<i class="fa fa-eye" aria-hidden="true"></i> Xem
	                                    	</a>&nbsp; &nbsp; &nbsp;
	                                        <a href="<?php echo e(route('categories-post.edit', ['id' => $item->id])); ?>" title="Sửa">
	                                            <i class="fa fa-pencil fa-fw"></i> Sửa
	                                        </a> &nbsp; &nbsp; &nbsp;
	                                        <a href="javascript:;" class="btn-destroy" data-href="<?php echo e(route('categories-post.destroy', $item->id)); ?>"
				                            data-toggle="modal" data-target="#confim">
				                            <i class="fa fa-trash-o fa-fw"></i> Xóa</a>
	                                    </td>
	                                </tr>
	                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        </tbody>
	                    </table>
	                </div>
	            </div>
	        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/backend/categories-post/create-list.blade.php ENDPATH**/ ?>