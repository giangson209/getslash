<section id="showroom" class="pt-80" style="background: #fff;">
	<div class="container">
		<div class="content">
			<div class="title text-center"><h2 class="text-uppercase">Các chi nhánh</h2></div>
			<div class="list-showroom">
				<div class="slide-showroom text-center">
					<?php if(count($branchs)): ?>
						<?php $__currentLoopData = $branchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item item-room" data-tab="room-<?php echo e($loop->index + 1); ?>">	
								<div class="avarta">
									<a title="<?php echo e($item->name); ?>" href="javascript:0">
										<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($item->name); ?>">
									</a>
								</div>
								<div class="info">
									<h4><a title="<?php echo e($item->name); ?>" href="javascript:0"><?php echo e($item->name); ?></a></h4>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
			<div class="maps">
				<div class="content-maps">
					<?php if(count($branchs)): ?>
						<?php $__currentLoopData = $branchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item <?php echo e($loop->index == 0 ? 'current' : null); ?>" id="room-<?php echo e($loop->index + 1); ?>">
								<?php echo $item->iframe; ?>

								<div class="info-maps">
									<div class="avar"><img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" alt="<?php echo e($item->name); ?>"></div>
									<div class="company">
										<h5><?php echo e($item->name); ?></h5>
										<ul>
											<li>Địa chỉ: <?php echo e($item->address); ?></li>
											<?php if(!empty($item->phone)): ?>
												<li>Hotline: <?php echo e($item->phone); ?></li>
											<?php endif; ?>
											
											<?php if(!empty($item->email)): ?>
												<li>Email: <?php echo e($item->email); ?></li>
											<?php endif; ?>
											
										</ul>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section><?php /**PATH /home/bephungphu/public_html/resources/views/frontend/teamplate/parts/showroom.blade.php ENDPATH**/ ?>