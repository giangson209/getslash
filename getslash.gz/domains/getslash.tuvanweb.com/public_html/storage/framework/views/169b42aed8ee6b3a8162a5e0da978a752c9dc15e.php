<footer>
    <section class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="ft-col-1 footer-company">
                        <div class="ft-logo">
                            <a href="<?php echo e(url('/')); ?>" title=""><img src="<?php echo e(@$site_info->logo_footer); ?>" alt=""> </a>
                        </div>
                        <p class="info-company"><?php echo e(@$site_info->desc_sort); ?></p>
                        <ul class="address-company">
                            <li><a href="#" title="">Địa chỉ: <?php echo e(@$site_info->address); ?></a> </li>
                            <li><a href="" title="">Số điện thoại: <?php echo e(@$site_info->hotline); ?> </a> </li>
                            <li><a href="" title="">Email: <?php echo e(@$site_info->email); ?></a> </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="ft-col-2">
                        <h4 class="footer-title"><?php echo e(@$site_info->col_footer_1->title); ?></h4>
                        <?php echo @$site_info->col_footer_1->value; ?>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="ft-col-2">
                        <h4 class="footer-title"><?php echo e(@$site_info->col_footer_2->title); ?></h4>
                        <?php echo @$site_info->col_footer_2->value; ?>

                    </div>
                </div>
                <div class="col-md-2">
                    <div class="ft-col-2">
                        <h4 class="footer-title">Fanpage</h4>
                        <?php echo @$site_info->code_facebook; ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="copyright">
        <div class="container">
            <div class="flex-center-between footer-bottom">
                <p class="copyright-text">© GCO GROUP 2017. All rights reserved</p>
                <div class="follow-us flex-center">
                    <p class="follow-title">Theo dõi chúng tôi: </p>
                    <div class="ft-social flex-center">
                        <?php if(!empty($site_info->social)): ?>
                            <?php $__currentLoopData = $site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <a href="<?php echo e($item->link); ?>" title=""><i class="<?php echo e($item->icon); ?>" aria-hidden="true"></i></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</footer><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/teamplate/footer.blade.php ENDPATH**/ ?>