<?php $id = isset($id) ? $id : (int) round(microtime(true) * 1000); ?>
<tr>
	<td class="index"><?php echo e($index); ?></td>
	<td>
		<input type="text" class="form-control" name="content[meta][<?php echo e($id); ?>][title]">
	</td>
	<td>
		<input type="text" class="form-control" name="content[meta][<?php echo e($id); ?>][value]">
	</td>
	<td style="text-align: center;">
        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
            <i class="fa fa-minus"></i>
        </a>
    </td>
</tr><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/backend/repeater/row-services-meta.blade.php ENDPATH**/ ?>