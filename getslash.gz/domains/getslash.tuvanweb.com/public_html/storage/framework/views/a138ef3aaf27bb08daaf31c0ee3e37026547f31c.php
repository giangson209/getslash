
<?php $__env->startSection('main'); ?>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="<?php echo e($category->name); ?>" href="<?php echo e(route('home.archive.product', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
					<li class="list-inline-item"><a title="<?php echo e($brand->name); ?>" href="javascript:0"><?php echo e($brand->name); ?></a></li>
				</ul>
				<div class="avar-bread">
					<div class="avarta">
						<img data-src="<?php echo e(!empty($brand->banner) ? $brand->banner : __BASE_URL__.'/images/thuonghieu.jpg'); ?>" class="img-fluid lazyload" alt="<?php echo e($brand->name); ?>">
					</div>
					<div class="caption text-center">
						<h1><?php echo e($brand->name); ?></h1>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section id="product" class="pb-80">
		<div class="container">
			<div class="content">
				<div class="tab-hot-sale slide-th">
					<div class="grid-tabs">
						<div class="row">
							<div class="col-md-2">
								<div class="grid text-center">
									<div class="item-grid"><a title="" href="javascript:0" class="clc-gird active"><i class="fa fa-th"></i></a></div>
									<div class="item-grid"><a title="" href="javascript:0" class="clc-list"><i class="fa fa-bars"></i></a></div>
								</div>
							</div>
							<div class="col-md-10" style="padding-left: 0;">
								<ul class="tabs" style="border: 0;">

									<?php if(count($list_id_children_id)): ?>
										<li class="">
											<a class="tab-prd active" href="javascript:0" data-tab="tab-1-1" ><?php echo e($category->name); ?></a>
										</li>
										<?php $__currentLoopData = $list_id_children_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php $category_child = \App\Models\Categories::find($cate); ?>
											<li class="">
												<a class="tab-prd" 
													href="<?php echo e(route('home.products.category.brand', ['category' => $category_child->slug, 'brand' => $brand->slug ])); ?>"><?php echo e($category_child->name); ?>

												</a>
											</li>	
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>
					<div class="tab-content">
						<div class="tab-pane pane-prd active" id="tab-1-1">
							<div class="list-product prd-list">
								<div class="row list-product-hot-style-1">
									<?php if(count($products)): ?>
										<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-lg-3 col-6 col-sm-3">
												<?php $__env->startComponent('frontend.components.product-style-2', ['item'=> $item]); ?>
							    
												<?php echo $__env->renderComponent(); ?>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<div class="col-sm-12">
											<div class="alert alert-success" role="alert">
											  	Không có sản phẩm nào phù hợp.
											</div>
										</div>
									<?php endif; ?>
								</div>
							</div>
							<div class="grid-prd list-product-hot-style-2">
								<?php if(count($products)): ?>
									<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php $__env->startComponent('frontend.components.product-style-3', ['item'=> $item]); ?>
							    
										<?php echo $__env->renderComponent(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<div class="item">
										<div class="alert alert-success" style="width: 100%;" role="alert">
										  	Không có sản phẩm nào phù hợp.
										</div>
									</div>
								<?php endif; ?>
							</div>
							<div class="load-more text-center pt-50" style="background: #f9f9f9;">
								<a title="Xem thêm" href="javascript:;" class="loadMoreCategory" data-id="<?php echo e($category->id); ?>">Xem thêm</a>
								<input type="hidden" value="12">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php echo $__env->make('frontend.teamplate.parts.modal-emty-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
		jQuery(document).ready(function($) {

			$('.loadMoreCategory').click(function(event) {
				brand_id = '<?php echo e($brand->id); ?>';
				var offset = parseInt($(this).next().val());
				btn = $(this);
				category = $(this).data('id');
				$('.loadingcover').show();
				$.get('<?php echo e(route('home.load.products.brand.ajax')); ?>', { offset : offset, brand_id : brand_id, category : category } ,function(data) {
					$('.loadingcover').hide();
					btn.next().val(offset + 12);
					if(data.style_1 != '' && data.style_2 != ''){
						$('.list-product-category-style-1-'+category).append(data.style_1);
						$('.list-product-category-style-2-'+category).append(data.style_2);
					}else{
						$('#exampleModal').modal('show');
						btn.remove();
					}
				});
			});

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bephungphu/public_html/resources/views/frontend/pages/product-brand-category.blade.php ENDPATH**/ ?>