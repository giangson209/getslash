<?php $id = isset($id) ? $id : (int) round(microtime(true) * 1000); ?>
<tr>
    <td class="index"><?php echo e($index); ?></td>
    <td>
        <div class="form-group">
           <div class="image">
               <div class="image__thumbnail">
                   <img src="<?php echo e(!empty($value->icon) ?  $value->icon : __IMAGE_DEFAULT__); ?>"  
                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
                    <i class="fa fa-times"></i></a>
                   <input type="hidden" value="<?php echo e(@$value->icon); ?>" name="content[khoi2_list][<?php echo e($id); ?>][icon]"  />
                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
               </div>
           </div>
       </div>
    </td>
    <td>
        <div class="form-group">
            <label for="">Title</label>
            <input type="text" class="form-control" name="content[khoi2_list][<?php echo e($id); ?>][title]" value="<?php echo e(@$value->title); ?>">
        </div>
        <div class="form-group">
            <label for="">Content</label>
            <textarea name="content[khoi2_list][<?php echo e($id); ?>][content]" id="contentRP<?php echo e($id); ?>" cols="30" rows="10"><?php echo @$value->content; ?></textarea>
        </div>

    </td>
    <td>
        <div class="form-group">
            <label for="">Nút</label>
            <input type="text" class="form-control" name="content[khoi2_list][<?php echo e($id); ?>][nut]" value="<?php echo e(@$value->nut); ?>">
        </div>
        <div class="form-group">
            <label for="">Link</label>
            <input type="text" class="form-control" name="content[khoi2_list][<?php echo e($id); ?>][link]" value="<?php echo e(@$value->link); ?>">
        </div>
    </td>
    <td style="text-align: center;">
        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
            <i class="fa fa-minus"></i>
        </a>
    </td>
</tr>
<script>
    CKEDITOR.replace( 'contentRP<?php echo e($id); ?>' );
</script><?php /**PATH /home/slash/domains/getslash.tuvanweb.com/public_html/resources/views/backend/repeater/row-khoi2.blade.php ENDPATH**/ ?>