<ul>
	<?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $indexLoop = $loop->index + 2; ?>
		<?php if(!empty($filter->content)){
			$content = json_decode( $filter->content );
		} ?>
		<li>
			<?php if($filter->type == 'price'): ?>
				<select name="" class="select-filter-mobile" data-type="<?php echo e($filter->type); ?>">
					<option value=""><?php echo e($filter->name); ?></option>
					<?php if(!empty($content->filter)): ?>
						<?php $__currentLoopData = $content->filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e(@$value->min_value.'-'.$value->max_value); ?>"><?php echo e($value->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</select>
			<?php elseif($filter->type == 'brand'): ?>
				<select name="" class="select-filter-mobile" data-type="<?php echo e($filter->type); ?>">
					<option value=""><?php echo e($filter->name); ?></option>
					<?php if(!empty($content->filter)): ?>
						<?php $__currentLoopData = $content->filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e(@$value->brand_id); ?>"><?php echo e($value->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</select>
			<?php else: ?>
				<select name="" class="select-filter-mobile" data-type="<?php echo e($filter->type); ?>">
					<option value=""><?php echo e($filter->name); ?></option>
					<?php if(!empty($content->filter)): ?>
						<?php $__currentLoopData = $content->filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e(@$value->value); ?>"><?php echo e($value->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</select>
			<?php endif; ?>
		</li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu2/resources/views/frontend/pages/products/parts/filters-mobile.blade.php ENDPATH**/ ?>