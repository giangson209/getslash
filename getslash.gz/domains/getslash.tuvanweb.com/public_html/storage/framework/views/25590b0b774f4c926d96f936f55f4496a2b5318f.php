
<?php $__env->startSection('main'); ?>
	<h1 style="display: none;"><?php echo e(@$data->title_h1); ?></h1>
	<?php echo $__env->make('frontend.teamplate.breadcrumbs', [ 
		'config' => [
			'banner' => @$data->banner,
			'title' => 'Liên hệ'
		] 
	], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php if(!empty($data->content)){
		$content = json_decode($data->content);
	} ?>
	<section id="contact" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="info-contact">
					<div class="row">
						<div class="col-md-5">
							<div class="left">
								<h4 class="jose"><?php echo e(@$content->info->title); ?></h4>
								<ul>
									<li><i class="fa fa-map-marker"></i><?php echo e(@$content->info->address); ?></li>
									<li><i class="fa fa-phone"></i><?php echo e(@$content->info->phone); ?></li>
									<li><i class="fa fa-envelope"></i><?php echo e(@$content->info->email); ?></li>
								</ul>
							</div>
						</div>
						<div class="col-md-7">
							<div class="right">
								<h3 class="jose">LIÊN HỆ VỚI CHÚNG TÔI</h3>
								<div class="form-contact">
									<form action="<?php echo e(route('home.contact.post')); ?>" method="POST" id="contact-form">
										<?php echo csrf_field(); ?>
										<div class="row">
											<?php if(Session::has('flash_message')): ?>
				                                <div class="col-sm-12">
				                                    <div class="item" style="margin-bottom: 15px">
				                                        <div class="alert alert-success alert-dismissible">
				                                            <h4><i class="icon fa fa-ban"></i> Thông báo</h4>
				                                            <?php echo e(Session::get('flash_message')); ?>

				                                        </div>
				                                    </div>
				                                </div>
				                            <?php endif; ?>

				                            <?php if(count($errors) > 0): ?>
				                                <div class="col-sm-12">
				                                    <div class="item" style="margin-bottom: 15px">
				                                        <div class="alert alert-danger alert-dismissible">
				                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				                                            <h4><i class="icon fa fa-ban"></i> Thông báo</h4>
				                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                                                <li><?php echo $error; ?></li>
				                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                                        </div>
				                                    </div>
				                                </div>
				                            <?php endif; ?>

				                            
											<div class="col-md-12">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Họ & tên" name="name" value="<?php echo e(old('name')); ?>">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct1.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct2.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Số điện thoại" name="phone" value="<?php echo e(old('phone')); ?>">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct3.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Địa chỉ" name="address" value="<?php echo e(old('address')); ?>">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct4.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
													<div class="item">
														<textarea name="content" placeholder="Nội dung" cols="30" rows="10"><?php echo e(old('content')); ?></textarea>
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct5.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="item" style="margin-bottom: 0;">
													<input type="submit" class="btn-submit" value="GỬI LIÊN HỆ">
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="maps">
				<?php echo @$site_info->google_maps; ?>

			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript" src="<?php echo e(asset('public/vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
	<?php echo $jsValidator->selector('#contact-form'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/pages/contact.blade.php ENDPATH**/ ?>