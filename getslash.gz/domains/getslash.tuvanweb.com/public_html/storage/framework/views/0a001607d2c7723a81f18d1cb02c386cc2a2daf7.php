<?php $data_image_reviews = $data->ProductImage()->where('type', 'image_reviews_customer')->take(4)->get(); ?>
<?php if(count($data_image_reviews)): ?>
	<div class="box-gall">
		<div class="title-gall"><?php echo e(count($data->ProductImage()->where('type', 'image_reviews_customer')->get())); ?> ảnh từ khách hàng</div>
		<div class="list-gall">
			<div class="row">
				
				<?php $__currentLoopData = $data_image_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-2">
						<div class="item">
							<a title="<?php echo e($data->name); ?>" href="<?php echo e($item->image); ?>" data-fancybox="group-gall" class="lightbox"> 
								<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($data->name); ?>" width="100%" height="186">
							</a>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php $data_image_reviews_more = $data->ProductImage()->where('type', 'image_reviews_customer')->skip(4)->take(50)->get();?>
				<?php if(count($data_image_reviews_more)): ?>
					<div class="col-md-2">
						<div class="item">
							<?php $__currentLoopData = $data_image_reviews_more; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($loop->index == 0): ?>
									<a title="" href="<?php echo e($item->image); ?>" data-fancybox="group-gall" class ="view-gall lightbox text-center">Xem thêm <?php echo e(count($data_image_reviews_more)); ?> ảnh</a>
									<a title="" href="<?php echo e($item->image); ?>" data-fancybox="group-gall" class =" text-center">
										<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($data->name); ?>">
									</a>
								<?php else: ?>
									<a title="" href="<?php echo e($item->image); ?>" data-fancybox="group-gall" class ="lightbox text-center d-none">
									<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($data->name); ?>"></a>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/pages/products/parts/images-reviews-customers.blade.php ENDPATH**/ ?>