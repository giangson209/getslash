<section class="contact">
    <div class="container">
        <div class="title">
            <h4 class="text-uppercase wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s"><?php echo app('translator')->getFromJson('site.contact'); ?></h4>
            <h2 class=" wow fadeInUp wHighlight" data-aos-duration=".45" data-wow-delay=".45s"><?php echo app('translator')->getFromJson('site.get_more_detail'); ?></h2>
        </div>
        <div class="content-contact">
            <div class="row">
                <div class="col-md-6">
                    <div class="txt-contact">
                        <ul>
                            <li class=" wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                                <div class="icon"><img src="<?php echo e(__BASE_URL__); ?>/images/ctn-1.svg" class="img-fluid"
                                                       alt=""></div>
                                <div class="i-icon">
                                    <label><?php echo app('translator')->getFromJson('site.phone'); ?></label>
                                    <p><a href="tel:<?php echo @$site_info->hotline; ?>" title=""><?php echo @$site_info->hotline; ?></a></p>
                                </div>
                            </li>
                            <li class=" wow fadeInUp wHighlight" data-aos-duration=".45" data-wow-delay=".45s">
                                <div class="icon"><img src="<?php echo e(__BASE_URL__); ?>/images/ctn-2.svg" class="img-fluid"
                                                       alt=""></div>
                                <div class="i-icon">
                                    <label>email</label>
                                    <p><a href=""><?php echo @$site_info->email; ?></a></p>
                                </div>
                            </li>
                            <li class=" wow fadeInUp wHighlight" data-aos-duration=".65" data-wow-delay=".65s">
                                <div class="icon"><img src="<?php echo e(__BASE_URL__); ?>/images/ctn-3.svg" class="img-fluid"
                                                       alt=""></div>
                                <div class="i-icon">
                                    <label><?php echo app('translator')->getFromJson('site.address'); ?></label>
                                    <p>
                                        <?php echo @$site_info->{ 'address_'.locale() }; ?>

                                    </p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <form action="<?php echo e(route('pages.contact.post')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-ctn">
                            <div class="item-form">
                                <div class="row">
                                    <div class="col-md-6 wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                                        <input type="text" name="name" class="inp-text" placeholder="<?php echo app('translator')->getFromJson('site.name'); ?>" required>
                                    </div>
                                    <div class="col-md-6 wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                                        <input type="text" name="phone" class="inp-text" placeholder="<?php echo app('translator')->getFromJson('site.phone'); ?>" required>
                                    </div>
                                    <div class="col-md-12 wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                                        <input type="text" name="email" class="inp-text" placeholder="Email" required>
                                    </div>
                                    <div class="col-md-12 wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                                        <textarea name="content" id="" cols="30" rows="10" placeholder="Message (optional)"></textarea>
                                    </div>
                                    <div class="col-md-12 text-right wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                                        <input type="submit" class="inp-btn" value="SEND">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal modal-contact" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="content-popup">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <div class="desc">
                            <h3><?php echo app('translator')->getFromJson('site.form_contact_title_1'); ?></h3>
                            <p><?php echo app('translator')->getFromJson('site.form_contact_title_2'); ?></p>
                            <div class="btn-close"><a href="javascript:void(0)" data-dismiss="modal">CLOSE</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php if(session()->has('modal_show')): ?>
    <script>
        jQuery(document).ready(function($) {
            $('#myModal').modal('show');
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\slash\resources\views/frontend/pages/contact/form.blade.php ENDPATH**/ ?>