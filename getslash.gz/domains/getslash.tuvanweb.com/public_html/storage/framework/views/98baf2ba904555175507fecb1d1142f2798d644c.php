<div class="title-bar-news">Tin tức mới nhất</div>
<?php $list_news_sidebar = \App\Models\Posts::active()->where('type', 'blog')->order()->take(5)->get(); ?>
<div class="list-new-bar">
	<?php if(count($list_news_sidebar)): ?>
		<?php $__currentLoopData = $list_news_sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="item">
				<div class="avarta">
					<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>">
						<img data-src="<?php echo e(@$item->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($item->name); ?>">
					</a>
				</div>
				<div class="info">
					<h4><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>"><?php echo e($item->name); ?></a></h4>
					<div class="date"><?php echo e($item->created_at->format('d/m/yy')); ?></div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\hungphu\resources\views/frontend/teamplate/parts/sidebar.blade.php ENDPATH**/ ?>