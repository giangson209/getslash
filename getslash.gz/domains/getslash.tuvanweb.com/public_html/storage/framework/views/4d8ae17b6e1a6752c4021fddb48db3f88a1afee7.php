<?php $id = isset($id) ? $id : (int) round(microtime(true) * 1000); ?>
<tr>
    <td class="index"><?php echo e($index); ?></td>
    <td>
        <div class="form-group">
            <label for="">Title</label>
            <input type="text" class="form-control" name="content[main_content][<?php echo e($id); ?>][title]" value="<?php echo e(@$value->title); ?>">
        </div>
        <div class="form-group">
            <label for="">Sub Title</label>
            <input type="text" class="form-control" name="content[main_content][<?php echo e($id); ?>][sub_title]" value="<?php echo e(@$value->sub_title); ?>">
        </div>

        <div class="form-group">
            <label for="">Content</label>
            <textarea name="content[main_content][<?php echo e($id); ?>][content]" id="contentRP<?php echo e($id); ?>" cols="30" rows="10"><?php echo @$value->content; ?></textarea>
        </div>

    </td>
    <td style="text-align: center;">
        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
            <i class="fa fa-minus"></i>
        </a>
    </td>
</tr>
<script>
    CKEDITOR.replace( 'contentRP<?php echo e($id); ?>' );
</script><?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/backend/repeater/row-about_content_main.blade.php ENDPATH**/ ?>