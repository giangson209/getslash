<?php if(!empty($dataSeo->content)): ?>
	<?php $filter = json_decode( $dataSeo->content ); ?>
<?php endif; ?>
<?php if(count($filters)): ?>
	<div class="rmv-filter"> 
		<ul class="list-inline" id="filter-properties">
			<li class="list-inline-item"><span>Lọc:</span></li>
		</ul>
	</div>
	<?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $indexLoop = $loop->index + 2; ?>
		<?php if(!empty($filter->content)){
			$content = json_decode( $filter->content );
		} ?>
		<div class="box-filt">
			<div class="title-filt"><?php echo e($filter->name); ?></div>
			<ul class="<?php echo e($filter->type == 'brand' ? 'flex-logo' : null); ?>">
				<?php if(!empty($content->filter)): ?>
					<?php $__currentLoopData = $content->filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($filter->type == 'price'): ?>
							<li>
								<input type="radio" id="filter-<?php echo e($key); ?>" name="filter-<?php echo e($indexLoop); ?>" value="<?php echo e($value->min_value.'-'.$value->max_value); ?>" data-type="<?php echo e($filter->type); ?>"
						 		class="filter-check-box check-box-filter <?php echo e($filter->type); ?>" data-id="input-<?php echo e($filter->type); ?>" data-name="<?php echo e($value->name); ?>">
						 		<label for="filter-<?php echo e($key); ?>"><?php echo e($value->name); ?> </label>
						 	</li>
						<?php elseif($filter->type == 'brand'): ?>
							<?php $brand = \App\Models\Categories::find($value->brand_id); ?>
							<li class="filter-logo">
								<input type="checkbox" id="filter-<?php echo e($key); ?>" name="filter-<?php echo e($indexLoop); ?>" value="<?php echo e($value->brand_id); ?>" data-type="<?php echo e($filter->type); ?>"
							 	class="filter-check-box check-box-filter <?php echo e($filter->type); ?>" data-id="input-<?php echo e($filter->type); ?>" data-name="<?php echo e($value->name); ?>">
							 	<label for="filter-<?php echo e($key); ?>">
							 		<?php if(!empty($brand)): ?>
							 			<img src="<?php echo e($brand->image); ?>" class="img-fluid" alt="<?php echo e($value->name); ?> ">
							 		<?php else: ?>
							 			<?php echo e($value->name); ?> 
							 		<?php endif; ?>
							 	</label>
							</li>
						<?php else: ?>
							<li>
								<input type="checkbox" id="filter-<?php echo e($key); ?>" name="filter-<?php echo e($indexLoop); ?>" value="<?php echo e($value->value); ?>" data-type="<?php echo e($filter->type); ?>"
							 	class="filter-check-box check-box-filter <?php echo e($filter->type); ?>" data-id="input-<?php echo e($filter->type); ?>" data-name="<?php echo e($value->name); ?>">
							 	<label for="filter-<?php echo e($key); ?>"><?php echo e($value->name); ?> </label>
							</li>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</ul>
			<input type="hidden" id="input-<?php echo e($filter->type); ?>" value="" class="input-param" data-type="<?php echo e($filter->type); ?>">
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<input type="hidden" value="product-page" id="category_base"><?php /**PATH /home/bephungphu/public_html/resources/views/frontend/pages/products/parts/filters-page-product.blade.php ENDPATH**/ ?>