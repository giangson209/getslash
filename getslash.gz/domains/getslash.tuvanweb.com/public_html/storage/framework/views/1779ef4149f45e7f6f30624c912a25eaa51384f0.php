<footer>
	<div class="container">
		<div class="content">
			<div class="info-footer">
				<div class="row">
					<div class="col-md-4">
						<div class="left">
							<div class="logo">
								 <a title="<?php echo e(@$site_info->site_title); ?>" href="<?php echo e(url('/')); ?>">
		                            <img src="<?php echo e(@$site_info->footer_logo); ?>" class="img-fluid" alt="<?php echo e(@$site_info->site_title); ?>">
		                        </a>
							</div>
							<h2><?php echo e(@$site_info->name_company); ?></h2>
							<ul>
								<li><i class="fa fa-map-marker"></i>Địa chỉ: <?php echo e(@$site_info->address); ?></li>
								<li><i class="fa fa-envelope"></i>Email:  <?php echo e(@$site_info->email); ?></li>
								<li><i class="fa fa-phone"></i>Hotline:   <?php echo e(@$site_info->hotline); ?></li>
								<li><i class="fa fa-internet-explorer"></i>Website:   <?php echo e(@$site_info->website); ?></li>
							</ul>
						</div>
					</div>
					<div class="col-md-8">
						<div class="right">
							<div class="row">
								<div class="col-md-4">
									<div class="item">
										<div class="title-ft">danh mục</div>
										<div class="menu-ft">
											<ul>
												<?php if(!empty($menuFooter)): ?>
													<?php $__currentLoopData = $menuFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php if($item->parent_id == null): ?>
															<li><a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a></li>
														<?php endif; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
											</ul>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-sm-6">
									<div class="item">
										<div class="title-ft">liên kết mxh</div>
										<div class="social">
											<ul>
												 <?php if(!empty(@$site_info->social)): ?>
				                                    <?php $__currentLoopData = @$site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                                        <li class="">
				                                            <a title="<?php echo e($value->name); ?>" href="<?php echo e($value->link); ?>" target="_blank">
				                                                <i class="<?php echo e($value->icon); ?>"></i> <?php echo e($value->name); ?>

				                                            </a>
				                                        </li>
				                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                                <?php endif; ?>
											</ul>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-sm-6">
									<div class="item">
										<div class="title-ft">google map</div>
										<div class="maps-ft">
											<?php echo @$site_info->google_maps; ?>

										</div>
									</div>
								</div>

								<div class="col-md-12">
									<div class="ct text-center"><?php echo @$site_info->copyright; ?></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/teamplate/footer.blade.php ENDPATH**/ ?>