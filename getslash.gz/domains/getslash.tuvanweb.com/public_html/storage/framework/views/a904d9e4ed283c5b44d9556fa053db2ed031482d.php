
<?php $__env->startSection('main'); ?>
	<section class="breadcrumbs pb-40">
        <div class="container">
            <ul class="list-inline">
                <li class="list-inline-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i><span>/</span></a></li>
                <li class="list-inline-item"><a href="javascript:void(0)">Tìm kiếm từ khóa: <?php echo e(request('key')); ?></a></li>
            </ul>
        </div>
    </section>

     <section class="producrt pb-60">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="list-product">
                        <div class="prd-top">
                            <h1>Kết quả tìm kiếm từ khóa : <?php echo e(request('key')); ?></h1>
                            <div class="sort" style="visibility: hidden;">
                                <ul class="list-inline">
                                    <li class="list-inline-item"><span>Sắp xếp: </span></li>
                                    <li class="list-inline-item">
                                        <select id="sort">
                                            <option value="desc" <?php echo e(request('sort') == null || request('sort') == 'desc' ? 'selected' : null); ?>>Mới nhất</option>
                                            <option value="asc" <?php echo e(request('sort') == 'asc' ? 'selected' : null); ?>>Cũ nhất</option>
                                        </select>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <?php if(count($data)): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-4 col-6">
                                        <div class="prd-sale">
                                            <div class="avarta">
                                                <a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
                                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h4>
                                                <div class="s-bott">
                                                    <div class="price">
                                                        <?php if(!empty($item->sale)): ?>
                                                            <del><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</del>
                                                            <p><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</p>
                                                        <?php else: ?>
                                                            <p><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if(!empty($item->sale)): ?>
                                                        <div class="per-sale"><span>-<?php echo e($item->sale); ?>% <br>SALE</span></div>
                                                    <?php endif; ?>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="col-sm-12">
                                    <div class="alert alert-primary" role="alert">
                                        Không tìm thấy sản phẩm phù hợp.
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                        </div>
                        <div class="pagination w-100">
                            <ul class="list-inline w-100 text-center">
                                <?php echo $data->appends(request()->all())->links(); ?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/vongtay/resources/views/frontend/pages/products/search.blade.php ENDPATH**/ ?>