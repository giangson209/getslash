
<?php $__env->startSection('main'); ?>
	<?php if(!empty($dataContent->content)){
		$content = json_decode( $dataContent->content );
	} ?>
	<section id="banner" class="pb-50">
		<h1 class="d-none"><?php echo e(@$dataContent->title_h1); ?></h1>
		<div class="container">
			<div class="content-banner">
				<div class="col-padd empty"></div>
				<div class="col-padd slide-banner">
					<div class="slide">
						<?php if(!empty($content->banner)): ?>
							<?php $__currentLoopData = $content->banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item">
									<a title="<?php echo e($value->desc); ?>" href="<?php echo e($value->link); ?>">
										<img data-src="<?php echo e($value->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($value->desc); ?>">
									</a>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
				<div class="col-padd right">
					<ul class="slide-vert">
						<?php if(!empty($content->banner)): ?>
							<?php $__currentLoopData = $content->banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>
									<a title="<?php echo e($value->desc); ?>" href="javascript:0">
										<img src="<?php echo e($value->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($value->image); ?>">
									</a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section id="category-mobile" class="pb-50">
		<div class="container">
			<ul>
				<?php $categoryMobile = \App\Models\Categories::where('type', 'product_category')->where('parent_id', 0)->get(); ?>
				<?php if(count($categoryMobile)): ?>
					<?php $__currentLoopData = $categoryMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<li>
							<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.archive.product', $item->slug)); ?>">
								<?php echo e($item->name); ?>

							</a>
						</li>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>
			</ul>
			<div class="load-more-cate text-center"><a href="javascript:void(0)">Xem thêm</a></div>
		</div>
	</section>
	<section id="hot-sales">
		<div class="container">
			<div class="content">
				<div class="title text-center"><h2 class="text-uppercase">Sản phẩm giá sốc</h2></div>
				<div class="list-product slide-sale">
					<?php if(!empty($products_price_shock)): ?>
						<?php $__currentLoopData = $products_price_shock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__env->startComponent('frontend.components.product', ['item'=> $item]); ?>
						    
							<?php echo $__env->renderComponent(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					
				</div>
			</div>
		</div>
	</section>



	<section id="sale-today" class="pt-80">
		<div class="container">
			<div class="content">
				<div class="title text-center"><h2 class="text-uppercase">khuyến mãi hot mỗi ngày</h2></div>
				<div class="tab-hot-sale slide-hot">
					<ul class="tabs">
						<li class="">
							<a class="tab-sle active" href="javascript:0" data-tab="tab-1" >Nổi bật</a>
						</li>
						<?php if(!empty($content->list_category_hot)): ?>
							<?php $category_hot = \App\Models\Categories::whereIn('id', @$content->list_category_hot)->get(); ?>
							<?php $__currentLoopData = $category_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="">
									<a class="tab-sle category-hot" href="javascript:0" data-tab="tab-cate-<?php echo e($cate->id); ?>" data-id="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						<?php endif; ?>
					</ul>
					<div class="tab-content">
						<div class="tab-pane pane-sale active" id="tab-1">
							<div class="list-product">
								<div class="row">
									<?php if(count($products_sale_hot)): ?>
										<?php $__currentLoopData = $products_sale_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-lg-2 col-6 col-sm-3">
												<?php $__env->startComponent('frontend.components.product', ['item'=> $item]); ?>
												<?php echo $__env->renderComponent(); ?>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<?php if(!empty($category_hot)): ?>
							<?php $__currentLoopData = $category_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
								<div class="tab-pane pane-sale" id="tab-cate-<?php echo e($cate->id); ?>">
									<div class="list-product">
										<div class="row list-append-products-category-<?php echo e($cate->id); ?>">
											
										</div>
									</div>
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section id="product" class="pt-80">
		<div class="container">
			<div class="content">
				<div class="title"><h2 class="text-uppercase">Danh sách sản phẩm</h2></div>
				<div class="tab-hot-sale slide-hot">
					<ul class="tabs">
						<li class="">
							<a class="tab-prd active" href="javascript:0" data-tab="tab-11-1" >Nổi bật</a>
						</li>
						<?php if(!empty($content->list_category)): ?>
							<?php $category_list = \App\Models\Categories::whereIn('id', @$content->list_category)->get(); ?>
							<?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="">
									<a class="tab-prd category-link" href="javascript:0" data-tab="tab-list-cate-<?php echo e($cate->id); ?>" data-id="<?php echo e($cate->id); ?>"><?php echo e($cate->name); ?></a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</ul>
					<div class="tab-content">
						<div class="tab-pane pane-prd active" id="tab-11-1">
							<div class="list-product">
								<div class="row">
									<?php if(count($products_hot)): ?>
										<?php $__currentLoopData = $products_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-lg-2 col-6 col-sm-3">
												<?php $__env->startComponent('frontend.components.product', ['item'=> $item]); ?>
												<?php echo $__env->renderComponent(); ?>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
									<div class="col-md-12">
										<div class="load-more text-center" style="background: #f9f9f9;">
											<a title="Xem thêm" href="<?php echo e(route('home.list.product')); ?>">Xem thêm</a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php if(!empty($category_list)): ?>
							<?php $__currentLoopData = $category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

								<div class="tab-pane pane-prd" id="tab-list-cate-<?php echo e($cate->id); ?>">
									<div class="list-product">
										<div class="row list-append-products-list-category-<?php echo e($cate->id); ?>">
											
										</div>
									</div>
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php endif; ?>

					</div>
				</div>
			</div>
		</div>
	</section>


	<section id="banner-sale" class="pt-80">
		<div class="container">
			<div class="content">
				<div class="slide-bn-sale">
					<?php if(!empty($content->banner_mid)): ?>
						<?php $__currentLoopData = $content->banner_mid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<div class="avarta">
									<a title="<?php echo e($value->desc); ?>" href="<?php echo e($value->link); ?>">
										<img data-src="<?php echo e($value->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($value->image); ?>">
									</a>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>

	<?php if(session('product_viewed')): ?>
		<?php $products_viewed = \App\Models\Products::whereIn('id', session('product_viewed'))->get(); ?>
		<?php if(count($products_viewed)): ?>
			<section id="prd-seen" class="pt-80 pb-80">
				<div class="container">
					<div class="content">
						<div class="title text-center"><h2 class="text-uppercase">Sản phẩm đã xem</h2></div>
						<div class="list-product slide-seen">
							<?php $__currentLoopData = $products_viewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item">
									<div class="avarta">
										<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>">
											<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($item->name); ?>">
										</a>
									</div>
									<div class="info">
										<h3><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</section>
		<?php endif; ?>
	<?php endif; ?>


	<section id="partner" class="pb-80" style="<?php echo e(session('product_viewed') ? '' : 'padding-top:80px'); ?>">
		<div class="container">
			<div class="content">
				<div class="slide-part">
					<?php if(!empty($content->partner)): ?>
						<?php $__currentLoopData = $content->partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<a title="<?php echo e($value->desc); ?>" href="<?php echo e($value->link); ?>" target="_blank">
									<img data-src="<?php echo e($value->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($value->desc); ?>">
								</a>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>


	<section id="box-news" class="pt-80 pb-80" style="background: #fafafa">
		<div class="container">
			<div class="content">
				<div class="title text-center"><h2 class="text-uppercase">Kinh nghiệm hay</h2></div>
				<div class="list-box-news">
					<div class="row">
						<div class="col-md-6">
							<div class="video-news">
								<div class="avarta"><img data-src="<?php echo e(@$content->video->image); ?>" class="img-fluid lazyload" alt="Video"></div>
								<div class="play text-center">
									<a title="" href="javascript:0" data-toggle="modal" data-target="#myModal">
										<img data-src="<?php echo e(__BASE_URL__); ?>/images/play.png" class="img-fluid lazyload" alt="play">
									</a>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="right">
								<div class="news-item">
									<?php if(count($posts_hot)): ?>
										<?php $__currentLoopData = $posts_hot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="item">
												<div class="avarta">
													<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>">
														<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e($item->name); ?>">
													</a>
												</div>
												<div class="info">
													<h4><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>"><?php echo e($item->name); ?></a></h4>
													<div class="desc">
														<?php echo e($item->desc); ?>

													</div>
												</div>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="load-more text-center">
								<a title="Xem thêm" href="<?php echo e(route('home.archive-news')); ?>">Xem thêm</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="myModal">
			<div class="modal-dialog">
			    <div class="modal-content">
			    	<div class="modal-header">
			        	<button type="button" class="close" data-dismiss="modal">&times;</button>
			    	</div>
			    	<div class="modal-body">
			        	<div class="content-popup">
			        		<?php echo @$content->video->iframe; ?>

			        	</div>
			    	</div>
			    </div>
			</div>
		</div>
	</section>

	<?php echo $__env->make('frontend.teamplate.parts.tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
		jQuery(document).ready(function($) {
			$('.category-hot').click(function(event) {
				var id_tab = $(this).data('id');
				if(isEmpty($('.list-append-products-category-'+id_tab))){
					$('.loadingcover').show();
					$.get('<?php echo e(route('home.load.products.ajax')); ?>', { id_category : id_tab, type : 'home-hot'  } , function(data) {
						$('.loadingcover').hide();
						if(data.trim() != ''){
							$('.list-append-products-category-'+id_tab).html(data);
						}else{
							$('.list-append-products-category-'+id_tab).html('<div class="col-sm-12"><div class="alert alert-success" role="alert">Không có sản phẩm nào phù hợp.</div></div>');
						}
					});
				}
			});

			$('.category-link').click(function(event) {
				var id_tab = $(this).data('id');
				if(isEmpty($('.list-append-products-list-category-'+id_tab))){
					$('.loadingcover').show();
					$.get('<?php echo e(route('home.load.products.ajax')); ?>', { id_category : id_tab, type : 'home-category'  } , function(data) {
						$('.loadingcover').hide();
						if(data.trim() != ''){
							$('.list-append-products-list-category-'+id_tab).html(data);
						}else{
							$('.list-append-products-list-category-'+id_tab).html('<div class="col-sm-12"><div class="alert alert-success" role="alert">Không có sản phẩm nào phù hợp.</div></div>');
						}
					});
				}
			});

		});

		function isEmpty( el ){
		    return !$.trim(el.html())
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/frontend/pages/home.blade.php ENDPATH**/ ?>