<div class="item">
	<div class="avarta">
		<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single-project', $item->slug)); ?>">
			<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>"></a>
		</div>
	<div class="info text-center">
		<div class="info-srv">
			<h2 class="text-uppercase">Dự án</h2>
			<h3 class="text-uppercase"><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single-project', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
			<div class="btn-read"><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single-project', $item->slug)); ?>"><i class="fa fa-angle-right"></i></a></div>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\hungphu\resources\views/frontend/components/project-style-2.blade.php ENDPATH**/ ?>