
<?php $__env->startSection('main'); ?>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0"><?php echo e($data->name); ?></a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="about">
		<div class="container">
			<div class="content">
				<div class="detail">
					<div class="title-about text-center text-uppercase"><h1><?php echo e($data->name); ?></h1></div>
					<div class="info-detail">
						<?php echo $data->content; ?>

					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu2/resources/views/frontend/pages/pages-combo.blade.php ENDPATH**/ ?>