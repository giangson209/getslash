<?php $__env->startSection('main'); ?>
	<section id="banner">
		<div class="slide-banner">
			<?php if(!empty($slider)): ?>
				<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<a title="<?php echo e($item->name); ?>" href="<?php echo e($item->link); ?>">
							<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->title); ?>">
						</a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</section>

	<?php if(!empty($contentHome)){
		$content = json_decode($contentHome->content);
	} ?>
 
	<section id="box-about" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="info-about">
					<div class="row">
						<div class="col-md-5">
							<div class="video-left">
								<div class="avarta">
									<img src="<?php echo e(@$content->whychoose->image); ?>" class="img-fluid" width="100%" 
									alt="<?php echo e(@$content->whychoose->title); ?>">
								</div>
								<div class="btn-play">
									<a title="" href="javascript:0" data-toggle="modal" data-target="#myModal">
										<img src="<?php echo e(__BASE_URL__); ?>/images/play.png" class="img-fluid" alt="<?php echo e(@$content->whychoose->title); ?>">
									</a>
								</div>
							</div>
						</div>
						<div class="col-md-7">
							<div class="right">
								<h1><?php echo e(@$content->whychoose->title); ?></h1>
								<div class="desc">
									<p><?php echo @$content->whychoose->desc; ?></p>
								</div>
								<div class="list-icon-ab">
									<div class="row">
										<?php if(!empty($content->whychoose->list)): ?>
											<?php $__currentLoopData = $content->whychoose->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="col-md-6 col-sm-6">
													<div class="item text-center">
														<div class="icon">
															<img src="<?php echo e(@$value->icon); ?>" class="img-fluid" alt="<?php echo e(@$value->title); ?>">
														</div>
														<div class="info">
															<h3><?php echo e(@$value->title); ?></h3>
															<p><?php echo e(@$value->content); ?></p>
														</div>
													</div>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="myModal">
		  <div class="modal-dialog">
		    <div class="modal-content">
		    	<div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal">&times;</button>
			    </div>
		      <div class="modal-body">
		        <div class="popup-video">
		        	<?php echo @$content->whychoose->iframe; ?>

		        </div>
		      </div>
		    </div>
		  </div>
		</div>
	</section>
	
	<section id="highlight">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase">
					<h2><?php echo e(@$content->indicators->title); ?></h2>
					<div class="line"></div>
				</div>
				<div class="desc-title">
					<p><?php echo @$content->indicators->desc; ?></p>
				</div>
				<div class="list-hight">
					<div class="row">
						<?php if(!empty($content->indicators->list)): ?>
							<?php $__currentLoopData = $content->indicators->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-3 col-6 col-sm-3">
									<div class="item text-center">
										<div class="icon">
											<img src="<?php echo e(@$value->image); ?>" class="img-fluid" alt="<?php echo e(@$content->indicators->title); ?>">
										</div>
										<div class="info">
											<div class="number"><span><?php echo @$value->number; ?></span></div>
											<p><?php echo @$value->content; ?></p>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="box-service" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase">
					<h2>Dự án nổi bật</h2>
					<div class="line"></div>
				</div>
			</div>
		</div>
		<div class="tab-service">
			<ul class="nav nav-tabs" role="tablist">
				<li class="">
					<a class="active" data-toggle="tab" href="#tabs-1" role="tab">All</a>
				</li>
				<?php if(!empty($categories)): ?>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="">
							<a class="" data-toggle="tab" href="#tabs-<?php echo e($loop->index + 2); ?>" role="tab"><?php echo e($item->name); ?></a>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>

			</ul>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="tabs-1" role="tabpanel">
				<div class="list-srv slide-srv">
					<?php if(!empty($projects_all)): ?>
						<?php $__currentLoopData = $projects_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__env->startComponent('frontend.components.project-style-2', ['item' => $value]); ?> <?php echo $__env->renderComponent(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
			
			<?php if(!empty($categories)): ?>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="tab-pane " id="tabs-<?php echo e($loop->index + 2); ?>" role="tabpanel">
						<div class="list-srv slide-srv">
							<?php $projects = $item->Projects()->where('status', 1)->orderBy('created_at', 'DESC')->paginate(6); ?>
							<?php if(!empty($projects)): ?>
								<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php $__env->startComponent('frontend.components.project-style-2', ['item' => $value]); ?> <?php echo $__env->renderComponent(); ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
			
		</div>
	</section>

	<section id="box-news" class="pb-100">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase">
					<h2>Tin tức nổi bật</h2>
					<div class="line"></div>
				</div>
				<div class="list-news slide-new">
					<div class="row">
						<?php if(count($postHots)): ?>
							<?php $__currentLoopData = $postHots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-3">
									<?php $__env->startComponent('frontend.components.post', ['item' => $item]); ?> <?php echo $__env->renderComponent(); ?>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="feedback">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase">
					<h2><?php echo e(@$content->reviews->title); ?></h2>
					<div class="line"></div>
				</div>
				<div class="slide-feed">
					<?php if(!empty($content->reviews->list)): ?>
						<?php $__currentLoopData = $content->reviews->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<div class="avarta">
									<img src="<?php echo e($value->image); ?>" class="img-fluid" alt="<?php echo e($value->name); ?>">
								</div>
								<div class="info">
									<div class="desc"><?php echo e($value->content); ?></div>
									<h4><?php echo e($value->name); ?></h4>
									<h5><?php echo e($value->position); ?></h5>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
	
	<section id="partner" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase">
					<h2>Khách hàng của chúng tôi</h2>
					<div class="line"></div>
				</div>
				<div class="slide-part text-center">
					<?php if(!empty($partner)): ?>
						<?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<a title="<?php echo e($item->name); ?>" href="<?php echo e($item->link); ?>" target="_blank">
									<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($item->name); ?>">
								</a>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>