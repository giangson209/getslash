<?php if(!empty($data->content)){
	$content = json_decode( $data->content );
} ?>
<?php $__env->startSection('main'); ?>
	<section class="banner-home">
        <div class="banner-slider">
        	<?php if(!empty($content->banner)): ?>
        		<?php $__currentLoopData = $content->banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        		<div class="item">
	        			<a href="<?php echo e($value->link); ?>" title="<?php echo e($value->name); ?>">
	        				<img data-src="<?php echo e($value->banner); ?>" alt="<?php echo e($value->name); ?>" class="lazyload">
	        			</a>
	        		</div>
	        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	<?php endif; ?>
        	
        </div>
	</section>
	<section class="service-us">
		<div class="container">
			<ul class="service-list text-center flex-center">
				<?php if(!empty($content->tieuchi)): ?>
					<?php $__currentLoopData = $content->tieuchi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<span class="service-icon"><img data-src="<?php echo e($value->icon); ?>" class="lazyload" alt="<?php echo e($value->title_1); ?>"></span>
							<span class="service-name"><?php echo e($value->title_1); ?></span>
							<span class="service-detail"><?php echo e($value->title_2); ?></span>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				<?php endif; ?>
			</ul>
		</div>
	</section>


	<section class="product-deal">
        <div class="container">
            <div class="title-index">
                <div class="row no-gutters">
                    <div class="col-md-12"><span>Sản phẩm khuyến mãi</span></div>
                </div>
            </div>
            <div class="product-slider products-slider">
            	<?php $product_sale = \App\Models\Products::active()->orderBy('order', 'ASC')->where('sale', '!=', 0)->take(8)->get(); ?>
            	<?php $__currentLoopData = $product_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<div class="product-item text-center">
		                <div class="product-photo">
		                    <a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom">
                            	<img data-src="<?php echo e($item->image); ?>" class="lazyload" alt="<?php echo e($item->name); ?>">
                            </a>
		                    <span class="discount">-<?php echo e($item->sale); ?>%</span>
		                </div>
		                <h3 class="product-name"><a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a> </h2>
		                <div class="price-wrapper">
		                    <?php if(!empty($item->sale_price)): ?>
                        		<span class="old-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                        		<span class="special-price"><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</span>
                            <?php else: ?>
								<span class="special-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                        	<?php endif; ?>
		                </div>
		                <div class="product-action">
		                    <a class="product-view" href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>">Chi tiết</a>
		                </div>
		            </div>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

	<?php $list_cate = \App\Models\CategoryHome::all(); ?>
	
	<?php $__currentLoopData = $list_cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			$category = \App\Models\Categories::find($cate->id_category)
		?>
		<?php if(!empty($category)): ?>
		
			<?php
				$list_id_children   = get_list_ids($category);
		        $list_id_children[] = $category->id;
		        $list_id_product    = \App\Models\ProductCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_product')->toArray();
		        $list_product_by_cate = \App\Models\Products::active()->whereIn('id', $list_id_product)->take(8)->get();
			?>
			<section class="product-list-index">
		        <div class="container">
		            <div class="title-index">
		                <div class="row no-gutters">
		                    <div class="col-md-3"><a href="<?php echo e(route('home.archive.product', $category->slug)); ?>" title="<?php echo e($cate->title); ?>"><?php echo e($cate->title); ?></a></div>
		                    <div class="col-md-9">
		                        <ul class="flex-center-end">
		                        	<?php
		                        		if(!empty($cate->links)){
		                        			$links = json_decode( $cate->links );
		                        		}
		                        	?>
		                        	<?php if(!empty($links->links)): ?>
		                        		<?php $__currentLoopData = $links->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<li><a href="<?php echo e($value->link); ?>" title="<?php echo e($value->title); ?>"><?php echo e($value->title); ?></a></li>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        	<?php endif; ?>
		                            <li><a href="<?php echo e(route('home.archive.product', $category->slug)); ?>" title="Xem tất cả">Xem tất cả <i class="fa fa-angle-right"></i> </a> </li>
		                        </ul>
		                    </div>
		                </div>
		            </div>
		            <div class="row no-mr product-items">
						
						<?php if(count($list_product_by_cate)): ?>
							<?php $__currentLoopData = $list_product_by_cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-3 no-pd">
				                    <div class="product-item text-center">
				                        <div class="product-photo">
				                            <a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom">
				                            	<img data-src="<?php echo e($item->image); ?>" class="lazyload" alt="<?php echo e($item->name); ?>">
				                            </a>
				                        </div>
				                        <h3 class="product-name"><a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a> </h2>
				                        <div class="price-wrapper">
				                            <?php if(!empty($item->sale_price)): ?>
				                        		<span class="old-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
				                        		<span class="special-price"><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</span>
				                            <?php else: ?>
												<span class="special-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
				                        	<?php endif; ?>
				                        </div>
				                        <div class="product-action">
				                            <a class="product-view" href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>">Chi tiết</a>
				                        </div>
				                    </div>
				                </div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
		            </div>
		            <div class="text-center mgt-30">
		            	<a href="<?php echo e(route('home.archive.product', $category->slug)); ?>" title="Xem tất cả sản phẩm" class="view-all inflex-center-center">Xem tất cả sản phẩm</a>
		            </div>
		        </div>
		    </section>

			<?php if(!empty($cate->banner)): ?>
				<section class="banner-ad pd-60">
			        <div class="container">
			            <a href="<?php echo e(route('home.archive.product', $category->slug)); ?>" title=""><img data-src="<?php echo e($cate->banner); ?>" class="lazyload" alt="<?php echo e($cate->title); ?>"> </a>
			        </div>
			    </section>
			<?php endif; ?>


		<?php endif; ?>
	    
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

	<section class="news-index pd-60">
        <div class="container">
            <p class="title-lg">tin tức nổi bật</p>
            <?php $list_post = \App\Models\Posts::where('status', 1)->where('hot', 1)->orderBy('created_at')->take(3)->get(); ?>
            <div class="row">
            	<?php $__currentLoopData = $list_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<div class="col-md-4 col-sm-4">
            			<?php echo $__env->make('frontend.components.content-news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            		</div>
            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mgt-30"><a href="<?php echo e(url('tin-tuc')); ?>" title="" class="view-all inflex-center-center">Xem thêm</a> </div>
        </div>
    </section>

    <section class="customer pd-60">
        <div class="container">
            <p class="title-lg">Cảm nhận của khách hàng</p>
            <div class="customer-slider">
            	<?php if(!empty($content->camnhan)): ?>
					<?php $__currentLoopData = $content->camnhan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="item">
		                    <div class="customer-item">
		                        <div class="idea"><?php echo e($value->desc); ?></div>
		                        <div class="customer-info">
		                            <div class="image"><img data-src="<?php echo e($value->image); ?>" class="lazyload" alt="<?php echo e($value->name); ?>"> </div>
		                            <div class="customer-name">
		                                <?php echo e($value->name); ?> <span>- <?php echo e($value->job); ?></span>
		                            </div>
		                        </div>
		                    </div>
		                </div>
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	<?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>