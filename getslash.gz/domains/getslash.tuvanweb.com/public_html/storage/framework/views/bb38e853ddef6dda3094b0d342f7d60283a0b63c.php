<?php $__env->startSection('main'); ?>
	<section class="breadrumbs">
        <div class="container">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home" aria-hidden="true"></i></a></li>
                <li class="breadcrumb-item active" aria-current="page">Sản phẩm</li>
              </ol>
            </nav>
        </div>
    </section>
    <section class="banner-product">
        <div class="container">
            <div class="banner-img">
                <img src="<?php echo e(!empty($category->banner) ? $category->banner : __BASE_URL__.'/images/bn-product.png'); ?>" alt="<?php echo e($category->name); ?>">
            </div>
        </div>
    </section>
    <section class="product-list">
        <div class="container">
            <div class="block-top flex-center-between">
                <h1 class="product-title"><?php echo e($category->name); ?></h1>
                <?php echo $__env->make('frontend.pages.products.path.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="row no-mr product-items">
            	<?php if(count($data)): ?>
            		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            			<div class="col-md-3 no-pd">
		                    <div class="product-item text-center">
		                        <div class="product-photo">
		                            <a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom">
		                            	<img data-src="<?php echo e($item->image); ?>" class="lazyload" alt="<?php echo e($item->name); ?>">
		                            </a>
		                        </div>
		                        <h3 class="product-name">
		                        	<a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom"><?php echo e($item->name); ?></a>
		                        </h3>
		                        <div class="price-wrapper">
		                            <?php if(!empty($item->sale_price)): ?>
                                		<span class="old-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                                		<span class="special-price"><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</span>
                                    <?php else: ?>
										<span class="special-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                                	<?php endif; ?>
		                        </div>
		                        <div class="product-action">
		                            <a class="product-view" href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="Chi tiết">Chi tiết</a>
		                        </div>
		                    </div>
		                </div>
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	<?php endif; ?>
			</div>
        </div>
    </section>
    <section class="paginations">
        <nav aria-label="Page navigation example">
          	<ul class="pagination justify-content-center">
            	<?php echo $data->links(); ?>

          	</ul>
        </nav>
    </section>
    <section class="about-product">
        <div class="container">
            <?php echo $category->desc; ?>

            <div class="fb-comment">
                <div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-numposts="5" data-width="100%"></div>
            </div>
            <div id="fb-root"></div>
			<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v7.0&appId=1620283888101801&autoLogAppEvents=1" nonce="8R0O8rk6"></script>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/pages/products/archive.blade.php ENDPATH**/ ?>