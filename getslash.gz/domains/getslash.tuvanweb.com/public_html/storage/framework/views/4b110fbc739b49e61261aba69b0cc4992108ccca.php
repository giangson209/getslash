
<?php $__env->startSection('main'); ?>
<main>
    <section class="box-form">
        <div class="container">
            <div class="content-form">
                <div class="row">
                    <div class="col-md-6">
                        <div class="heading">
                            <p><?php echo e(@$contentPage->khoi1->title); ?></p>
                            <h2><?php echo e(@$contentPage->khoi1->title_sub); ?></h2>
                        </div>
                        <div class="form-field">
                            <form action="<?php echo e(route('pages.contact.post')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="item-field">
                                <label><?php echo e(@$contentPage->field->name); ?> <span style="color: #fc3462;">*</span></label>
                                <input type="text" placeholder="<?php echo e(@$contentPage->field->placeholder_name); ?>" name="name" required class="txt_field" value="<?php echo old('name'); ?>"/>
                                <input type="hidden" name="type" value="Contact">
                            </div>
                            <div class="item-field">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label><?php echo e(@$contentPage->field->email); ?> <span style="color: #fc3462;">*</span></label>
                                        <input type="email" placeholder="<?php echo e(@$contentPage->field->placeholder_email); ?>" name="email" class="txt_field" required value="<?php echo old('email'); ?>"/>
                                    </div>
                                    <div class="col-md-6">
                                        <label><?php echo e(@$contentPage->field->phone); ?> <span style="color: #fc3462;">*</span></label>
                                        <input type="text" placeholder="<?php echo e(@$contentPage->field->placeholder_phone); ?>" name="phone" class="txt_field" required />
                                    </div>
                                </div>
                            </div>
                            <div class="item-field">
                                <label><?php echo e(@$contentPage->field->who); ?> <span style="color: #fc3462;">*</span></label>
                                <select name="you_are" id="you_are" required>
                                <?php if(!empty(@$contentPage->who_select)): ?>
                                    <?php $__currentLoopData = @$contentPage->who_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(@$value->name); ?>"><?php echo e(@$value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </select>
                                <div class="icon-choose"><img src="<?php echo e(__BASE_URL__); ?>/images/arr-choose.svg" class="img-fluid" alt="" /></div>
                            </div>
                            <div class="item-field show-choose" id="select-show">
                                <label><?php echo e(@$contentPage->field->choice); ?> <span style="color: #fc3462;">*</span></label>
                                <select name="help" id="help" required>
                                <?php if(!empty(@$contentPage->choice_select)): ?>
                                    <?php $__currentLoopData = @$contentPage->choice_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(@$value->name); ?>"><?php echo e(@$value->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </select>
                                <div class="icon-choose"><img src="<?php echo e(__BASE_URL__); ?>/images/arr-choose.svg" class="img-fluid" alt="" /></div>
                            </div>
                            <div class="item-field">
                                <label><?php echo e(@$contentPage->field->content); ?> </label>
                                <textarea name="content" cols="30" rows="10" placeholder="<?php echo e(@$contentPage->field->placeholder_content); ?> "></textarea>
                            </div>
                            <div class="item-field item-field-btn">
                                <input type="submit" value="<?php echo e(@$contentPage->field->button); ?> " class="btn_field" />
                            </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="maps">
                            <?php echo @$contentPage->khoi1->map; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="popup-success">
            <div class="modal fade" id="Modal-success">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="content-pop-success text-center">
                                <div class="close-popup" data-bs-dismiss="modal"><img src="<?php echo e(__BASE_URL__); ?>/images/close.svg" class="img-fluid" alt="" /></div>
                                <div class="icon-success">
                                    <svg width="84" height="84" viewBox="0 0 84 84" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="42" cy="42" r="40" fill="#D3F8D6" stroke="#57D562" stroke-width="4" />
                                        <path d="M30.8892 42L38.6669 49.7778L53.1114 35.3333" stroke="#57D562" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </div>
                                <div class="info">
                                    <h4>Cảm ơn, <span class="text-name-success"></span></h4>
                                    <div class="desc">Chúng tôi đã nhận được thông tin và sẽ sớm liên hệ với bạn qua Email. Cảm ơn bạn đã dành sự quan tâm đến Slash!</div>
                                    <div class="btn-page"><a href="<?php echo e(asset('/')); ?>">Tìm hiểu thêm</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="box-place">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="title-place">
                        <img src="<?php echo e(__BASE_URL__); ?>/images/t-place.svg" class="img-fluid" alt="<?php echo @$contentPage->khoi2; ?>" />
                        <h2><?php echo @$contentPage->khoi2; ?></h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="list-place">
                        <?php if(!empty(@$contentPage->contact_content)): ?>
                            <?php $__currentLoopData = @$contentPage->contact_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item-place">
                                    <div class="title-place">
                                        <img src="<?php echo e(@$value->icon); ?>" class="img-fluid" alt="<?php echo e(@$value->title); ?>" />
                                        <span><?php echo e(@$value->title); ?></span>
                                    </div>
                                    <?php echo @$value->content; ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/slash/domains/getslash.tuvanweb.com/public_html/resources/views/frontend/pages/contact/index.blade.php ENDPATH**/ ?>