<?php $__env->startSection('main'); ?>
    <section class="banner">
        <div class="slide-banner">
            <div class="item-banner">
                <div class="avarta"><img src="<?php echo e(!empty($contentPage->banner) ? $contentPage->banner : __BASE_URL__.'/images/bn-blog.jpg'); ?>" class="img-fluid w-100" alt=""></div>
                <div class="caption">
                    <div class="container">
                        <h3 class="text-uppercase "><?php echo e(@$contentPage->content->name); ?></h3>
                        <h1><?php echo e(@$contentPage->content->desc); ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="recruitment blog-cate">
        <div class="container">
            <div class="list-cruitment">
                <div class="row">
                    <?php $__currentLoopData = $data ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                        <div class="item-recruit">
                            <div class="avarta">
                                <a href="<?php echo e(route('pages.recruitments.single', $item->slug)); ?>" title="<?php echo e($item->{ 'name_'.locale() }); ?>">
                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->{ 'name_'.locale() }); ?>">
                                </a>
                            </div>
                            <div class="info">
                                <div class="date-time"><?php echo e($item->created_at->format('F jS, Y')); ?></div>
                                <h3><a href="<?php echo e(route('pages.recruitments.single', $item->slug)); ?>"><?php echo e($item->{ 'name_'.locale() }); ?></a></h3>
                                <div class="desc">
                                    <?php echo e($item->{ 'sort_desc_'.locale() }); ?>

                                </div>
                                <div class="view-more">
                                    <a href="<?php echo e(route('pages.recruitments.single', $item->slug)); ?>"><?php echo app('translator')->getFromJson('site.view_more'); ?>
                                        <img src="<?php echo e(__BASE_URL__); ?>/images/more.svg" class="img-fluid" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="pagination w-100">
                <ul class="list-inline w-100 text-center">
                    <?php echo e($data->links()); ?>

                </ul>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bestay\resources\views/frontend/pages/recruitments/index.blade.php ENDPATH**/ ?>