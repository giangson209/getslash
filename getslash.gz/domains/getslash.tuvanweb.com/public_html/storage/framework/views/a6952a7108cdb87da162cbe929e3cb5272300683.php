<li class="header">TRANG QUẢN TRỊ</li>

<li class="<?php echo e(Request::segment(2) == 'home' ? 'active' : null); ?>">
    <a href="<?php echo e(route('backend.home')); ?>">
        <i class="fa fa-home"></i> <span>Trang chủ</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'users' ? 'active' : null); ?>">
    <a href="<?php echo e(route('users.index')); ?>">
        <i class="fa fa-user"></i> <span>Tài khoản</span>
    </a>
</li>
<li class="treeview <?php echo e(Request::segment(2) === 'services' ? 'active' : null); ?>">
    <a href="#">
        <i class="fa fa-server" aria-hidden="true"></i> <span>Dịch vụ</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">

        <li class="<?php echo e(Request::segment(3) === 'website' ? 'active' : null); ?>">
            <a href="<?php echo e(route('backend.services.getListType')); ?>"><i class="fa fa-circle-o"></i> Thiết kế website</a>
        </li>

        <li class="<?php echo e(activeMenuServices('hosting')); ?>">
            <a href="<?php echo e(route( 'accompanied-services.index' , [ 'type'=> 'hosting' ] )); ?>"><i class="fa fa-circle-o"></i> Hosting</a>
        </li>

        <li class="<?php echo e(activeMenuServices('vps')); ?>">
            <a href="<?php echo e(route( 'accompanied-services.index' , [ 'type'=> 'vps' ] )); ?>"><i class="fa fa-circle-o"></i> VPS</a>
        </li>

        <li class="<?php echo e(Request::segment(3) == 'accompanied-services' && request()->get('type') == 'ssl' ? 'active' : null); ?>">
            <a href="<?php echo e(route( 'accompanied-services.index' , [ 'type'=> 'ssl' ] )); ?>"><i class="fa fa-circle-o"></i> SSL</a>
        </li>
        <li class="<?php echo e(Request::segment(3) == 'accompanied-services' && request()->get('type') == 'email' ? 'active' : null); ?>

             <?php echo e(activeMenuServices('email')); ?>">
            <a href="<?php echo e(route( 'accompanied-services.index' , [ 'type'=> 'email' ] )); ?>"><i class="fa fa-circle-o"></i> Email Hosting</a>
        </li>
        

    </ul>
</li>


<li class="<?php echo e(Request::segment(2) == 'projects' ? 'active' : null); ?>">
    <a href="<?php echo e(route('projects.index')); ?>">
        <i class="fa fa-globe" aria-hidden="true"></i> <span>Dựa án tiêu biểu</span>
    </a>
</li>
<li class="<?php echo e(Request::segment(2) == 'posts' ? 'active' : null); ?>">
    <a href="<?php echo e(route('posts.index', ['type'=> 'blog'])); ?>">
        <i class="fa fa-tags" aria-hidden="true"></i> <span>Bài viết</span>
    </a>
</li>

<li class="<?php echo e(Request::segment(2) == 'pages' ? 'active' : null); ?>">
    <a href="<?php echo e(route('pages.list')); ?>">
        <i class="fa fa-paper-plane" aria-hidden="true"></i> <span>Cài đặt trang</span>
    </a>
</li>

<li class="<?php echo e(Request::segment(2) == 'contact' ? 'active' : null); ?>">
    <a href="<?php echo e(route('get.list.contact')); ?>">
        <i class="fa fa-bell" aria-hidden="true"></i> <span>Liên hệ
        <?php echo e($count_contact_new > 0 ? '('.$count_contact_new.' mới) ' : null); ?>

        </span>
    </a>
</li>

<li class="<?php echo e(Request::segment(2) == 'orders' ? 'active' : null); ?>">
    <a href="<?php echo e(route('orders.list')); ?>">
        <i class="fa fa-database" aria-hidden="true"></i> <span>Đơn hàng 
            <?php echo e($count_order_new > 0 ? '('.$count_order_new.' mới) ' : null); ?>

        </span>
    </a>
</li>



<li class="header">Cấu hình hệ thống</li>
<li class="treeview <?php echo e(Request::segment(2) === 'options' || Request::segment(2) === 'images' || Request::segment(2) === 'menu' || Request::segment(2) === 'banks' ? 'active' : null); ?>">
    <a href="#">
        <i class="fa fa-cog" aria-hidden="true"></i> <span>Cấu hình</span>
        <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
        </span>
    </a>
    <ul class="treeview-menu">

        <li class="<?php echo e(Request::segment(3) === 'general' ? 'active' : null); ?>">
            <a href="<?php echo e(route('backend.options.general')); ?>"><i class="fa fa-circle-o"></i> Cấu hình chung</a>
        </li>

        <li class="<?php echo e(request()->get('type') == 'slider' ? 'active' : null); ?>">
            <a href="<?php echo e(route('images.index', ['type'=> 'slider'])); ?>"><i class="fa fa-circle-o"></i> Banner</a>
        </li>

        <li class="<?php echo e(request()->get('type') == 'partner' ? 'active' : null); ?>">
            <a href="<?php echo e(route('images.index', ['type'=> 'partner'])); ?>"><i class="fa fa-circle-o"></i> Đối tác</a>
        </li>

        <li class="<?php echo e(Request::segment(2) === 'menu' ? 'active' : null); ?>">
            <a href="<?php echo e(route('setting.menu')); ?>"><i class="fa fa-circle-o"></i> Menu</a>
        </li>

        <li class="<?php echo e(Request::segment(2) === 'banks' ? 'active' : null); ?>">
            <a href="<?php echo e(route('banks.index')); ?>"><i class="fa fa-circle-o"></i> Ngân hàng</a>
        </li>


    </ul>
</li>
<div style="display: none;">
	<li class="header">Cấu hình hệ thống</li>
	<li class="treeview <?php echo e(Request::segment(2) == 'options' ? 'active' : null); ?>">
		<a href="#">
			<i class="fa fa-folder"></i> <span>Setting (Developer)</span>
			<span class="pull-right-container">
				<i class="fa fa-angle-left pull-right"></i>
			</span>
		</a>
		<ul class="treeview-menu">
			<li class="<?php echo e(Request::segment(3) == 'developer-config' ? 'active' : null); ?>">
				<a href="<?php echo e(route('backend.options.developer-config')); ?>"><i class="fa fa-circle-o"></i> Developer - Config</a>
			</li>
			<li class="">
				<a href="<?php echo e(route('io_generator_builder')); ?>" target="_blank"><i class="fa fa-circle-o"></i> Builder Tables</a>
			</li>
		</ul>
	</li>
</div><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/backend/layouts/menu.blade.php ENDPATH**/ ?>