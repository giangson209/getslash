
<?php $__env->startSection('main'); ?>
    <section class="banner banner-home">
        <div class="slide-banner">
            <div class="item-banner">
                <div class="avarta"><img src="<?php echo e(@$content->top->banner); ?>" class="img-fluid w-100" alt=""></div>
                <div class="caption">
                    <div class="container">
                        <h3 class="text-uppercase wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s"><?php echo e(@$content->top->title_1); ?></h3>
                        <h1 class=" wow fadeInUp wHighlight" data-aos-duration=".45" data-wow-delay=".45s"><?php echo e(@$content->top->title_2); ?></h1>
                        <div class="desc wow fadeInUp wHighlight" data-aos-duration=".65" data-wow-delay=".55s"><?php echo e(@$content->top->desc); ?></div>
                        <div class="btn-beatay wow fadeInUp wHighlight" data-aos-duration=".85" data-wow-delay=".75s">
                            <a href="<?php echo e(@$content->top->link); ?>" class="text-uppercase"><?php echo app('translator')->getFromJson('site.explore_now'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="btn-scroll wow fadeInUp wHighlight" data-aos-duration="1.25" data-wow-delay=".95s">
            <a href="#number"><img src="<?php echo e(__BASE_URL__); ?>/images/scroll.png" class="img-fluid" alt=""><span>Scroll</span></a>
        </div>
    </section>
    <section class="box-number">
        <div class="container">
            <div class="list-number">
                <div class="row">
                    <?php if(!empty(@$content->summary)): ?>
                        <?php $__currentLoopData = @$content->summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="item-number text-center">
                                    <div class="numb"><?php echo e(@$value->title); ?></div>
                                    <div class="desc"><?php echo e(@$value->desc); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <section class="box-trending" id="trending">
        <div class="container">
            <div class="title">
                <h4 class="text-uppercase wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s"><?php echo app('translator')->getFromJson('site.trending_styles'); ?></h4>
                <h2 class=" wow fadeInUp wHighlight" data-aos-duration=".45" data-wow-delay=".45s"><?php echo app('translator')->getFromJson('site.for_your_space'); ?></h2>
            </div>
            <div class="list-trend">
                <?php $__currentLoopData = $styles ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-trend wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                    <div class="row align-items-center">
                        <div class="col-md-7">
                            <div class="avarta">
                                <a href="<?php echo e(route('styles.single', $item->slug)); ?>">
                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="txt-trend">
                                <div class="year"><?php echo e($item->created_at->format('Y')); ?></div>
                                <h3><a href="<?php echo e(route('styles.single', $item->slug)); ?>"><?php echo e($item->{ 'name_'.locale() }); ?></a></h3>
                                <div class="desc">
                                    <?php echo e($item->{ 'desc_'.locale() }); ?>

                                </div>
                                <div class="view-more">
                                    <a href="<?php echo e(route('styles.single', $item->slug)); ?>"><?php echo app('translator')->getFromJson('site.view_more'); ?>
                                        <img src="<?php echo e(__BASE_URL__); ?>/images/more.svg" class="img-fluid" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <section class="box-partner partner-home" style="background: url(<?php echo e(__BASE_URL__); ?>/images/partner.jpg);">
        <div class="avarta avar-partner">
            <img src="<?php echo e(__BASE_URL__); ?>/images/partner.jpg" class="img-fluid w-100" alt="">
            <div class="title">
                <div class="container">
                    <h4 class="text-uppercase wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s"><?php echo app('translator')->getFromJson('site.partners'); ?></h4>
                    <h2 class=" wow fadeInUp wHighlight" data-aos-duration=".45" data-wow-delay=".45s"><?php echo app('translator')->getFromJson('site.proud_cooperations'); ?></h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="slide-part wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s">
                <?php if(!empty(@$content->partner)): ?>
                    <?php $__currentLoopData = @$content->partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item-slide">
                            <div class="item-part">
                                <a href="<?php echo e($value->link); ?>"><img src="<?php echo e($value->logo); ?>" class="img-fluid" alt=""></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php echo $__env->make('frontend.pages.contact.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/frontend/pages/home/index.blade.php ENDPATH**/ ?>