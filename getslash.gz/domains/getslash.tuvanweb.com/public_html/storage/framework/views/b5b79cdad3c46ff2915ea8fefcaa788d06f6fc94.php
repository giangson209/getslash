<?php $__env->startSection('main'); ?>
	<main>
	<section class="breadrumbs">
		<div class="container">
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home" aria-hidden="true"></i></a></li>
			    <li class="breadcrumb-item active" aria-current="page">Tin tức</li>
			  </ol>
			</nav>
		</div>
	</section>
	<section class="amblog-element">
		<div class="container">
			<?php if(count($data)): ?>
				<div class="amblog-list">
					<div class="row">
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-4 col-sm-4">
								<?php echo $__env->make('frontend.components.content-news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			<?php else: ?>
				<h2>Nội dung đang được cập nhật</h2>
			<?php endif; ?>
			
		</div>
	</section>
	<section class="paginations">
		<nav aria-label="Page navigation example">
		  	<ul class="pagination justify-content-center">
		  		<?php echo $data->links(); ?>

		  	</ul>
		</nav>
	</section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/pages/blog/archive.blade.php ENDPATH**/ ?>