<?php $__env->startSection('controller', request()->get('type') == 'slider' ? 'Slider' : 'Đối tác' ); ?>
<?php $__env->startSection('action','Thêm mới'); ?>
<?php $__env->startSection('controller_route', route('images.index').'?type='.request()->get('type')); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('images.postMultiDel')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="btnAdd">
                        <a href="<?php echo e(route('images.create')); ?>?type=<?php echo e(request()->get('type')); ?>">
                            <fa class="btn btn-primary"><i class="fa fa-plus"></i> Thêm</fa>
                        </a>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa ?')"><i class="fa fa-trash-o"></i> Xóa
                        </button>
                    </div>

                    <table id="example1" class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th><input type="checkbox" name="chkAll" id="chkAll"></th>
                                <th>STT</th>
                                <th>Hình ảnh</th>
                                <th width="30%">Tiêu đề</th>
                                <th>Link</th>
                                <th>Trạng thái</th>
                                <th width="150px">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input type="checkbox" name="chkItem[]" value="<?php echo $item['id']; ?>"></td>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td>
                                        <img src="<?php echo e(renderImage($item->image)); ?>" class="img-responsive imglist">
                                    </td>
                                    <td><?php echo $item->name; ?></td>
                                    <td><?php echo e($item->link); ?></td>
                                    <td>
                                        <?php if($item->status == 1 ): ?>
                                            <span class="label label-success">Đang hiển thị</span>
                                        <?php else: ?>
                                            <span class="label label-danger">Đang ẩn</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                    <div>
                                        <a href="<?php echo e(route('images.edit', ['id'=> $item->id, 'type' => $item->type])); ?>" title="Sửa">
                                            <i class="fa fa-pencil fa-fw"></i> Sửa
                                        </a> &nbsp; &nbsp; &nbsp;
                                          <a href="javascript:void(0);" class="btn-destroy" 
                                          data-href="<?php echo e(route( 'images.destroy',  $item->id )); ?>"
                                          data-toggle="modal" data-target="#confim">
                                          <i class="fa fa-trash-o fa-fw"></i> Xóa
                                          </a>
                                      </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/backend/image/list.blade.php ENDPATH**/ ?>