
<?php $__env->startSection('controller','Liên kết tìm kiếm nhiều nhất'); ?>
<?php $__env->startSection('action','Cập nhật'); ?>
<?php $__env->startSection('controller_route', route('backend.options.tags')); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
       	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       	<form action="<?php echo e(route('backend.options.post.tags')); ?>" method="POST">
       		<?php echo csrf_field(); ?>
			<div class="nav-tabs-custom">
			    <ul class="nav nav-tabs">
			        <li class="active">
			            <a href="#activity" data-toggle="tab" aria-expanded="true">Liên kết tìm kiếm nhiều nhất</a>
			        </li>
			    </ul>
			    <div class="tab-content">
					<div class="tab-pane active" id="activity">
						<div class="row">
							<div class="col-sm-12">
								<div class="repeater" id="repeater">
					                <table class="table table-bordered table-hover tags-link">
					                    <thead>
						                    <tr>
						                    	<th style="width: 30px;">STT</th>
						                    	<th width="">Tiêu đề</th>
						                    	<th>Liên kết</th>
						                    	<th style="width: 20px"></th>
						                    </tr>
					                	</thead>
					                    <tbody id="sortable">
											<?php if(!empty($content->tags)): ?>
												<?php $__currentLoopData = $content->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php $index = $loop->index + 1;?>
													<?php echo $__env->make('backend.repeater.row-tags-link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
					                    </tbody>
					                </table>
					                <div class="text-right">
					                    <button class="btn btn-primary" 
							            	onclick="repeater(event,this,'<?php echo e(route('get.layout')); ?>','.index', 'tags-link', '.tags-link')">Thêm
							            </button>
					                </div>
					            </div>
							</div>
							<div class="col-sm-12">
								<button type="submit" class="btn btn-primary">Lưu lại</button>
							</div>
						</div>
					</div>
			    </div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bephungphu/public_html/resources/views/backend/options/tags-config.blade.php ENDPATH**/ ?>