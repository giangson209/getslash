<?php $__env->startSection('main'); ?>
	<main class="page-wrapper">
		<section class="product-detail pd-60">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-md-5">
						<div class="product-gallery not-arrow not-dots">
							<div><img src="<?php echo e($data->image); ?>" alt=""> </div>
							<?php $__currentLoopData = $data->ProductImage ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div><img src="<?php echo e($item->image); ?>" alt=""> </div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
					<div class="col-md-5 offset-md-1">
						<div class="product-info">
							<h1><?php echo e($data->name); ?></h1>
							<div class="price">
								<?php if(!empty($data->sale)): ?>
									<span class="new-price"><?php echo e(number_format($data->sale_price, 0, '.','.')); ?> VND</span>
									<span class="old-price"><?php echo e(number_format($data->regular_price, 0, '.','.')); ?> VND</span>
								<?php else: ?>
									<span class="new-price"><?php echo e(number_format($data->regular_price, 0, '.','.')); ?> VND</span>
								<?php endif; ?>
							</div>
							<div class="product-index">
								<?php echo $data->feature; ?>

							</div>
							<div class="product-index mgt-20">
								<?php echo $data->information; ?>

							</div>
							<div class="product-button mgt-30 flex-center">
								<a href="<?php echo e($data->add_cart_url); ?>&redirect_page=check-out" title="" class="btn-submit inflex-center-center">Mua ngay</a>
								<a href="<?php echo e($data->add_cart_url); ?>" title="" class="btn btn-blue text-uppercase">Thêm vào giỏ hàng</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="product-related pd-60">
			<div class="container">
				<h2 class="title title-lg">Sản phẩm liên quan</h2>
				<div class="row">
					<?php $__currentLoopData = $productSame ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3">
						<div class="products-item">
							<h4 class="pro-name"><a href="<?php echo e($item->url); ?>" title=""><?php echo e($item->name); ?></a> </h4>
							<div class="price">
								<?php if(!empty($item->sale)): ?>
									<span class="new-price"><?php echo e(number_format($item->sale_price, 0, '.','.')); ?> VND</span>
									<span class="old-price"><?php echo e(number_format($item->regular_price, 0, '.','.')); ?> VND</span>
								<?php else: ?>
									<span class="new-price"><?php echo e(number_format($item->regular_price, 0, '.','.')); ?> VND</span>
								<?php endif; ?>
							</div>
							<a href="<?php echo e($item->url); ?>" class="pro-image zoom" title="">
								<img src="<?php echo e($item->image); ?>" alt="">
							</a>
							<div class="text-center">
								<a href="<?php echo e($item->add_cart_url); ?>" title="" class="btn btn-blue mgt-30">Mua ngay</a>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\batdongsan\resources\views/frontend/pages/products/single-product.blade.php ENDPATH**/ ?>