
<?php if(!empty($dataSeo->content)){
	$content = json_decode( $dataSeo->content );
} ?>
<?php $__env->startSection('main'); ?>
	<main class="page-wrapper bg-white">
		<section class="about pd-60">
			<div class="container">
				<div class="row">
					<div class="col-md-6"><h1 class="title title-lg">Giới thiệu</h1></div>
					<div class="col-md-6">
						<p><?php echo @$content->desc; ?></p>
					</div>
					<div class="col-md-12 mgt-30 mgb-30"><img src="<?php echo @$content->banner; ?>" alt=""> </div>
				</div>
				<div class="article">
					<?php echo @$content->main_content; ?>

				</div>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/home-tech/resources/views/frontend/pages/about.blade.php ENDPATH**/ ?>