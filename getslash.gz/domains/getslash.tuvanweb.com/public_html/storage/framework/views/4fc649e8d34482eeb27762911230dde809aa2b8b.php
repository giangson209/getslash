
<?php $__env->startSection('main'); ?>
	<style>
		a.btn-close {
			text-align: center;
			display: inline-block;
			line-height: 22px;
		}
		.btn-submit {
			line-height: 45px;
			text-align: center;
		}
	</style>
	<main class="page-wrapper bg-white">
		<section class="cart pd-60">
			<div class="container">
				<h1 class="title title-lg">Giỏ hàng</h1>
				<?php if(Cart::count()): ?>
					<div class="cart-table">
					<table>
						<thead>
						<tr>
							<th>Sản phẩm</th>
							<th>Số lượng</th>
							<th>Giá</th>
							<th></th>
						</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td>
										<div class="cart-item">
											<a href="<?php echo e(route('home.single.product', $item->options->slug)); ?>" title="" class="zoom"><img src="<?php echo e($item->options->image); ?>" alt=""> </a>
											<h4 class="pro-name"><a href="<?php echo e(route('home.single.product', $item->options->slug)); ?>" title=""><?php echo e($item->name); ?></a> </h4>
										</div>
									</td>
									<td>
										<div class="input-group">
											<input type="button" value="-" class="button-minus" data-field="quantity">
											<input type="number" step="1" max="" value="<?php echo e($item->qty); ?>" name="quantity" class="quantity-field">
											<input type="button" value="+" class="button-plus" data-field="quantity">
										</div>
									</td>
									<td>
										<div class="price"><span class="new-price"><?php echo e(number_format($item->price * $item->qty , 0, '.', '.')); ?> VND</span></div>
									</td>
									<td><a class="btn-close" href="<?php echo e(route('home.remove.cart', $item->rowId)); ?>"><i class="fa fa-close"></i> </a> </td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
					<div class="flex-center-end total">
					<span>Tổng tiền:</span>
					<span class="text-blue"><?php echo e(number_format(Cart::total(), 0, '.', '.')); ?> VND</span>
				</div>
					<div class="flex-center-end mgt-30">
					<a class="btn-submit" href="<?php echo e(route('home.check-out.get')); ?>" type="button">Thanh toán</a>
				</div>
				<?php else: ?>
					<div class="alert alert-success" role="alert">
						<h4 class="alert-heading">Thông báo</h4>
						<p>Giỏ hàng trống.</p>
						<hr>
						<a href="<?php echo e(url("/")); ?>" class="btn btn-success">Về trang chủ</a>
					</div>
				<?php endif; ?>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/home-tech/resources/views/frontend/pages/products/cart.blade.php ENDPATH**/ ?>