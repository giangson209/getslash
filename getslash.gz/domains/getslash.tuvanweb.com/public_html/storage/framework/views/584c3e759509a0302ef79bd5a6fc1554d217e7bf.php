<?php $__env->startSection('main'); ?>

	<section id="box-new-cate" class="pt-50 pb-50">
		<div class="container">
			<div class="box-cate">
				<div class="titl-nws">
					<h2>Tags: <?php echo e($tag->name); ?></h2>
				</div>
				<div class="row slide-news">
					<?php if(count($data)): ?>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-sm-3" style="margin-top: 20px">
								<div class="item">
									<div class="avarta">
										<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>">
											<img data-src="<?php echo e($item->image); ?>" class="img-fluid w-100 lazyload" alt="<?php echo e($item->name); ?>">
										</a>
									</div>
									<div class="info">
										<div class="date-view">
											<ul class="list-inline">
												<li class="list-inline-item">
													<div class="date"><?php echo e($item->created_at->format('d/m/Y')); ?></div>
												</li>
												<li class="list-inline-item">
													<div class="view"><i class="fa fa-eye"></i><?php echo e($item->view_count); ?> lượt xem</div>
												</li>
											</ul>
										</div>
										<h3><a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h3>
										<div class="desc">
											<?php echo e($item->desc); ?>

										</div>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
						<div class="col-sm-12 item text-center" style="margin-top: 20px">
							<style>
								.pagination li{
									text-align: center;
								}
							</style>
							<ul class="pagination" style="display: inline-block;">
								<?php echo $data->links(); ?>

							</ul>
							
						</div>
					<?php else: ?>
						<div class="col-sm-12">
							<div class="alert alert-success">
								Nội dung đang được cập nhật.
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hungphu\resources\views/frontend/pages/tags-news.blade.php ENDPATH**/ ?>