<?php $__env->startSection('main'); ?>
	<section id="breadcrumbs">
		<div class="avarta">
			<?php if($dataSeo->banner): ?>
				<img src="<?php echo e($dataSeo->banner); ?>" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php else: ?>
				<img src="<?php echo e(__BASE_URL__); ?>/images/bread.png" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php endif; ?>
			
		</div>
		<div class="info">
			<div class="container text-center">
				<h2 class="text-uppercase">Dịch vụ</h2>
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ <span>/</span></a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Dịch vụ</a></li>
				</ul>
			</div>
		</div>
	</section>
	<h1 class="d-none"><?php echo e(@$dataSeo->title_h1); ?></h1>
	<?php if(!empty($dataSeo->content)){
		$content = json_decode($dataSeo->content);
	} ?>
	<section id="service">
		<div class="list-icon-srv pt-100 pb-100">
			<div class="container">
				<div class="content">
					<div class="row">
						<?php if(!empty($content->criteria)): ?>
						    <?php $__currentLoopData = $content->criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    	<div class="col-md-3 col-sm-6">
									<div class="item">
										<div class="avarta">
											<img src="<?php echo e(@$value->background); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$value->title); ?>">
										</div>
										<div class="info text-center">
											<div class="info-icon">
												<div class="icon">
													<img src="<?php echo e(@$value->icon); ?>" class="img-fluid" alt="<?php echo e(@$value->title); ?>">
												</div>
												<h2>
													<a title="" href="javascript:0"><?php echo e(@$value->title); ?></a>
												</h2>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<div class="slide-srv-cate" style="background: #f4f7ff;">
			<div class="container">
				<div class="content">
					<div class="list-item-cate">
						<?php if(!empty($content->services)): ?>
						    <?php $__currentLoopData = $content->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item">
									<div class="row">
										<div class="col-md-6 col-sm-6">
											<div class="left">
												<img src="<?php echo e(@$value->background); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$value->title); ?>">
											</div>
										</div>
										<div class="col-md-6 col-sm-6">
											<div class="right">
												<h2><a title="<?php echo e(@$value->title); ?>" href="<?php echo @$value->link; ?>"><?php echo e(@$value->title); ?></a></h2>
												<div class="desc">
													<?php echo @$value->content; ?>

												</div>
												<div class="btn-view">
													<a title="Xem chi tiết" href="<?php echo @$value->link; ?>">XEM CHI TIẾT</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="transform" class="pt-100">
		<div class="container-fluid list-trans">
			<div class="conten">
				<div class="title text-center text-uppercase"> <h2><?php echo e(@$content->gallery->title); ?></h2></div>
				<div class="list-transt" style="background: #f9f9f9">
					<div class="item">
						<div class="row">
							<div class="col-md-6">
								<div class="box-img slide-img">
									
									<?php if(!empty($content->gallery_1->list_image)): ?>
	                            		<?php $__currentLoopData = $content->gallery_1->list_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            			<div class="item">
	                            				<a title="" href="<?php echo e(@$item); ?>" data-fancybox="group" class ="lightbox" data-fancybox="lib-1">
	                            					<img src="<?php echo e(@$item); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$content->gallery->title); ?>">
	                            				</a>
	                            			</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>

								</div>
							</div>
							<div class="col-md-6">
								<div class="box-text">
									<?php echo @$content->gallery_1->content; ?>

								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="row">
							<div class="col-md-6">
								<div class="box-img slide-img">
									<?php if(!empty($content->gallery_2->list_image)): ?>
	                            		<?php $__currentLoopData = $content->gallery_2->list_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            			<div class="item">
	                            				<a title="" href="<?php echo e(@$item); ?>" data-fancybox="group" class ="lightbox" data-fancybox="lib-2">
	                            					<img src="<?php echo e(@$item); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$content->gallery->title); ?>">
	                            				</a>
	                            			</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</div>
							</div>
							<div class="col-md-6">
								<div class="box-text">
									<?php echo @$content->gallery_1->content; ?>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/pages/services.blade.php ENDPATH**/ ?>