<?php
    $routeHeader = [
        'pages.recruitments.single',
        'pages.post.single'
    ];
    $headerDefault = true;
    if(!empty(request()->route()) && in_array(request()->route()->getName(), $routeHeader)){
        $headerDefault = false;
    }
?>
<header class="<?php echo e($headerDefault ? null : 'header-white'); ?>">
    <div class="header-top  <?php echo e($headerDefault ? 'head-trans' :  'head-white'); ?>">
        <div class="container-fluid">
            <div class="h-pc">
                <div class="row align-items-center">
                    <div class="col-md-3">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e($headerDefault ? @$site_info->logo : @$site_info->logo_color); ?>" class="img-fluid" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <ul>
                            <?php $__currentLoopData = $menuMain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php if(count($item->get_child_cate())): ?>
                                        <a href="<?php echo e(url($item->url)); ?>" class="<?php echo e(url()->current() == url($item->url) ? 'active' : null); ?>"><?php echo e($item->name_menu); ?> <i class="fa fa-caret-down"></i></a>
                                        <div class="sub-menu">
                                            <ul>
                                                <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url($value->url)); ?>"><?php echo e($value->name_menu); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php else: ?>
                                       <a href="<?php echo e(url($item->url)); ?>" class="<?php echo e(url()->current() == url($item->url) ? 'active' : null); ?>"><?php echo e($item->name_menu); ?></a>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="javascript:;" style="text-transform: uppercase"><?php echo e(locale()); ?> <i class="fa fa-caret-down"></i></a>
                                <div class="sub-menu">
                                    <ul>
                                        <li><a href="<?php echo e(route('home.change-locale', 'en')); ?>" class="<?php echo e(locale() == 'en' ? 'active' : null); ?>">English</a></li>
                                        <li><a href="<?php echo e(route('home.change-locale', 'vi')); ?>" class="<?php echo e(locale() == 'vi' ? 'active' : null); ?>">tiếng việt</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="h-mobile" style="display: none;">
                <div class="row align-items-center">
                    <div class="col-3 text-left"> 
                        <div class="btn-menu"><a href="javascript:void(0)"><img src="<?php echo e(__BASE_URL__); ?>/images/menu.png" alt=""></a></div>
                        <ul class="menu-mobile">
                            <div class="btn-close-menu"><a href="javascript:void(0)"><img src="<?php echo e(__BASE_URL__); ?>/images/close.png" class="img-fluid" alt=""></a></div>
                            <?php $__currentLoopData = $menuMain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php if(count($item->get_child_cate())): ?>
                                        <a href="javascript:void(0)" class="<?php echo e(url()->current() == url($item->url) ? 'active' : null); ?>"><?php echo e($item->name_menu); ?> <i class="fa fa-caret-down"></i></a>
                                        <div class="sub-menu-mobile">
                                            <ul>
                                                <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url($value->url)); ?>"><?php echo e($value->name_menu); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php else: ?>
                                       <a href="<?php echo e(url($item->url)); ?>" class="<?php echo e(url()->current() == url($item->url) ? 'active' : null); ?>"><?php echo e($item->name_menu); ?></a>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="col-6 text-center">
                        <div class="logo">
                            <a href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e($headerDefault ? @$site_info->logo : @$site_info->logo_color); ?>" class="img-fluid" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-3 text-right">
                        <div class="translate">
                            <ul>
                                <li>
                                    <a href="javascript:;" class="mb-trans" style="text-transform: uppercase"><span><?php echo e(locale()); ?> <i class="fa fa-caret-down"></i></span></a>
                                    <div class="sub-menu sun-trans">
                                        <div class="btn-close-trans"><a href="javascript:void(0)"><img src="<?php echo e(__BASE_URL__); ?>/images/close.png" class="img-fluid" alt=""></a></div>
                                        <ul>
                                            <li><a href="<?php echo e(route('home.change-locale', 'en')); ?>" class="<?php echo e(locale() == 'en' ? 'active' : null); ?>">English</a></li>
                                            <li><a href="<?php echo e(route('home.change-locale', 'vi')); ?>" class="<?php echo e(locale() == 'vi' ? 'active' : null); ?>">tiếng việt</a></li>
                                        </ul>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/frontend/teamplate/header.blade.php ENDPATH**/ ?>