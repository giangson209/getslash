<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>