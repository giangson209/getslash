
<?php $__env->startSection('controller', renderLinkAddPostType()['title']); ?>
<?php $__env->startSection('controller_route', renderLinkAddPostType()['linkList'] ); ?>
<?php $__env->startSection('action','Danh sách'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
		<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<form action="<?php echo e(route('posts.update', $data->id)); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<?php echo method_field('PUT'); ?>
			<input type="hidden" value="blog" name="type">
			<div class="row">
				<div class="col-sm-9">
		            <div class="nav-tabs-custom">
		                <ul class="nav nav-tabs">
		                    <li class="active">
		                        <a href="#activity" data-toggle="tab" aria-expanded="true">Bài viết</a>
		                    </li>
		                    <li class="">
		                    	<a href="#setting" data-toggle="tab" aria-expanded="true">Cấu hình seo</a>
		                    </li>
		                </ul>
		                <div class="tab-content">
		                    <div class="tab-pane active" id="activity">
		                        <div class="row">
		                            <div class="col-sm-12">
		                                <div class="form-group">
		                                    <label>Tiêu đề</label>
		                                    <input type="text" class="form-control" name="name" id="name" value="<?php echo old('name', @$data->name); ?>" required="">
		                                </div>
		                                <div class="form-group" id="edit-slug-box">
		                                    <?php echo $__env->make('backend.posts.permalink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		                                </div>


		                                
		                                <div class="form-group">
		                                    <label>Mô tả ngắn</label>
		                                    <textarea class="form-control" rows="5" name="desc"><?php echo old('desc', @$data->desc); ?></textarea>
		                                </div>
		                                
		                                <div class="form-group">
		                                    <label>Nội dung</label>
		                                    <textarea class="content" name="content"><?php echo old('content', @$data->content); ?></textarea>
		                                </div>
		                            </div>
		                        </div>
		                    </div>
		                    <div class="tab-pane" id="setting">
		                        <div class="form-group">
		                            <label>Title SEO</label>
		                            <label style="float: right;">Số ký tự đã dùng: <span id="countTitle"><?php echo e($data->meta_title != null ? mb_strlen( $data->meta_title, 'UTF-8') : 0); ?>/70</span></label>
		                            <input type="text" class="form-control" name="meta_title"
		                                   value="<?php echo old('desc', isset($data->meta_title) ? $data->meta_title : null ); ?>"
		                                   id="meta_title">
		                        </div>

		                        <div class="form-group">
		                            <label>Meta Description</label>
		                            <label style="float: right;">Số ký tự đã dùng: <span id="countMeta"><?php echo e($data->meta_description != null ? mb_strlen( $data->meta_description, 'UTF-8') : 0); ?>/360</span></label>
		                            <textarea name="meta_description" class="form-control" id="meta_description"
		                                      rows="5"><?php echo old('meta_description', isset($data->meta_description) ? $data->meta_description : null ); ?></textarea>
		                        </div>

		                        <div class="form-group">
		                            <label>Meta Keyword</label>
		                            <input type="text" class="form-control" name="meta_keyword"
		                                   value="<?php echo old('meta_keyword', isset($data->meta_keyword) ? $data->meta_keyword : null ); ?>">
		                        </div>

		                        <h4 class="ui-heading">Xem trước kết quả tìm kiếm</h4>
		                        <div class="google-preview">
		                            <span class="google__title"><span><?php echo !empty($data->meta_title) ? $data->meta_title : $data->name; ?></span> </span>
		                            <div class="google__url">
		                                <?php echo e(asset( 'tin-tuc/'.$data->slug )); ?>

		                            </div>
		                            <div class="google__description"><?php echo old('meta_description', isset($data->meta_description) ? $data->meta_description : ''); ?></div>
		                        </div>
		                    </div>
		                </div>
		            </div>
				</div>
				<div class="col-sm-3">
					<div class="box box-success">
		                <div class="box-header with-border">
		                    <h3 class="box-title">Đăng</h3>
		                </div>
		                <div class="box-body">
		                    <div class="form-group">
		                        <label class="custom-checkbox">
		                            <input type="checkbox" name="status" value="1" <?php echo e(@$data->status == 1 ? 'checked' : null); ?>> Hiển thị
		                        </label>
		                        
	                            <label class="custom-checkbox">
	                                <input type="checkbox" name="hot" value="1" <?php echo e(@$data->hot == 1 ? 'checked' : null); ?>> Nổi bật
	                            </label>
		                       
		                    </div>
		                    <div class="form-group text-right">
		                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Lưu lại</button>
		                    </div>
		                </div>
		            </div>
		            <div class="box box-success">
		                <div class="box-header with-border">
		                    <h3 class="box-title">Ảnh đại diện</h3>
		                </div>
		                <div class="box-body">
		                    <div class="form-group" style="text-align: center;">
		                        <div class="image">
		                            <div class="image__thumbnail">
		                                <img src="<?php echo e(!empty($data->image) ? $data->image : __IMAGE_DEFAULT__); ?>"
		                                     data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
		                                <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
		                                    <i class="fa fa-times"></i></a>
		                                <input type="hidden" value="<?php echo e(old('image', @$data->image)); ?>" name="image"/>
		                                <div class="image__button" onclick="fileSelect(this)">
		                                	<i class="fa fa-upload"></i>
		                                    Upload
		                                </div>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>
				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script>
		jQuery(document).ready(function($) {
			$('#btn-ok').click(function(event) {
		        var slug_new = $('#new-post-slug').val();
		        var name = $('#name').val();
		        $.ajax({
		        	url: '<?php echo e(route('posts.get-slug')); ?>',
		        	type: 'GET',
		        	data: {
		        		id: $('#idPost').val(),
		        		slug : slug_new.length > 0 ? slug_new : name,
		        	},
		        })
		        .done(function(data) {
		        	$('#change_slug').show();
			        $('#btn-ok').hide();
			        $('.cancel.button-link').hide();
			        $('#current-slug').val(data);
		        	cancelInput(data);
		        })
		    });
		});	
	</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/backend/posts/edit.blade.php ENDPATH**/ ?>