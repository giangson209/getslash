<div class="slide-header">
    <?php $products_viewed = \App\Models\Products::whereIn('id', session('product_viewed'))->get(); ?>
    <?php if(count($products_viewed)): ?>
        <?php $__currentLoopData = $products_viewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="item">
                <div class="avarta">
                    <a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>">
                        <img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" alt="<?php echo e($item->name); ?>">
                    </a>
                </div>
                <div class="info text-center">
                    <h3><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
                    <?php if(!is_null($item->sale_price)): ?>
                        <div class="price"><?php echo e(number_format($item->sale_price,0, '.', '.')); ?>đ</div>
                        <del><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</del>
                    <?php else: ?>
                        <div class="price"><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/teamplate/parts-header/products-viewed.blade.php ENDPATH**/ ?>