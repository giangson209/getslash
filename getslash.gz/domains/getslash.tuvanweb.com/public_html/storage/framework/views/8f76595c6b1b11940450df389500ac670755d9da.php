<?php 
	$vote_info = getListStarProduct($data);
 	$averageVote = getStarProduct($data);
 ?>
<div class="info-rait">
	<div class="row">
		<div class="col-md-5">
			<div class="left">
				<div class="numb-rait">
					<?php if($averageVote > 0): ?>
						<span><?php echo e($averageVote); ?></span>
						<?php for($i = 1; $i <= round($averageVote); $i++): ?>
							<i class="fa fa-star"></i>
						<?php endfor; ?>
						<?php for($i = 0; $i < 5- round($averageVote); $i++): ?>
							<i class="fa fa-star-o"></i>
						<?php endfor; ?>
						<label for=""><?php echo e(@$vote_info['all']['total_vote']); ?> đánh giá</label>
					<?php endif; ?>
				</div>
				<div class="list-review">
					<div class="item">
						<div class="nb" data-star="5">5 <i class="fa fa-star"></i></div>
						<div class="line"><div class="per" style="width: <?php echo e(number_format($vote_info['5']['percent'])); ?>%"></div></div>
						<div class="percent"><?php echo e(number_format($vote_info['5']['percent'])); ?>%<span> | <?php echo e(number_format($vote_info['5']['total_vote'])); ?> đánh giá</span></div>
					</div>
					<div class="item">
						<div class="nb" data-star="4">4 <i class="fa fa-star"></i></div>
						<div class="line"><div class="per" style="width:<?php echo e(number_format($vote_info['4']['percent'])); ?>%"></div></div>
						<div class="percent"><?php echo e(number_format($vote_info['4']['percent'])); ?>%<span> | <?php echo e(number_format($vote_info['4']['total_vote'])); ?> đánh giá</span></div>
					</div>
					<div class="item">
						<div class="nb" data-star="3">3 <i class="fa fa-star"></i></div>
						<div class="line"><div class="per" style="width: <?php echo e(number_format($vote_info['3']['percent'])); ?>%"></div></div>
						<div class="percent"><?php echo e(number_format($vote_info['3']['percent'])); ?>%<span> | <?php echo e(number_format($vote_info['3']['total_vote'])); ?> đánh giá</span></div>
					</div>
					<div class="item">
						<div class="nb" data-star="2">2 <i class="fa fa-star"></i></div>
						<div class="line"><div class="per" style="width: <?php echo e(number_format($vote_info['2']['percent'])); ?>%"></div></div>
						<div class="percent"><?php echo e(number_format($vote_info['2']['percent'])); ?>%<span> | <?php echo e(number_format($vote_info['2']['total_vote'])); ?> đánh giá</span></div>
					</div>
					<div class="item">
						<div class="nb" data-star="1">1 <i class="fa fa-star"></i></div>
						<div class="line"><div class="per" style="width: <?php echo e(number_format($vote_info['1']['percent'])); ?>%"></div></div>
						<div class="percent"><?php echo e(number_format($vote_info['1']['percent'])); ?>%<span> | <?php echo e(number_format($vote_info['1']['total_vote'])); ?> đánh giá</span></div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-7">
			<div class="right">
				<div class="tieuchi">
					<div class="title-tieuchi">Theo tiêu chí (<?php echo e(!empty($data->vote_question) ? $data->vote_question : 0); ?> đánh giá)</div>
					<div class="list-tieuchi">
						<?php if(count($data->ProductQuestions()->order()->get())): ?>
    						<?php $__currentLoopData = $data->ProductQuestions()->order()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item">
									<p><?php echo e($item->content); ?></p>
									<div class="bar-tc">
										<div class="co"><?php echo e(getPercentVoteYesQuestions($item)); ?>% <span>Có</span></div>
										<div class="line"><div class="per" style="width: <?php echo e(getPercentVoteYesQuestions($item)); ?>%"></div></div>
										<div class="khong"><?php echo e(getPercentVoteNoQuestions($item)); ?>% <span>Không</span></div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\hungphu\resources\views/frontend/pages/products/parts/reviews-customers.blade.php ENDPATH**/ ?>