<footer class="c-footer">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4">
                <a class="navbar-brand" href="<?php echo e(asset('/')); ?>">
                    <img src="<?php echo e(@$site_info->logo); ?>" />
                    <a href="<?php echo e(@$site_info->link_bct); ?>"><span class="bct d-none"><img src="<?php echo e(@$site_info->logo_bct); ?>" /></span></a>
                </a>

                <h2 class="slogan">
                  <?php echo @$site_info->footer->desc1; ?>

                </h2>
                <p class="description">
                  <?php echo @$site_info->footer->desc2; ?>

                </p>
                <div class="social-top d-none">
                    <div class="social">
                        <?php if(!empty(@$site_info->social)): ?> <?php $__currentLoopData = @$site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($value->link); ?>" target="_blank"><img src="<?php echo e($value->icon); ?>" /></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-12 col-lg-8">
                <div class="link-fter">
                    <div class="row">
                        <div class="col-12 col-md-3 col-lg-3">
                            <h3 class="title-nav"><?php echo e(@$site_info->field1); ?> <img src="<?php echo e(__BASE_URL__); ?>/images/ar-blue.svg" class="img-fluid d-none" alt="" /></h3>
                            <ul class="nav">
                                <?php if(isset($menuMain[4])): ?>
                                <?php $__currentLoopData = $menuMain[4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item"><a href="<?php echo e($value->url); ?>" class="nav-link"><?php echo e($value->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="col-12 col-md-3 col-lg-3">
                            <h3 class="title-nav"><?php echo e(@$site_info->field2); ?> <img src="<?php echo e(__BASE_URL__); ?>/images/ar-blue.svg" class="img-fluid d-none" alt="" /></h3>
                            <ul class="nav">
                                <?php if(isset($menuMain[5])): ?>
                                <?php $__currentLoopData = $menuMain[5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item"><a href="<?php echo e($value->url); ?>" class="nav-link"><?php echo e($value->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="col-12 col-md-3 col-lg-3">
                            <h3 class="title-nav"><?php echo e(@$site_info->field3); ?> <img src="<?php echo e(__BASE_URL__); ?>/images/ar-blue.svg" class="img-fluid d-none" alt="" /></h3>
                            <ul class="nav">
                                <?php if(isset($menuMain[6])): ?>
                                <?php $__currentLoopData = $menuMain[6]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item"><a href="<?php echo e($value->url); ?>" class="nav-link"><?php echo e($value->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="col-12 col-md-3 col-lg-3">
                            <h3 class="title-nav"><?php echo e(@$site_info->field4); ?> <img src="<?php echo e(__BASE_URL__); ?>/images/ar-blue.svg" class="img-fluid d-none" alt="" /></h3>
                            <ul class="nav">
                                <?php
                                    $tang = 1
                                ?>
                                <?php if(isset($menuMain[7])): ?>
                                <?php $__currentLoopData = $menuMain[7]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item"><a href="<?php echo e($value->url); ?>" class="nav-link" data-bs-toggle="modal" data-bs-target="#modal-qrcode-<?php echo e($tang); ?>"><?php echo e($value->title); ?></a></li>
                                <?php
                                    $tang++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>

                            <div class="popup-header">
                                <div class="modal fade box-modal-head" id="modal-qrcode-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="content-popup-qr">
                                                    <div class="close-popup">
                                                        <a href="javascript:void(0)" data-bs-dismiss="modal"><img src="<?php echo e(__BASE_URL__); ?>/images/close.svg" class="img-fluid" alt="<?php echo e(@$site_info->popup->title); ?>" /></a>
                                                    </div>
                                                    <div class="row align-items-center">
                                                        <div class="col-lg-6">
                                                            <div class="avr-modal"><img src="<?php echo e(__BASE_URL__); ?>/images/qq-1.png" class="img-fluid w-100" alt="<?php echo e(@$site_info->popup->title); ?>" /></div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="info-modal-qr">
                                                                <h6><?php echo e(@$site_info->popup->title); ?></h6>
                                                                <div class="desc">
                                                                    <?php echo e(@$site_info->popup->desc); ?>

                                                                </div>
                                                                <div class="note-modal"><img src="<?php echo e(__BASE_URL__); ?>/images/footer-03.png" class="img-fluid" alt="" /></div>
                                                                <div class="apps-modal">
                                                                    <div class="left">
                                                                        <div class="avr-qr"><img src="<?php echo e(__BASE_URL__); ?>/images/qr-1-1.png" class="img-fluid" alt="Tải app ngay" /></div>
                                                                    </div>
                                                                    <div class="right">
                                                                        <ul> 
                                                                            <li><a href="<?php echo e(@$site_info->chung_link_ios); ?>" target="_blank"><img src="<?php echo e(@$site_info->chung_logo_ios); ?>" class="img-fluid"  alt="Tải app ngay" /></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade box-modal-head" id="modal-qrcode-2">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="content-popup-qr">
                                                    <div class="close-popup">
                                                        <a href="javascript:void(0)" data-bs-dismiss="modal"><img src="<?php echo e(__BASE_URL__); ?>/images/close.svg" class="img-fluid" alt="<?php echo e(@$site_info->popup->title); ?>" /></a>
                                                    </div>
                                                    <div class="row align-items-center">
                                                        <div class="col-lg-6">
                                                            <div class="avr-modal"><img src="<?php echo e(__BASE_URL__); ?>/images/qq-2.png" class="img-fluid w-100" alt="<?php echo e(@$site_info->popup->title); ?>" /></div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="info-modal-qr">
                                                                <h6><?php echo e(@$site_info->popup->title); ?></h6>
                                                                <div class="desc">
                                                                    <?php echo e(@$site_info->popup->desc); ?>

                                                                </div>
                                                                <div class="note-modal"><img src="<?php echo e(__BASE_URL__); ?>/images/footer-03.png" class="img-fluid" alt="" /></div>
                                                                <div class="apps-modal">
                                                                    <div class="left">
                                                                        <div class="avr-qr"><img src="<?php echo e(__BASE_URL__); ?>/images/qr-1-1.png" class="img-fluid" alt="Tải app ngay" /></div>
                                                                    </div>
                                                                    <div class="right">
                                                                        <ul>
                                                                            <li><a href="<?php echo e(@$site_info->chung_link_chplay); ?>" target="_blank"><img src="<?php echo e(@$site_info->chung_logo_chplay); ?>" class="img-fluid"  alt="Tải app ngay" /></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="bot-social">
                    <div class="left">
                        <div class="social mt-0">
                          <?php if(!empty(@$site_info->social)): ?> <?php $__currentLoopData = @$site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="<?php echo e($value->link); ?>" target="_blank"><img src="<?php echo e($value->icon); ?>" /></a>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                        </div>
                    </div>
                    <div class="right">
                      <a href="<?php echo e(@$site_info->link_bct); ?>"><img src="<?php echo e(@$site_info->logo_bct); ?>" /></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">
            <div class="content">© 2021 Slash. All rights reserved | Designed by <a href="http://pitstudio.co/" target="_blank">Pit Studio</a></div>
            <ul class="nav nav-copyright">
              <?php if(!empty(@$site_info->linkbottom)): ?>
                  <?php $__currentLoopData = @$site_info->linkbottom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item"><a href="<?php echo e($value->link); ?>" class="nav-item"><?php echo e($value->title); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </ul>
        </div>
    </div>
</footer>
<!-- footer end -->
<?php /**PATH /home/slash/domains/getslash.tuvanweb.com/public_html/resources/views/frontend/teamplate/footer.blade.php ENDPATH**/ ?>