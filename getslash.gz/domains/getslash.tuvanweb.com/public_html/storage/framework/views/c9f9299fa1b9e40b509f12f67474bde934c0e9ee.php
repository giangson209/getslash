<section id="breadcrumbs">
	<div class="avarta">
		<img src="<?php echo e(!empty($config['banner']) ? $config['banner'] : __BASE_URL__.'/images/bread.png'); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$title); ?>">
	</div>
	<div class="info">
		<div class="container">
			<div class="content text-center">
				<h2 class="text-uppercase"><?php echo e(@$config['title']); ?></h2>
				<ul class="list-inline">
					<li class="list-inline-item">
						<a href="<?php echo e(url('/')); ?>" title="Trang chủ">Trang chủ</a>
					</li>
					<li class="list-inline-item">
						<a href="javascript:0"><?php echo e(@$config['title']); ?></a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/teamplate/breadcrumbs.blade.php ENDPATH**/ ?>