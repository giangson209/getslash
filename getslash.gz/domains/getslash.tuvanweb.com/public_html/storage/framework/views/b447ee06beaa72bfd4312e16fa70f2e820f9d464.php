<?php $__env->startSection('controller',''); ?>
<?php $__env->startSection('controller_route', route('backend.home')); ?>
<?php $__env->startSection('action',''); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
		<div class="row">

			<div class="col-md-3 col-sm-6 col-xs-12">
		        <div class="info-box bg-green">
		            <span class="info-box-icon"><i class="fa fa-bookmark-o"></i></span>

		            <div class="info-box-content">
		                <span class="info-box-text">Đơn hàng</span>
		                <span class="info-box-number"><?php echo e(\App\Models\Orders::count()); ?> Đơn hàng</span>

		                <div class="progress">
		                    <div class="progress-bar" style="width: 70%"></div>
		                </div>
		                <span class="progress-description">
		                    <a href="<?php echo e(route('order.index')); ?>" style="color: #fff">Xem chi tiết</a>
		                </span>
		            </div>
		        </div>
		    </div>

		    <div class="col-md-3 col-sm-6 col-xs-12">
		        <div class="info-box bg-red">
		            <span class="info-box-icon"><i class="fa fa-bookmark-o"></i></span>

		            <div class="info-box-content">
		                <span class="info-box-text">Sản phẩm</span>
		                <span class="info-box-number"><?php echo e(\App\Models\Products::count()); ?> Sản phẩm</span>

		                <div class="progress">
		                    <div class="progress-bar" style="width: 70%"></div>
		                </div>
		                <span class="progress-description">
		                    <a href="<?php echo e(route('products.index')); ?>" style="color: #fff">Xem chi tiết</a>
		                </span>
		            </div>
		        </div>
		    </div>

			
			 <div class="col-md-3 col-sm-6 col-xs-12">
		        <div class="info-box bg-green">
		            <span class="info-box-icon"><i class="fa fa-bookmark-o"></i></span>

		            <div class="info-box-content">
		                <span class="info-box-text">Bài viết</span>
		                <span class="info-box-number"><?php echo e(\App\Models\Posts::count()); ?> bài viết</span>

		                <div class="progress">
		                    <div class="progress-bar" style="width: 70%"></div>
		                </div>
		                <span class="progress-description">
		                    <a href="<?php echo e(route('posts.index', [ 'type' => 'blog' ])); ?>" style="color: #fff">Xem chi tiết</a>
		                </span>
		            </div>
		        </div>
		    </div>


		     

		</div>

		<div class="row">
			<div class="col-sm-12">
				<div class="box box-primary">
		            <div class="box-body">
		            	<div class="table-translate">
					        <table class="table table-hover">
					            <thead>
					                <tr>
					                    <th width="30px">STT</th>
					                    <th width="">Tên trang</th>
					                    <th width="">Liên kết</th>
					                </tr>
					            </thead>
					            <tbody class="table-body-pro">
					                <?php $__currentLoopData = $dataPages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                    <tr>
					                        <td><?php echo e($loop->index + 1); ?></td>
					                        <td><?php echo e($item->name_page); ?></td>
					                        <td>
					                            <?php if(\Route::has($item->route)): ?>
					                                <a href="<?php echo e(route($item->route)); ?>" target="_blank">
					                                    <i class="fa fa-hand-o-right" aria-hidden="true"></i>
					                                    Link: <?php echo e(route($item->route)); ?>

					                                </a>
					                            <?php else: ?>
					                            	---------------
					                            <?php endif; ?>
					                        </td>
					                    </tr>
					                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					            </tbody>
					        </table>
					    </div>
		            </div>
		        </div>
	        </div>
		</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/vongtay/resources/views/backend/home.blade.php ENDPATH**/ ?>