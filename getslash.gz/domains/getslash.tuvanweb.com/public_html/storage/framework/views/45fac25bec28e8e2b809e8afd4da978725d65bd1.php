<?php $__env->startSection('main'); ?>
    <section class="banner">
        <div class="slider-banner not-arrow not-dots">
            <?php if(!empty($content->banner)): ?>
                <?php $__currentLoopData = $content->banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slider-item relative">
                        <img src="<?php echo e($value->banner); ?>" alt="">
                        <div class="banner-text">
                            <div class="container">
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <h2 class="font-oswald"><?php echo e($value->name); ?></h2>
                                        <p><?php echo e($value->desc); ?></p>
                                        <a href="<?php echo e($value->link); ?>" title="" class="btn btn-white">Xem thêm</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </section>
    <section class="about-index pd-60">
        <div class="container">
            <h2 class="title title-lg">Giới thiệu</h2>
            <div class="article">
                <div class="row">
                    <div class="col-md-5">
                        <?php echo @$content->about->col_1; ?>

                    </div>
                    <div class="col-md-5 offset-md-2">
                        <?php echo @$content->about->col_2; ?>

                    </div>
                </div>
            </div>
            <a href="<?php echo @$content->about->link; ?>" title="" class="btn btn-black mgt-30">Xem thêm</a>
        </div>
    </section>
    <section class="banner-ads"><a href="<?php echo @$content->about->link; ?>" title=""><img src="<?php echo e(@$content->about->banner); ?>" alt=""> </a> </section>

    <section class="products pd-60">
        <div class="container">
            <div class="products-nav flex-center-between">
                <h2 class="title title-lg">sản phẩm</h2>
                <a href="<?php echo e(route('home.list.product')); ?>" title="" class="font-oswald text-blue">Tất cả sản phẩm</a>
            </div>
            <div class="products-block">
                <div class="row">
                    <?php $__currentLoopData = $productHot ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <div class="products-item">
                                <h4 class="pro-name"><a href="<?php echo e($item->url); ?>" title=""><?php echo e($item->name); ?></a> </h4>
                                <div class="price">
                                    <?php if(!empty($item->sale)): ?>
                                        <span class="new-price"><?php echo e(number_format($item->sale_price, 0, '.','.')); ?> VND</span>
                                        <span class="old-price"><?php echo e(number_format($item->regular_price, 0, '.','.')); ?> VND</span>
                                    <?php else: ?>
                                        <span class="new-price"><?php echo e(number_format($item->regular_price, 0, '.','.')); ?> VND</span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo e($item->url); ?>" class="pro-image zoom" title="">
                                    <img src="<?php echo e($item->image); ?>" alt="">
                                </a>
                                <div class="text-center"><a href="<?php echo e($item->add_cart_url); ?>" title="" class="btn btn-blue mgt-30">Mua ngay</a></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="banner-2">
        <div class="container">
            <div class="banner-2-inner relative">
                <img src="<?php echo @$content->ads->banner; ?>" alt="">
                <div class="banner-2-text absolute">
                    <div class="row align-items-center">
                        <div class="col-md-6 offset-md-3">
                            <div class="text-center">
                                <h3><?php echo @$content->ads->title; ?></h3>
                                <p>><?php echo @$content->ads->desc; ?></p>
                                <div class="text-center"><a href="<?php echo @$content->ads->link; ?>" title="" class="btn btn-white mgt-30">Xem thêm</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="news pd-60">
        <div class="container">
            <h2 class="title title-lg">tin tức</h2>
            <div class="row">
                <?php $__currentLoopData = $postHot ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="news-item">
                            <a href="<?php echo e($item->url); ?>" title="" class="news-image zoom">
                                <img src="<?php echo e($item->image); ?>" alt="">
                            </a>
                            <div class="news-cache">
                                <h4><a href="<?php echo e($item->url); ?>" title=""><?php echo e($item->name); ?></a> </h4>
                                <div class="desc"><?php echo e($item->desc); ?></div>
                                <a href="<?php echo e($item->url); ?>" title="" class="text-blue font-oswald">Xem thêm</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\batdongsan\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>