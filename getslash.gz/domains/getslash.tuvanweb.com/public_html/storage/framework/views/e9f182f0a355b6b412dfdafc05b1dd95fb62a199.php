<div class="content">
	<div class="row">
		<div class="col-md-6">
			<div class="left">
				<div class="title-cart jose">Thông tin khách hàng</div>
				<div class="info-member">
					<div class="row">
						<?php if(count($errors) > 0): ?>
                            <div class="col-md-12">
                                <div style="margin-bottom: 15px">
                                    <div class="alert alert-danger alert-dismissible">
                                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                        <h4><i class="icon fa fa-ban"></i> Thông báo</h4>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo $error; ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <script>
                            	var elmnt = document.getElementById("check-out");
                                elmnt.scrollIntoView();
                            
                            </script>
                        <?php endif; ?>
						<div class="col-md-12">
							<div class="form-group">
								<div class="item">
									<input type="text" placeholder="Họ tên" name="name" value="<?php echo e(old('name')); ?>">
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<div class="item">
									<input type="text" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<div class="item">
									<input type="text" placeholder="Số điện thoại" name="phone" value="<?php echo e(old('phone')); ?>">
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<div class="item">
									<select name="province_id" id="province">
										<option value="">Chọn tỉnh thành</option>
										<?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($item->provinceid); ?>"><?php echo e($item->name); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<div class="item">
									<select name="district_id" id="district">
										<option value="">Quận / Huyện</option>
									</select>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<div class="item">
									<input type="text" placeholder="Địa chỉ cụ thể ( ghi rõ số nhà, ngõ, ngách)" name="address" value="<?php echo e(old('address')); ?>">
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<div class="item">
									<textarea name="content" placeholder="Nội dung" cols="30" rows="10"><?php echo e(old('content')); ?></textarea>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="right">
				<div class="title-cart jose">Phương thức thanh toán</div>
				<div class="method">
					<p data-tab="tab-method-1" class="active type" data-type="1">
					    <input type="radio" id="method-1" name="radio-group" checked>
					    <label for="method-1">Thanh toán khi nhận hàng</label>
					</p>
					<p data-tab="tab-method-2" data-type="2" class="type">
					    <input type="radio" id="method-2" name="radio-group">
					    <label for="method-2">Chuyển khoản qua thẻ ngân hàng</label>
					</p>
				</div>
				<div class="tab-method">
					<div class="item" id="tab-method-1"></div>
					<div class="item" id="tab-method-2">
						<ul class="nav nav-tabs" role="tablist">
							<?php if(count($banks)): ?>
								<?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<a class="<?php echo e($loop->index == 0 ? 'active' : null); ?> idBank" data-toggle="tab" href="#tabs-<?php echo e($loop->index); ?>" data-id="<?php echo e($item->id); ?>" 
											role="tab">
											<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($item->name); ?>">
										</a>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</ul>
						<div class="tab-content">
							<?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="tab-pane <?php echo e($loop->index == 0 ? 'active' : null); ?>" id="tabs-<?php echo e($loop->index); ?>" role="tabpanel">
									<h5>Thông tin tài khoản</h5>
									<ul>
										<li>Chủ tài khoản: <?php echo e($item->account_holder); ?></li>
										<li>Số tài khoản : <?php echo e($item->account_number); ?></li>
										<li>Chi nhánh : <?php echo e($item->branch); ?></li>
									</ul>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>

			<div class="btn-view">
				<input type="hidden" name="typePay" value="1" id="typePay">
				<input type="hidden" name="id_bank" value="<?php echo e(@$banks[0]->id); ?>" id="id_bank">
				<button type="submit">Thanh toán</button>
			</div>
		</div>
	</div>
</div><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/teamplate/cart/check-out.blade.php ENDPATH**/ ?>