
<?php $__env->startSection('main'); ?>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="Tin tức" href="<?php echo e(route('home.archive-news')); ?>">Tin tức</a></li>
					<li class="list-inline-item"><a title="<?php echo e($data->name); ?>" href="javascript:0"><?php echo e($data->name); ?></a></li>
				</ul>
			</div>
		</div>
	</section>

	<section id="news" class="pb-80">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-9">
						<div class="content-detail">
							<div class="detail">
								<div class="title-detail">
									<h1><?php echo e($data->name); ?></h1>
									<div class="date"><?php echo e($data->created_at->format('d/m/yy')); ?></div>
									<div class="desc">
										<?php echo e(@$data->desc); ?>

									</div>
								</div>
								<div class="info-detail">
									<?php echo @$data->content; ?>

								</div>
								<div class="tags">
									<ul class="list-inline">
										<li class="list-inline-item"><span>Tags: </span></li>
										<?php if(!empty($data->tags)): ?>
											<?php $__currentLoopData = $data->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li class="list-inline-item"><a href="<?php echo e(route('home.news.tags', $tag->slug)); ?>"><?php echo e($tag->name); ?></a></li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</ul>
								</div>
								<div class="like-share">
									<ul class="list-inline">
										<div class="fb-like" data-href="<?php echo e(url()->current()); ?>" data-width="" data-layout="button" data-action="like" data-size="small" data-share="true"></div>
									</ul>
								</div>
								<div class="comment pt-50">
									<div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-width="100%" data-numposts="5"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="side-news bar-detail">
							<?php echo $__env->make('frontend.teamplate.parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						</div>
					</div>
					<div class="col-md-12">
						<div class="new-other pt-50">
							<div class="title-other text-uppercase">Bài viết liên quan</div>
							<div class="new-other">
								<div class="row">
									<?php if(!empty($post_related)): ?>
										<?php $__currentLoopData = $post_related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-md-3 col-sm-3">
												<div class="item">
													<div class="avarta">
														<a title="<?php echo e(@$item->name); ?>" href="<?php echo e(route('home.post.single', @$item->slug)); ?>">
															<img data-src="<?php echo e(@$item->image); ?>" class="img-fluid lazyload" width="100%" alt="<?php echo e(@$item->name); ?>">
														</a>
													</div>
													<div class="info">
														<h3><a title="<?php echo e(@$item->name); ?>" href="<?php echo e(route('home.post.single', @$item->slug)); ?>"><?php echo e(@$item->name); ?></a></h3>
													</div>
												</div>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v6.0&appId=1620283888101801&autoLogAppEvents=1"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu2/resources/views/frontend/pages/single-news.blade.php ENDPATH**/ ?>