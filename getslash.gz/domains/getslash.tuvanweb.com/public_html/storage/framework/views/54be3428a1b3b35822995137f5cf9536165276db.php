
<?php $__env->startSection('main'); ?>
	<section id="box-new-cate" class="pt-50 pb-50">
		<div class="container">
			<?php if(count($categories)): ?>
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="box-cate">
						<div class="titl-nws">
							<h2><?php echo e($value->name); ?></h2>
							<a href="<?php echo e(route('home.post.category', $value->slug)); ?>">Xem thêm <i class="fa fa-angle-right"></i></a>
						</div>
						<div class="slide-news">
							<?php if(count($value->Posts)): ?>
								<?php $posts = $value->Posts()->active()->published()->orderBy('hot', 'desc')->orderBy('created_at', 'DESC')->take(12)->get(); ?>
								<?php if(count($posts)): ?>
									<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="item">
											<div class="avarta">
												<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>">
													<img data-src="<?php echo e($item->image); ?>" class="img-fluid w-100 lazyload" alt="<?php echo e($item->name); ?>">
												</a>
											</div>
											<div class="info">
												<div class="date-view">
													<ul class="list-inline">
														<li class="list-inline-item">
															<div class="date"><?php echo e($item->created_at->format('d/m/Y')); ?></div>
														</li>
														<li class="list-inline-item">
															<div class="view"><i class="fa fa-eye"></i><?php echo e($item->view_count); ?> lượt xem</div>
														</li>
													</ul>
												</div>
												<h3><a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h3>
												<div class="desc">
													<?php echo e($item->desc); ?>

												</div>
											</div>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script>
		$('.slide-news').slick({
		    autoplay: false,
		    arrow: true,
		    dots: false,
		    slidesToShow: 4,
		    slidesToScroll: 1, 
		    prevArrow: '<button class="prev" href="javascript:0"><i class="fa fa-chevron-left"></i></button>',
		    nextArrow: '<button class="next" href="javascript:0"><i class="fa fa-chevron-right"></i></button>',
		    responsive: [
		        {
		            breakpoint: 767,
		            settings: {
		                slidesToShow: 4,
		            }
		        },
		        {
		            breakpoint: 480,
		            settings: {
		                slidesToShow: 2,
		            }
		        }
		    ]
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bephungphu/public_html/resources/views/frontend/pages/archives-news.blade.php ENDPATH**/ ?>