
<?php $__env->startSection('main'); ?>
	<section id="breadcrumbs">
		<div class="avarta"><img src="<?php echo e(__BASE_URL__); ?>/images/bread.png" class="img-fluid" width="100%" alt="<?php echo e($data->name); ?>"></div>
		<div class="info">
			<div class="container text-center">
				<h2 class="text-uppercase">Tin tức</h2>
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ <span>/</span></a></li>
					<li class="list-inline-item"><a title="Tin tức" href="<?php echo e(route('home.posts')); ?>">Tin tức <span>/</span></a></li>
					<li class="list-inline-item"><a title="" href="javascript:0"><?php echo e($data->name); ?></a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="detail-content" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-9">
						<div class="detail">
							<div class="title-detail">
								<h1><?php echo e($data->name); ?></h1>
								<div class="date"><?php echo e($data->created_at->format('d/m/yy')); ?></div>
								<div class="desc"><?php echo e($data->desc); ?></div>
							</div>
							<div class="info-detail">
								<?php echo $data->content; ?>

							</div>
							<div class="comment">
								<div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-width="100%" data-numposts="5"></div>
							</div>
							<div class="other-news pt-100">
								<div class="title text-uppercase"><h2>Bài viết liên quan</h2></div>
								<div class="list-news slide-new-other">
									<div class="row">
										<?php if(count($related_posts)): ?>
											<?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="col-md-3">
													<?php $__env->startComponent('frontend.components.post', ['item' => $item]); ?> <?php echo $__env->renderComponent(); ?>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="side-bar">
							<div class="box-bar">
								<div class="title-bar">Tin tức mới nhất</div>
								<?php if(!empty($post_news)): ?>
									<?php $__currentLoopData = $post_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php $__env->startComponent('frontend.components.side-bar', ['item' => $item, 'type' => 'news' ]); ?> <?php echo $__env->renderComponent(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</div>
							<div class="box-bar">
								<div class="bn-bar">
									<a href="<?php echo e(@$site_info->side_bar->news->link_1); ?>" title="<?php echo e(@$site_info->side_bar->news->title_1); ?>">
									<img src="<?php echo e(@$site_info->side_bar->news->banner_1); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$site_info->side_bar->news->title_1); ?>">
									</a>
								</div>
							</div>
							<div class="box-bar">
								<div class="bn-bar">
									<a href="<?php echo e(@$site_info->side_bar->news->link_2); ?>" title="<?php echo e(@$site_info->side_bar->news->title_2); ?>">
									<img src="<?php echo e(@$site_info->side_bar->news->banner_2); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$site_info->side_bar->news->title_2); ?>">
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script>
		jQuery(document).ready(function($) {
			$('.news_menu').addClass('active');
		});
	</script>
	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v6.0&appId=1620283888101801&autoLogAppEvents=1"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/bacviet/resources/views/frontend/pages/single-news.blade.php ENDPATH**/ ?>