<?php if(count($list_brands)): ?>
	<?php $__currentLoopData = $list_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-2">
			<div class="item text-center">
				<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.brand', $item->slug)); ?>">
					<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" alt="<?php echo e($item->name); ?>">
				</a>
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\hungphu\resources\views/frontend/components/loop-brand.blade.php ENDPATH**/ ?>