<div class="amblog-item">
	<div class="amblog-photo">
		<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom">
			<img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>" title="<?php echo e($item->name); ?>">
		</a>
	</div>
	<p class="amblog-date"><?php echo e($item->created_at->format('d/m/Y')); ?></p>
	<h4 class="amblog-name"><a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h4>
	<p class="amblog-short"><?php echo e($item->desc); ?></p>
	<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" class="view-detail" title="">Chi tiết</a>
</div><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/frontend/components/content-news.blade.php ENDPATH**/ ?>