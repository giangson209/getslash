<?php $__env->startSection('main'); ?>
    <section class="banner">
        <div class="slide-banner">
            <div class="item-banner">
                <div class="avarta"><img src="<?php echo e(!empty($dataSeo->banner) ? $dataSeo->banner : __BASE_URL__.'/images/bn-about.jpg'); ?>" class="img-fluid w-100" alt=""></div>
                <div class="caption">
                    <div class="container">
                        <h3 class="text-uppercase "><?php echo e(@$dataSeo->content->name); ?></h3>
                        <h1><?php echo e(@$dataSeo->content->desc); ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="box-number">
        <div class="container">
            <div class="list-number">
                <div class="row">
                    <?php if(!empty(@$dataSeo->content->summary)): ?>
                        <?php $__currentLoopData = @$dataSeo->content->summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="item-number text-center">
                                    <div class="numb"><?php echo e(@$value->title); ?></div>
                                    <div class="desc"><?php echo e(@$value->desc); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <section class="box-about">
        <div class="container">
            <div class="list-about">
                <?php if(!empty(@$dataSeo->content->main_content)): ?>
                    <?php $__currentLoopData = @$dataSeo->content->main_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item-about">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="left">
                                        <h2><?php echo e(@$value->title); ?></h2>
                                        <h3><?php echo e(@$value->sub_title); ?></h3>
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <div class="desc">
                                        <?php echo @$value->content; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section class="box-partner">
        <div class="avarta">
            <img src="<?php echo e(__BASE_URL__); ?>/images/partner.jpg" class="img-fluid w-100" alt="">
            <div class="title">
                <div class="container">
                    <h4 class="text-uppercase"><?php echo e(@$dataSeo->content->jobs->title); ?></h4>
                    <h2><?php echo e(@$dataSeo->content->jobs->sub_title); ?></h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="list-service">
                <div class="row">
                    <?php if(!empty(@$dataSeo->content->jobs->list)): ?>
                        <?php $__currentLoopData = @$dataSeo->content->jobs->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="item-service text-center">
                                    <div class="icon"><img src="<?php echo e(@$value->icon); ?>" class="img-fluid" alt=""></div>
                                    <div class="desc-srv">
                                        <h3><?php echo e(@$value->name); ?></h3>
                                        <div class="desc"><?php echo e(@$value->desc); ?></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
   <?php echo $__env->make('frontend.pages.contact.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bestay\resources\views/frontend/pages/about/index.blade.php ENDPATH**/ ?>