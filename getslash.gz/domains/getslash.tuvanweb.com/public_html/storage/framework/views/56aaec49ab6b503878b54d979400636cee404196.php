
<?php $__env->startSection('main'); ?>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="Sản phẩm" href="<?php echo e(route('home.list.product')); ?>">Sản phẩm</a></li>
					<li class="list-inline-item"><a title="Sản phẩm" href="<?php echo e(route('home.archive.product', $data->category[0]->slug)); ?>"><?php echo e($data->category[0]->name); ?></a></li>
					<li class="list-inline-item"><a title="" href="javascript:0"><?php echo e($data->name); ?></a></li>
				</ul>
			</div>
		</div>
	</section>

	<section id="preview" class="pt-20">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="left">
							<div class="slide-thumbs">
								<div class="slider-for">
                                    <div class="carousel-item">
                                    	<a title="<?php echo e($data->name); ?>" href="<?php echo e($data->image); ?>" data-fancybox="group" class ="lightbox" data-fancybox="lib-1">
                                    		<img src="<?php echo e($data->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($data->name); ?>">
                                    	</a>
                                    </div>
                                    <?php if(count($data->ProductImage()->where('type', 'more_image_product')->get())): ?>
                                    	<?php $__currentLoopData = $data->ProductImage()->where('type', 'more_image_product')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    		<div class="carousel-item">
		                                    	<a title="<?php echo e($data->name); ?>" href="<?php echo e($item->image); ?>" data-fancybox="group" class ="lightbox" data-fancybox="lib-1">
		                                    		<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($data->name); ?>">
		                                    	</a>
		                                    </div>
                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="slider-nav">
                                     <div class="clc">
                                     	<img class="" src="<?php echo e($data->image); ?>" width="100%" alt="<?php echo e($data->name); ?>">
                                     </div>
                                     <?php if(count($data->ProductImage()->where('type', 'more_image_product')->get())): ?>
                                    	<?php $__currentLoopData = $data->ProductImage()->where('type', 'more_image_product')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="clc">
		                                     	<img class="" src="<?php echo e($item->image); ?>" width="100%" alt="<?php echo e($data->name); ?>">
		                                     </div>
                                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<form action="<?php echo e(route('home.post-add-cart')); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<div class="info-preview">
								<h1><?php echo e($data->name); ?></h1>
								<div class="price">
									<?php $price = 0; ?>
									<?php if(!is_null($data->sale_price)): ?>
										<?php $price = $data->sale_price; ?>
										<span id="text-price"><?php echo e(number_format($data->sale_price,0, '.', '.')); ?>VNĐ</span> 
										<del id="regular_price" data-regularprice="<?php echo e($data->regular_price); ?>" >
											<?php echo e(number_format($data->regular_price,0, '.', '.')); ?>VNĐ
										</del>
									<?php else: ?>
										<?php $price = $data->regular_price; ?>
										<span id="text-price"><?php echo e(number_format($data->regular_price,0, '.', '.')); ?>VNĐ</span>
									<?php endif; ?>
									
								</div>
								<div class="code">Mã sản phẩm: <span><?php echo e($data->sku); ?></span></div>
								<div class="style">
									<p><?php echo e($data->title_attributes); ?></p>
									<?php if(!empty($data->products_version)): ?>
										<?php $products_version = json_decode( $data->products_version );  ?>
										<div class="src-style">
											<ul>
												<?php $__currentLoopData = $products_version; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li>
														<input type="radio" id="style-<?php echo e($loop->index + 1); ?>" name="radio-group" <?php echo e($loop->index == 0 ? 'checked' : null); ?> 
														class="options-radio" data-value="<?php echo e($price + @$value->value); ?>" data-text="<?php echo e(number_format($price + @$value->value, 0, '.', '.')); ?>VNĐ"
														data-difference="<?php echo e(@$value->value); ?>" data-name="<?php echo e(@$value->name); ?>">
														<label for="style-<?php echo e($loop->index + 1); ?>"><span><?php echo e(@$value->name); ?></span><?php echo e(number_format($price + @$value->value, 0, '.', '.')); ?>vnđ</label>
													</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												
											</ul>
										</div>

									<?php endif; ?>
								</div>

								<?php if($data->CheckApplyGift()): ?>
									<div class="box-sale">
										<div class="titl-sale">
											<h4><?php echo e($data->title_desc_gift); ?></h4>
											<span>Áp dụng dự kiến đến <?php echo e(\Carbon\Carbon::parse($data->end_date_apply_gift)->format('d/m/yy')); ?></span>
										</div>
										<div class="info-box">
											<?php if(!empty($data->content_gift)): ?>
												<?php $content_gift = json_decode( $data->content_gift ); ?>
												<?php $__currentLoopData = $content_gift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<p><span><?php echo e($loop->index + 1); ?></span><?php echo e($value->title); ?></p>
													<input type="hidden" value="<?php echo e($value->title); ?>" name="gift[]">
													<?php $indexParent = $loop->index; ?>
													<?php if(!empty($value->value)): ?>
														<?php $options_gift = explode('|', $value->value) ?>
														<ul>
															<?php $__currentLoopData = $options_gift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																<li>
																	<input type="radio" id="sale-<?php echo e($loop->index + 1); ?>-<?php echo e($indexParent); ?>" name="radiosale[<?php echo e($indexParent); ?>]" <?php echo e($loop->index == 0 ? 'checked' : null); ?>

																	value="<?php echo e($item); ?> ">
																	<label for="sale-<?php echo e($loop->index + 1); ?>-<?php echo e($indexParent); ?>"><?php echo e($item); ?></label>
																</li>
															<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</ul>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</div>
									</div>
								<?php endif; ?>
								<div class="quantity-cart">
									<ul class="list-inline">
										<li class="list-inline-item">
											<div class="quatity">
												<span>Số lượng</span>
												<div class="number-spinner">
													<span class="ns-btn">
			                                            <a data-dir="dwn"><span class="icon-minus">-</span></a>
			                                        </span>
			                                        <input type="text" class="pl-ns-value" value="1" maxlength="5" readonly name="qty">
			                                        <span class="ns-btn">
			                                            <a data-dir="up"><span class="icon-plus">+</span></a>
			                                        </span>
			                                    </div>
											</div>
										</li>
										<li class="list-inline-item">
											<div class="add-cart">
												<button type="submit">Thêm vào giỏ hàng <i class="fa fa-shopping-cart"></i></button>
											</div>
										</li>
									</ul>
								</div>
							</div>

							<input type="hidden" id="id_price_base" value="<?php echo e(@$price); ?>">
							<input type="hidden" id="id_price" name="price" value="<?php echo e(@$price); ?>">
							<?php $first_attributes = null; ?>
							<?php if(!empty($attributes)): ?>
								<?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($loop->index == 0): ?>
										<?php $first_attributes = $value->name ?>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
							<input type="hidden" id="attributes_products" name="attributes" value="<?php echo e($first_attributes); ?>">
							<input type="hidden" name="id_product" value="<?php echo e($data->id); ?>">
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="product-detail" class="pt-50">
		<div class="container">
			<div class="content">
				<div class="detail">
					<ul class="nav nav-tabs" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" data-toggle="tab" href="#tabs-2" role="tab">Thông số sản phẩm</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" data-toggle="tab" href="#tabs-1" role="tab">Chi tiết sản phẩm</a>
						</li>
					</ul>
					<div class="tab-content" style="background: #fafafa;">
						<div class="tab-pane" id="tabs-1" role="tabpanel">
							<div class="info-detail info-detail-prd">
								<?php echo $data->content; ?>

							</div>
						</div>
						<div class="tab-pane active" id="tabs-2" role="tabpanel">
							<div class="info-detail info-detail-prd">
								<?php echo $data->specifications; ?>

							</div>
						</div>
						<div class="load-detail text-center pt-50">
							<a title="" href="javascript:0">Đọc thêm</a>
						</div>
					</div>
				</div>
				<div class="rait pt-80">
					<div class="title-rait">
						<div class="row">
							<div class="col-md-8 col-sm-8">
								<h2>Đánh giá <?php echo e($data->name); ?></h2>
							</div>
							<div class="col-md-4 col-sm-4">
								<div class="btn-rait text-right"><a title="" href="javascript:0" class="text-uppercase" data-toggle="modal" data-target="#myModal-dg">Đánh giá ngay</a></div>
							</div>
						</div>
					</div>

					<?php echo $__env->make('frontend.pages.products.parts.reviews-customers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					<?php echo $__env->make('frontend.pages.products.parts.images-reviews-customers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
					<?php echo $__env->make('frontend.pages.products.parts.list-comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					
				</div>
			</div>
		</div>
		<?php echo $__env->make('frontend.pages.products.parts.modal-reviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</section>
	
	<?php if(count($product_same_category)): ?>
		<section class="favorite pt-50 pb-80">
			<div class="container">
				<div class="content">
					<h4>Sản phẩm cùng loại</h4>
					<div class="list-product slide-frv" style="background: #fff;">
					
						<?php $__currentLoopData = $product_same_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__env->startComponent('frontend.components.product', ['item'=> $item]); ?>
						    
							<?php echo $__env->renderComponent(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript" src="<?php echo e(asset('public/vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
	<?php echo $jsValidatorReviews->selector('#formsreviews'); ?>


	<script>
		function currencyFormat(num) {
		  return num.toFixed(0).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.')
		}
	</script>
	<script>
		jQuery(document).ready(function($) {
			$('.options-radio').click(function(event) {
				$('#id_price').val($(this).data('value'));
				$('#text-price').text($(this).data('text'));
				$('#attributes_products').val($(this).data('name'));
				<?php if(!empty($data->sale_price)): ?>
					var base_regular_price = parseInt($('#regular_price').data('regularprice'));
					var value_difference = parseInt($(this).data('difference'));
					$('#regular_price').text(currencyFormat(base_regular_price+value_difference)+'VNĐ');
				<?php endif; ?>
			});
		});


		var numberSpinner = (function() {
		  $('.number-spinner>.ns-btn>a').click(function() {
		    var btn = $(this),
		      oldValue = btn.closest('.number-spinner').find('input').val().trim(),
		      newVal = 0;

		    if (btn.attr('data-dir') === 'up') {
		      newVal = parseInt(oldValue) + 1;
		    } else {
		      if (oldValue > 1) {
		        newVal = parseInt(oldValue) - 1;
		      } else {
		        newVal = 1;
		      }
		    }
		    btn.closest('.number-spinner').find('input').val(newVal);
		  });
		  $('.number-spinner>input').keypress(function(evt) {
		    evt = (evt) ? evt : window.event;
		    var charCode = (evt.which) ? evt.which : evt.keyCode;
		    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		      return false;
		    }
		    return true;
		  });
		})();
		
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/frontend/pages/products/single-product.blade.php ENDPATH**/ ?>