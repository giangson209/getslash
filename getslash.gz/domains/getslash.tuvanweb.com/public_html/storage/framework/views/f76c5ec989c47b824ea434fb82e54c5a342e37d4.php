<header>
    <div class="header-top">
        <div class="container">
            <div class="content" style="position: relative;">
                <div class="row">
                    <div class="col-md-4">
                        <div class="logo">
                        	<a title="<?php echo e(@$site_info->site_title); ?>" href="<?php echo e(url('/')); ?>">
                        		<img src="<?php echo e(@$site_info->logo); ?>" class="img-fluid" alt="<?php echo e(@$site_info->site_title); ?>">
                        	</a>
                        </div>
                    </div>
                    <div class="col-md-4" style="padding-left: 0;">
                        <div class="focus-search">
                            <form action="<?php echo e(route('home.search')); ?>" method="GET">
                                <div class="box-search">
                                    <input type="text" placeholder="Nhập từ khóa tìm kiếm ..." name="q" id="query-search">
                                    <button type="submit" id="icon-search"><i class="fa fa-search" id=""></i></button>
                                </div>
                            </form>
                            <div class="list-search" style="display: none;">
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4" style="padding-left: 0; position: unset;">
                        <div class="header-right">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a title="" href="javascript:0">Sản phẩm đã xem <i class="fa fa-caret-down"></i></a>
                                    <?php if(session('product_viewed')): ?>
                                        <div class="hver-seen">
                                            <?php echo $__env->make('frontend.teamplate.parts-header.products-viewed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    <?php endif; ?>
                                </li>
                                <li class="list-inline-item">
                                    <a title="Giỏ hàng" href="<?php echo e(route('home.cart')); ?>" class="cart">
                                        <img src="<?php echo e(__BASE_URL__); ?>/images/cart-hd.png" class="img-fluid" alt="cart"><span><?php echo e(Cart::count()); ?></span>
                                    </a>
                                    <?php if(Cart::count()): ?>
                                        <div class="hver-cart">
                                            <?php echo $__env->make('frontend.teamplate.parts-header.products-cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    <?php endif; ?>
                                   
                                </li>
                                <li class="list-inline-item"><a title="" href="tel:<?php echo e(@$site_info->hotline); ?>">Hotline: <?php echo e(@$site_info->hotline); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-menu">
        <div class="container">
            <div class="content">
                <div class="row">
                    <div class="col-md-4">
                        <div class="menu-left">
                            <div class="cate-menu"><a title="" href="javascript:0"><i class="fa fa-bars"></i>Danh mục sản phẩm</a></div>
                            <ul class="<?php echo e(url()->current() == url('/') ? 'active' : null); ?>">
                                <?php echo $__env->make('frontend.teamplate.parts-header.category-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="menu-right">
                            <ul>
                                <?php $__currentLoopData = $menuMain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->parent_id == null): ?>
                                        <li><a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="menu-mobile d-none">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-6 col-sm-6">
                    <div class="logo"> 
                        <a title="<?php echo e(@$site_info->site_title); ?>" href="<?php echo e(url('/')); ?>">
                        	<img alt="<?php echo e(@$site_info->site_title); ?>" src="<?php echo e(@$site_info->logo); ?>" class="img-fluid avarta-logo" alt="<?php echo e(@$site_info->site_title); ?>">
                        </a>
                    </div>
                </div>
                <div class="col-md-7 col-6 col-sm-6">
                    <div class="right text-right">
                        <div class="search">
                            <form action="<?php echo e(route('home.search')); ?>" method="GET">
                                <input type="text" placeholder="Nhập từ khóa tìm kiếm" name="q">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <div class="cart">
                            <a title="Giỏ hàng" href="<?php echo e(route('home.cart')); ?>">
                                <img src="<?php echo e(__BASE_URL__); ?>/images/cart-hd.png" class="img-fluid" alt="cart"><span><?php echo e(Cart::count()); ?></span>
                            </a>
                        </div>
                        <div class="header">
                            <!-- <a title="" href="#menu"><img src="<?php echo e(__BASE_URL__); ?>/images/bar.png" class="img-fluid" alt="bar"></a> -->
                            <a title="" href="#menu"><i class="fa fa-bars"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav id="menu">
            <ul>
                <?php $__currentLoopData = $menuMainMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->parent_id == null): ?>
                        <?php if(count($item->get_child_cate())): ?>
                            <li>
                                <a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a>
                                <ul>
                                    <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(count($value->get_child_cate())): ?>
                                            <li>
                                                <a title="<?php echo e($value->title); ?>" href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a>
                                                <ul>
                                                    <?php $__currentLoopData = $value->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a title="<?php echo e($value2->title); ?>" href="<?php echo e(url($value2->url)); ?>"><?php echo e($value2->title); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </li>
                                            
                                        <?php else: ?>
                                            <li><a title="<?php echo e($value->title); ?>" href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a></li>
                                        <?php endif; ?>
                                        

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li><a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a></li>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>
    </div>
    <div class="search-mb">
        <form action="<?php echo e(route('home.search')); ?>" method="GET">
            <input type="text" placeholder="Nhập từ khóa tìm kiếm" class="" name="q">
            <button class=""><i class="fa fa-search"></i></button>
        </form>
    </div>
</header><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/frontend/teamplate/header.blade.php ENDPATH**/ ?>