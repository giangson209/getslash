<header>
    <section class="header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3 col-6">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>" title="<?php echo e(@$site_info->site_title); ?>">
                            <img src="<?php echo e(@$site_info->logo); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-md-9 col-6">
                    <div class="header-right flex-center-end">
                        <div class="header-nav">
                            <ul class="flex-center-end">
                                <?php $__currentLoopData = $menuMain ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url($item->url)); ?>" title=""><?php echo e($item->title); ?></a> </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <a href="<?php echo e(route('home.cart')); ?>" title="" class="cart-icon">
                            <span><?php echo e(Cart::count()); ?></span>
                        </a>
                        <a title="" href="#menu" class="btn-menu visible-mobile"><img src="<?php echo e(__BASE_URL__); ?>/images/icon-bar.png" class="img-fluid" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</header>
<nav id="menu">
    <ul>
        <?php $__currentLoopData = $menuMain ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url($item->url)); ?>" title=""><?php echo e($item->title); ?></a> </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</nav><?php /**PATH C:\xampp\htdocs\batdongsan\resources\views/frontend/teamplate/header.blade.php ENDPATH**/ ?>