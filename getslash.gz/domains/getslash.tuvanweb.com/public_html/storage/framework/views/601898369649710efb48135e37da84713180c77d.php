
<?php $__env->startSection('main'); ?>
	<?php if(!empty($data->content)){
		$content = json_decode( $data->content );
	} ?>
	<section id="sllide-home" class="pb-60">
		<div class="slide-banner">
			<?php if(!empty($content->banner)): ?>
				<?php $__currentLoopData = $content->banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<a href="<?php echo e($value->link); ?>">
							<img src="<?php echo e($value->banner); ?>" class="img-fluid w-100" alt="<?php echo e($value->name); ?>">
						</a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
	</section>

	<section class="prd-hot pb-60">
		<div class="container">
			<div class="title text-center"><h2><span>Sản phẩm khuyến mãi</span></h2></div>
			<div class="slide-prd-hot">
				<?php $product_sale = \App\Models\Products::where('status', 1)->where('sale', '!=', 0)->orderBy('created_at', 'DESC')->take(12)->get(); ?>
				<?php $__currentLoopData = $product_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item-slide"> 
						<div class="item-prd text-center">
							<div class="avarta">
								<a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
                                </a>
							</div>
							<div class="info">
								<div class="info">
									<h3><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
									<div class="price">
										 <?php if(!empty($item->sale)): ?>
                                            <span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                                            <del><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</del>
                                        <?php else: ?>
                                            <span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                                        <?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="read-more text-center"><a href="<?php echo e(route('home.list.product')); ?>">Xem thêm</a></div>	
		</div>
	</section>

	<?php if(!empty($content->category->id_first)): ?>
		<?php $categories = \App\Models\Categories::find($content->category->id_first); ?>
		<?php if(!empty($categories)): ?>
			<section class="box-product pb-60">
				<div class="container">
					<div class="title text-center"><h2><span><?php echo e($categories->name); ?></span></h2></div>
					<div class="tab-home">
						<ul class="tabs">
							<?php if(count($categories->get_child_cate())): ?>
								<?php $__currentLoopData = $categories->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li class="tab-link <?php echo e($loop->index == 0 ? 'active' : null); ?>" data-tab="tab-<?php echo e($loop->index + 1); ?>"><?php echo e($value->name); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</ul> 
					</div>
					<div class="list-prd">
						<?php if(count($categories->get_child_cate())): ?>
							<?php $__currentLoopData = $categories->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div id="tab-<?php echo e($loop->index + 1); ?>" class="tab-content <?php echo e($loop->index == 0 ? 'active' : null); ?>">
									<div class="row">
										<?php $categoriesChild = \App\Models\Categories::find($value->id); ?>
										<?php if(!empty( $categoriesChild )): ?>
											<?php
												$list_id_children   = get_list_ids($categoriesChild);
										        $list_id_children[] = $categoriesChild->id;
										        $list_id_product    = \App\Models\ProductCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_product')->toArray();
										        $data_products      = \App\Models\Products::active()->filter()->whereIn('id', $list_id_product)->orderBy('created_at', 'DESC')->take(9)->get();
											?>
											<?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="col-md-2 <?php echo e($loop->index == 0 ? 'col-40' : null); ?>">
													<div class="item-prd <?php echo e($loop->index == 0 ? 'prd-40' : null); ?> text-center">
														<div class="avarta">
															<a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
							                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
							                                </a>
														</div>
														<div class="info">
															<h3><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
															<div class="price">
															 	<?php if(!empty($item->sale)): ?>
					                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
					                                            	<del><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</del>
					                                        	<?php else: ?>
					                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
					                                        	<?php endif; ?>
															</div>
														</div>
													</div>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											
										<?php endif; ?>
										<div class="read-more text-center"><a href="<?php echo e(route('home.archive.product', $categoriesChild->slug )); ?>">Xem thêm</a></div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						
					</div>
				</div> 
			</section>
		<?php endif; ?>
		
	<?php endif; ?>

	<?php if(!empty($content->category->id_second)): ?>
		<?php $categories = \App\Models\Categories::find($content->category->id_second); ?>
		<?php if(!empty($categories)): ?>
			<section class="box-product pb-60">
				<div class="container">
					<div class="title text-center"><h2><span><?php echo e($categories->name); ?></span></h2></div>
					<div class="list-prd">
						<div id="" class="active">
							<div class="row">
								<?php
									$list_id_children   = get_list_ids($categories);
							        $list_id_children[] = $categories->id;
							        $list_id_product    = \App\Models\ProductCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_product')->toArray();
							        $data_products      = \App\Models\Products::active()->filter()->whereIn('id', $list_id_product)->orderBy('created_at', 'DESC')->take(9)->get();
								?>
								<?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-md-2 <?php echo e($loop->index == 3 ? 'col-40' : null); ?>">
										<div class="item-prd <?php echo e($loop->index == 3 ? 'prd-40' : null); ?> text-center">
											<div class="avarta">
												<a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
				                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
				                                </a>
				                            </div>
											<div class="info">
												<h3><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
												<div class="price">
												 	<?php if(!empty($item->sale)): ?>
		                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
		                                            	<del><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</del>
		                                        	<?php else: ?>
		                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
		                                        	<?php endif; ?>
												</div>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<div class="read-more text-center"><a href="<?php echo e(route('home.archive.product', $categories->slug )); ?>">Xem thêm</a></div>
							</div>
						</div>
					</div>
				</div> 
			</section>
		<?php endif; ?>
	<?php endif; ?>

	<section class="box-sale pb-60">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<a href="<?php echo e(@$content->category->banner_1->link); ?>">
						<img src="<?php echo e(@$content->category->banner_1->banner); ?>" class="img-fluid w-100" alt="">
					</a>
				</div>
				<div class="col-md-6">
					<a href="<?php echo e(@$content->category->banner_2->link); ?>">
						<img src="<?php echo e(@$content->category->banner_2->banner); ?>" class="img-fluid w-100" alt="">
					</a>
				</div>
			</div>
		</div>
	</section>


	
	<?php if(!empty($content->category->id_ba)): ?>
		<?php $categories = \App\Models\Categories::find($content->category->id_ba); ?>
		<?php if(!empty( $categories )): ?>
			<?php
				$list_id_children   = get_list_ids($categories);
		        $list_id_children[] = $categories->id;
		        $list_id_product    = \App\Models\ProductCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_product')->toArray();
		        $data_products      = \App\Models\Products::active()->filter()->whereIn('id', $list_id_product)->orderBy('created_at', 'DESC')->take(10)->get();
			?>
			<section class="box-product pb-60">
				<div class="container">
					<div class="title text-center"><h2><span><?php echo e($categories->name); ?></span></h2></div>
					<div class="list-prd">
						<div class="row">
							<?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-2">
									<div class="item-prd text-center">
										<div class="avarta">
											<a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
			                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
			                                </a>
										</div>
										<div class="info">
											<h3><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
											<div class="price">
											 	<?php if(!empty($item->sale)): ?>
	                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
	                                            	<del><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</del>
	                                        	<?php else: ?>
	                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
	                                        	<?php endif; ?>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="read-more text-center"><a href="<?php echo e(route('home.archive.product', $categories->slug )); ?>">Xem thêm</a></div>
					</div>
				</div>
			</section>
		<?php endif; ?>
	<?php endif; ?>
	
	<?php if(!empty($content->category->id_bon)): ?>
		<?php $categories = \App\Models\Categories::find($content->category->id_bon); ?>
		<?php if(!empty( $categories )): ?>
			<?php
				$list_id_children   = get_list_ids($categories);
		        $list_id_children[] = $categories->id;
		        $list_id_product    = \App\Models\ProductCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_product')->toArray();
		        $data_products      = \App\Models\Products::active()->filter()->whereIn('id', $list_id_product)->orderBy('created_at', 'DESC')->take(4)->get();
			?>
			<section class="box-product pb-60">
				<div class="container">
					<div class="title text-center"><h2><span><?php echo e($categories->name); ?></span></h2></div>
					<div class="list-prd">
						<div id="" class="active">
							<div class="row">
								<?php $__currentLoopData = $data_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-md-2 <?php echo e($loop->index == 0 ? 'col-40' : null); ?>">
										<div class="item-prd <?php echo e($loop->index == 0 ? 'prd-40' : null); ?> text-center">
											<div class="avarta">
												<a href="<?php echo e(route('home.single.product', $item->slug)); ?>">
				                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
				                                </a>
				                            </div>
											<div class="info">
												<h3><a href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
												<div class="price">
												 	<?php if(!empty($item->sale)): ?>
		                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
		                                            	<del><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</del>
		                                        	<?php else: ?>
		                                            	<span><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
		                                        	<?php endif; ?>
												</div>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<div class="read-more text-center"><a href="<?php echo e(route('home.archive.product', $categories->slug )); ?>">Xem thêm</a></div>
							</div>
						</div>
					</div>
				</div> 
			</section>
		<?php endif; ?>
	<?php endif; ?>
	
	<?php if(!empty($content->tieuchi)): ?>
		<section class="box-srv">
			<div class="container">
				<div class="row">
					<?php $__currentLoopData = $content->tieuchi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3 col-sm-3">
							<div class="item-srv text-center">
								<div class="icon">
									<img src="<?php echo e($value->icon); ?>" class="img-fluid" alt="">
								</div>
								<div class="info">
									<h3><?php echo e($value->title_1); ?></h3>
									<p><?php echo e($value->title_2); ?></p>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<section class="box-news pt-60 pb-60">
		<div class="container">
			<div class="title text-center"><h2><span>Tin tức</span></h2></div>
			<div class="news-home">
				<div class="row">
					<?php $post_new = \App\Models\Posts::where('status', 1)->orderBy('created_at', 'DESC')->take(3)->get(); ?>
					<?php if(count($post_new)): ?>
						<?php $__currentLoopData = $post_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-4 col-sm-4">
								<div class="item">
									<div class="avarta">
										<a href="<?php echo e(route('home.post.single', $item->slug)); ?>">
											<img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
										</a>
									</div>
									<div class="info">
										<h3><a href="<?php echo e(route('home.post.single', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
										<div class="date-time">
											<ul class="list-inline">
												<li class="list-inline-item"><?php echo e($item->created_at->format('d/m/Y')); ?></li>
											</ul>
										</div>
										<div class="desc">
											<?php echo e($item->desc); ?>

										</div>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/vongtay/resources/views/frontend/pages/home.blade.php ENDPATH**/ ?>