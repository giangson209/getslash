<?php $__env->startSection('main'); ?>
	<section id="breadcrumbs">
		<div class="avarta">
			<?php if($dataSeo->banner): ?>
				<img src="<?php echo e($dataSeo->banner); ?>" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php else: ?>
				<img src="<?php echo e(__BASE_URL__); ?>/images/bread.png" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php endif; ?>
		</div>
		<div class="info">
			<div class="container text-center">
				<h2 class="text-uppercase">Liên hệ</h2>
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ <span>/</span></a></li>
					<li class="list-inline-item"><a title="Liên hệ" href="javascript:0">Liên hệ</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="contact">
		<h1 class="d-none"><?php echo e(@$dataSeo->title_h1); ?></h1>
		<?php if(!empty($dataSeo->content)){
			$content = json_decode($dataSeo->content);
		} ?>
		<div class="container">
			<div class="content">
				<div class="info-contact pt-100 pb-100">
					<div class="row" style="position: relative;">
						<div class="col-md-12">
							<div class="social">
								<ul>
									<li>
										<a title="Zalo" href="<?php echo e(@$content->info->zalo); ?>" target="_blank">
											<img src="<?php echo e(__BASE_URL__); ?>/images/sc-1.png" class="img-fluid" alt="Zalo">
										</a>
									</li>
									<li>
										<a title="Facebook" href="<?php echo e(@$content->info->facebook); ?>" target="_blank">
											<img src="<?php echo e(__BASE_URL__); ?>/images/sc-2.png" class="img-fluid" alt="Facebook">
										</a>
									</li>
									<li><a title="<?php echo e(@$content->info->phone); ?>" href="<?php echo e(@$content->info->phone); ?>">
										<img src="<?php echo e(__BASE_URL__); ?>/images/sc-3.png" class="img-fluid" alt="Phone"></a>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-md-6">
							<div class="left">
								<div class="title-contact">Liên hệ với chúng tôi</div>
								<div class="desc">
									<?php echo e(@$content->info->desc_pages); ?>

								</div>
								<div class="list-place">
									<ul>
										<li><i class="fa fa-map-marker"></i><?php echo e(@$content->info->address); ?></li>
										<li><i class="fa fa-phone"></i><?php echo e(@$content->info->phone); ?></li>
										<li><i class="fa fa-envelope"></i><?php echo e(@$content->info->email); ?></li>
									</ul>
								</div>
								<div class="social-md d-none"> 
									<ul class="list-inline">
										<li class="list-inline-item">
											<a title="" href="">
												<img src="<?php echo e(__BASE_URL__); ?>/images/sc-1.png" class="img-fluid" alt="ICON">
											</a>
										</li>
										<li class="list-inline-item">
											<a title="" href="">
												<img src="<?php echo e(__BASE_URL__); ?>/images/sc-2.png" class="img-fluid" alt="ICON">
											</a>
										</li>
										<li class="list-inline-item">
											<a title="" href="">
												<img src="<?php echo e(__BASE_URL__); ?>/images/sc-3.png" class="img-fluid" alt="ICON">
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="right">
								<div class="title-contact">Nhập thông tin của bạn</div>
								<div class="form-contact">
									<form action="<?php echo e(route('home.contact.post')); ?>" method="POST" id="contact-form">
										<?php echo csrf_field(); ?>

										<div class="row">
											<?php if(Session::has('flash_message')): ?>
				                                <div class="col-sm-12">
				                                    <div class="item" style="margin-bottom: 15px">
				                                        <div class="alert alert-success alert-dismissible">
				                                        	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				                                            <h4><i class="icon fa fa-ban"></i> Thông báo</h4>
				                                            <?php echo e(Session::get('flash_message')); ?>

				                                        </div>
				                                    </div>
				                                </div>
				                            <?php endif; ?>


				                            <?php if(count($errors) > 0): ?>
				                                <div class="col-sm-12">
				                                    <div class="item" style="margin-bottom: 15px">
				                                        <div class="alert alert-danger alert-dismissible">
				                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				                                            <h4><i class="icon fa fa-ban"></i> Thông báo</h4>
				                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                                                <li><?php echo $error; ?></li>
				                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                                        </div>
				                                    </div>
				                                </div>
				                            <?php endif; ?>
				                            
											<div class="col-md-12">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Họ & tên" name="name">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct1.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Email" name="email">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct2.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Số điện thoại" name="phone">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct3.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
													<div class="item">
														<input type="text" placeholder="Địa chỉ" name="address">
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct4.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
													<div class="item">
														<textarea name="content" placeholder="Nội dung" cols="30" rows="10"></textarea>
														<span class="icon-form"><img src="<?php echo e(__BASE_URL__); ?>/images/ct5.png" class="img-fluid" alt="Liên hệ "></span>
													</div>
												</div>
											</div>
											<div class="col-md-12">
												<div class="item text-center">
													<div class="btn-submit">
														<input type="submit" class="btn-sent" value="GỬI">
													</div>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="maps">
			<?php echo $site_info->google_maps; ?>

		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script type="text/javascript" src="<?php echo e(asset('public/vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
	<?php echo $jsValidator->selector('#contact-form'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>