<?php
    $sideBarCategories = \App\Models\Categories::where('type', 'post_category')->orderBy('created_at')->get();
    $sideBarTags = Conner\Tagging\Model\Tag::all();
?>
<div class="side-bar">
    <div class="list-bar">
        <div class="item-bar">
            <div class="title-bar"><?php echo app('translator')->getFromJson('site.categories'); ?></div>
            <ul class="list-cate">
                <?php $__currentLoopData = $sideBarCategories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('pages.category.post', $item->slug)); ?>" class="<?php echo e($item->id == @$category->id ? 'active' : null); ?>"><?php echo e($item->{ 'name_'.locale() }); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="item-bar">
            <div class="title-bar">Tags</div>
            <div class="list-tags">
                <ul class="list-inline">
                    <?php $__currentLoopData = $sideBarTags ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-inline-item"><a href="<?php echo e(route('pages.tags.post', $item->slug)); ?>"><?php echo e($item->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\slash\resources\views/frontend/pages/blog/sidebar.blade.php ENDPATH**/ ?>