<?php $__env->startSection('main'); ?>
	<h1 style="display: none;"><?php echo e(@$dataSeo->title_h1); ?></h1>
	<?php echo $__env->make('frontend.teamplate.breadcrumbs', [ 
		'config' => [
			'banner' => @$dataSeo->banner,
			'title' => 'Tin tức'
		] 
	], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<section id="news" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-9">
						<div class="list-news">
							<div class="row">
								<?php if(!empty($data)): ?>
									<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($loop->index == 0): ?>
											<div class="col-md-12">
												<div class="news-big">
													<div class="avarta">
														<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" 
															title="<?php echo e($item->name); ?>">
															<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>">
														</a>
													</div>
													<div class="info">
														<div class="date jose"><?php echo e($item->created_at->format('d/m/Y')); ?></div>
														<h1><a href="<?php echo e(route('home.post.single', $item->slug)); ?>" class="jose" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h1>
														<div class="desc">
															<?php echo e($item->desc); ?>

														</div>
													</div>
												</div>
											</div>
										<?php else: ?>
											<div class="col-md-4 col-sm-4">
												<div class="item">
													<div class="avarta">
														<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" 
															title="<?php echo e($item->name); ?>">
															<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>">
														</a>
													</div>
													<div class="info">
														<div class="date">
															<?php echo e($item->created_at->format('d/m/Y')); ?>

														</div>
														<h3>
															<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>">
																<?php echo e($item->name); ?>

															</a>
														</h3>
														<div class="desc">
															<?php echo e(text_limit($item->desc, 12)); ?>...
														</div>
													</div>
												</div>
											</div>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								<div class="col-md-12">
									<div class="pagination">
										<?php echo $data->links(); ?>

									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<?php echo $__env->make('frontend.teamplate.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/frontend/pages/archives-news.blade.php ENDPATH**/ ?>