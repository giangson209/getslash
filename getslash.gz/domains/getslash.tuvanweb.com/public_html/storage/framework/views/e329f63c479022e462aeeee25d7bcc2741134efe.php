<?php $__env->startSection('controller', $module['name'] ); ?>
<?php $__env->startSection('controller_route', route($module['module'].'.index')); ?>
<?php $__env->startSection('action', renderAction(@$module['action'])); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo updateOrStoreRouteRender( @$module['action'], $module['module'], @$data); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isUpdate(@$module['action'])): ?>
                <?php echo e(method_field('put')); ?>

            <?php endif; ?>
            <div class="row">
                <div class="col-sm-9">
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                            <li class="active">
                                <a href="#activity" data-toggle="tab" aria-expanded="true">Thông tin </a>
                            </li>
                       <!--      <li class="">
                                <a href="#setting" data-toggle="tab" aria-expanded="true">Cấu hình seo</a>
                            </li> -->
                        </ul>
                        <div class="tab-content">

                            <div class="tab-pane active" id="activity">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label>Tiêu đề</label>
                                            <input type="text" class="form-control" name="name_vi" id="name" value="<?php echo old('name_vi', @$data->name_vi); ?>" required="">
                                        </div>

                                        <div class="form-group">
                                            <label>Mô tả</label>
                                            <textarea name="desc_vi" class="content" cols="30" rows="10"><?php echo old('desc_vi', @$data->desc_vi); ?></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label>Địa chỉ</label>
                                            <input type="text" class="form-control" name="address_vi" value="<?php echo old('address_vi', @$data->address_vi); ?>" >
                                        </div>

                                   <!--      <div class="form-group">
                                            <label>Số lượng</label>
                                            <input type="text" class="form-control" name="qty" value="<?php echo old('qty', @$data->qty); ?>" >
                                        </div> -->

                                        <div class="form-group">
                                            <label>Mức lương</label>
                                            <input type="text" class="form-control" name="offers_vi" value="<?php echo old('offers_vi', @$data->offers_vi); ?>" >
                                        </div>
                                  <!--       <div class="form-group">
                                            <label>Ngày kết thúc</label>
                                            <input type="text" class="form-control" name="deadline" value="<?php echo old('deadline', @$data->deadline); ?>" >
                                        </div> -->
                                        <div class="form-group">
                                            <label>EMPLOYMENT TYPE</label>
                                            <input type="text" class="form-control" name="type" value="<?php echo old('type', @$data->type); ?>" >
                                        </div>

                                        <div class="form-group">
                                            <label>DEPARTMENT</label>
                                            <input type="text" class="form-control" name="department" value="<?php echo old('department', @$data->department); ?>" >
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="tab-pane" id="setting">
                                <div class="form-group">
                                    <label>Title SEO</label>
                                    <label style="float: right;">Số ký tự đã dùng: <span id="countTitle"><?php echo e(@$data->meta_title != null ? mb_strlen( $data->meta_title, 'UTF-8') : 0); ?>/70</span></label>
                                    <input type="text" class="form-control" name="meta_title" value="<?php echo old('meta_title', isset($data->meta_title) ? $data->meta_title : null); ?>" id="meta_title">
                                </div>

                                <div class="form-group">
                                    <label>Meta Description</label>
                                    <label style="float: right;">Số ký tự đã dùng: <span id="countMeta"><?php echo e(@$data->meta_description != null ? mb_strlen( $data->meta_description, 'UTF-8') : 0); ?>/360</span></label>
                                    <textarea name="meta_description" class="form-control" id="meta_description" rows="3"><?php echo old('meta_description', isset($data->meta_description) ? $data->meta_description : null); ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Meta Keyword</label>
                                    <input type="text" class="form-control" name="meta_keyword" value="<?php echo old('meta_keyword', isset($data->meta_keyword) ? $data->meta_keyword : null); ?>">
                                </div>
                                <?php if(isUpdate(@$module['action'])): ?>
                                    <h4 class="ui-heading">Xem trước kết quả tìm kiếm</h4>
                                    <div class="google-preview">
                                        <span class="google__title"><span><?php echo !empty($data->meta_title) ? $data->meta_title : @$data->name; ?></span></span>
                                        <div class="google__url">
                                            <?php echo e(asset( 'van-ban/'.$data->slug.'-'.$data->id )); ?>

                                        </div>
                                        <div class="google__description"><?php echo old('meta_description', isset($data->meta_description) ? @$data->meta_description : ''); ?></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title">Đăng</h3>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <label class="custom-checkbox">
                                    <?php if(isUpdate(@$module['action'])): ?>
                                        <input type="checkbox" name="status" value="1" <?php echo e(@$data->status == 1 ? 'checked' : null); ?>> Hiển thị
                                    <?php else: ?>
                                        <input type="checkbox" name="status" value="1" checked> Hiển thị
                                    <?php endif; ?>
                                </label>
                            </div>
                            <div class="form-group text-right">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-save" style="padding-right: 5px"></i>Đăng</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        jQuery(document).ready(function($) {
            $('#btn-ok').click(function(event) {
                var slug_new = $('#new-post-slug').val();
                var name = $('#name').val();
                $.ajax({
                    url: '<?php echo e(route($module['module'].'.get-slug')); ?>',
                    type: 'GET',
                    data: {
                        id: $('#idPost').val(),
                        slug : slug_new.length > 0 ? slug_new : name,
                    },
                })
                .done(function(data) {
                    $('#change_slug').show();
                    $('#btn-ok').hide();
                    $('.cancel.button-link').hide();
                    $('#current-slug').val(data);
                    cancelInput(data);
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\slash\resources\views/backend/recruitments/create-edit.blade.php ENDPATH**/ ?>