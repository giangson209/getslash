<div class="item">
	<?php if(!empty($item->sale)): ?>
			<div class="sale-per"><span>-<?php echo e($item->sale); ?>%</span></div>
		<?php endif; ?>
	<div class="avarta">
		
		<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>">
			<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" alt="<?php echo e($item->name); ?>">
		</a>
		<?php if($item->CheckApplyGift()): ?>
			<div class="icon-sale">
				<img data-src="<?php echo e(__BASE_URL__); ?>/images/gift.png" class="img-fluid lazyload" alt="Quà tặng"><span>Quà tặng</span>
			</div>
		<?php endif; ?>
	</div>
	<div class="info text-left">
		<h3><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.product', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
		<div class="price">
			<?php if($item->CheckPricePriority()): ?>
				<span class="uutien"><?php echo e(number_format($item->price_priority,0, '.', '.')); ?>đ</span>
				<del><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</del>
			<?php else: ?>
				<?php if(!is_null($item->sale_price)): ?>
					<span><?php echo e(number_format($item->sale_price,0, '.', '.')); ?>đ</span>
					<del><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</del>
				<?php else: ?>
					<?php if($item->regular_price != 0): ?>
						<span><?php echo e(number_format($item->regular_price,0, '.', '.')); ?>đ</span>
					<?php else: ?>
						<span>Liên hệ</span>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\bephungphu\resources\views/frontend/components/product-style-2.blade.php ENDPATH**/ ?>