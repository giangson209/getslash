<?php $__env->startSection('controller','Trang'); ?>
<?php $__env->startSection('controller_route',route('pages.list')); ?>
<?php $__env->startSection('action','Danh sách'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo e(route('pages.build.post')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input name="type" value="<?php echo e($data->type); ?>" type="hidden">

	               	<div class="row">
						<div class="col-sm-12">
							<div class="form-group">
								<label for="">Trang</label>
								<input type="text" class="form-control" value="<?php echo e($data->name_page); ?>" disabled="">
				 				
								<?php if(\Route::has($data->route)): ?>
									<h5>
										<a href="<?php echo e(route($data->route)); ?>" target="_blank">
					                        <i class="fa fa-hand-o-right" aria-hidden="true"></i>
					                        Link: <?php echo e(route($data->route)); ?>

					                    </a>
									</h5>
				                <?php endif; ?>
							</div>
							
						</div>
					</div>
					<div class="nav-tabs-custom">
				        <ul class="nav nav-tabs">
				        	<li class="active">
				        		<a href="#criteria" data-toggle="tab" aria-expanded="true">Tiêu chí</a>
				        	</li>
				        	<li class="">
				        		<a href="#services" data-toggle="tab" aria-expanded="true">Dịch vụ</a>
				        	</li>
				        	<li class="">
				        		<a href="#gallery" data-toggle="tab" aria-expanded="true">Thư viện ảnh</a>
				        	</li>
				            <li class="">
				            	<a href="#seo" data-toggle="tab" aria-expanded="true">Cấu hình trang</a>
				            </li>
				        </ul>
				    </div>
				    <?php if(!empty($data->content)){
				    	$content = json_decode($data->content);
				    }?>
				    <div class="tab-content">

						<div class="tab-pane active" id="criteria">
							<div class="row">
								<div class="col-sm-12">
									<div class="repeater" id="repeater">
						                <table class="table table-bordered table-hover criteria">
						                    <thead>
							                    <tr>
							                    	<th style="width: 30px;">STT</th>
							                    	<th width="200px">Ảnh nền</th>
							                    	<th width="200px">Icon</th>
							                    	<th>Tiêu đề</th>
							                    	<th width="20px"></th>
							                    </tr>
						                	</thead>
						                    <tbody id="sortable">
						                    	<?php if(!empty($content->criteria)): ?>
						                    		<?php $__currentLoopData = $content->criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						                    			<tr>
															<td class="index"><?php echo e($loop->index + 1); ?></td>
															<td>
														       <div class="image">
														           <div class="image__thumbnail">
														               <img src="<?php echo e(!empty($value->background) ? $value->background : __IMAGE_DEFAULT__); ?>"
														               data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
														               <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
														                <i class="fa fa-times"></i></a>
														               <input type="hidden" value="<?php echo e(@$value->background); ?>" name="content[criteria][<?php echo e($key); ?>][background]"  />
														               <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
														           </div>
														       </div>
															</td>
															<td>
														       <div class="image">
														           <div class="image__thumbnail">
														               <img src="<?php echo e(!empty($value->icon) ? $value->icon : __IMAGE_DEFAULT__); ?>"
														               data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
														               <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
														                <i class="fa fa-times"></i></a>
														               <input type="hidden" value="<?php echo e(@$value->icon); ?>" name="content[criteria][<?php echo e($key); ?>][icon]"  />
														               <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
														           </div>
														       </div>
															</td>
															<td>
																<input type="text" name="content[criteria][<?php echo e($key); ?>][title]" class="form-control"
																value="<?php echo e(@$value->title); ?>">
															</td>
															<td style="text-align: center;">
														        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
														            <i class="fa fa-minus"></i>
														        </a>
														    </td>
														</tr>
						                    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                    	<?php endif; ?>
											</tbody>
						                </table>
						                <div class="text-right">
						                    <button class="btn btn-primary" 
								            	onclick="repeater(event,this,'<?php echo e(route('get.layout')); ?>','.index', 'criteria', '.criteria')">Thêm
								            </button>
						                </div>
						            </div>
								</div>
							</div>
						</div>

						<div class="tab-pane" id="services">
							<div class="row">
								<div class="col-sm-12">
									<div class="repeater" id="repeater">
						                <table class="table table-bordered table-hover services">
						                    <thead>
							                    <tr>
							                    	<th style="width: 30px;">STT</th>
							                    	<th width="200px">Hình ảnh</th>
							                    	<th>Nội dung</th>
							                    	<th style="width: 20px"></th>
							                    </tr>
						                	</thead>
						                    <tbody id="sortable">
												<?php if(!empty($content->services)): ?>
													<?php $__currentLoopData = $content->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													    <?php $index = $loop->index + 1 ; ?>
														<?php echo $__env->make('backend.repeater.row-services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
						                    </tbody>
						                </table>
						                <div class="text-right">
						                    <button class="btn btn-primary" 
								            	onclick="repeater(event,this,'<?php echo e(route('get.layout')); ?>','.index', 'services', '.services')">Thêm
								            </button>
						                </div>
						            </div>
						        </div>
							</div>
						</div>

			            <div class="tab-pane" id="seo">
							<div class="row">
								<div class="col-sm-2">
									<div class="form-group">
			                           <label>Hình ảnh</label>
			                           <div class="image">
			                               <div class="image__thumbnail">
			                                   <img src="<?php echo e($data->image ?  $data->image : __IMAGE_DEFAULT__); ?>"  
			                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                   <input type="hidden" value="<?php echo e(@$data->image); ?>" name="image"  />
			                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
			                               </div>
			                           </div>
			                       </div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
			                           <label>Banner</label>
			                           <div class="image">
			                               <div class="image__thumbnail">
			                                   <img src="<?php echo e($data->banner ?  $data->banner : __IMAGE_DEFAULT__); ?>"  
			                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                   <input type="hidden" value="<?php echo e(@$data->banner); ?>" name="banner"  />
			                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
			                               </div>
			                           </div>
			                       </div>
								</div>
								<div class="col-sm-8">
									<div class="form-group">
										<label for="">Tiêu đề trang</label>
										<input type="text" name="meta_title" class="form-control" value="<?php echo e(@$data->meta_title); ?>">
									</div>
									<div class="form-group">
										<label for="">Mô tả trang</label>
										<textarea name="meta_description" 
										class="form-control" rows="5"><?php echo @$data->meta_description; ?></textarea>
									</div>
									<div class="form-group">
										<label for="">Từ khóa</label>
										<input type="text" name="meta_keyword" class="form-control" value="<?php echo @$data->meta_keyword; ?>">
									</div>
									
									<div class="form-group">
										<label for="">Tiêu đề thẻ H1 ẩn</label>
										<input type="text" name="title_h1" class="form-control" value="<?php echo @$data->title_h1; ?>">
									</div>

								</div>
							</div>
			            </div>

			            <div class="tab-pane" id="gallery">
			            	<div class="row">
			            		<div class="col-sm-12">
			            			<div class="form-group">
			            				<label for="">Tiêu đề</label>
			            				<input type="text" name="content[gallery][title]" value="<?php echo e(@$content->gallery->title); ?>" class="form-control">
			            			</div>
			            		</div>

			            		<div class="col-sm-12 image" style="margin-bottom: 20px">
		                            <button type="button" class="btn btn-success" onclick="fileMultiSelectCustom(this,'content[gallery_1][list_image]')"><i class="fa fa-upload"></i>  
		                                Chọn hình ảnh thư viện 1
		                            </button>
		                            <br><br>
		                            <div class="image__gallery">
		                            	<?php if(!empty($content->gallery_1->list_image)): ?>
		                            		<?php $__currentLoopData = $content->gallery_1->list_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                            			<div class="image__thumbnail image__thumbnail--style-1">
		                            				<img src="<?php echo e(@$item); ?>">
	                            					<a href="javascript:void(0)" class="image__delete" onclick="urlFileMultiDelete(this)">
	                            						<i class="fa fa-times"></i>
	                            					</a>
	                            					<input type="hidden" name="content[gallery_1][list_image][]" value="<?php echo e(@$item); ?>">
		                            			</div>
		                            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                            	<?php endif; ?>
		                            </div>
		                        </div>

		                        <div class="col-sm-12">
		                        	<div class="form-group">
		                        		<label for="">Nội dung mô tả thư viện ảnh 1</label>
		                        		<textarea class="content" name="content[gallery_1][content]"><?php echo @$content->gallery_1->content; ?></textarea>
									</div>
		                        </div>



								<div class="col-sm-12 image" style="margin-bottom: 20px">
		                            <button type="button" class="btn btn-success" onclick="fileMultiSelectCustom(this,'content[gallery_2][list_image]')"><i class="fa fa-upload"></i>  
		                                Chọn hình ảnh thư viện 2
		                            </button>
		                            <br><br>
		                            <div class="image__gallery">
		                            	<?php if(!empty($content->gallery_2->list_image)): ?>
		                            		<?php $__currentLoopData = $content->gallery_2->list_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                            			<div class="image__thumbnail image__thumbnail--style-1">
		                            				<img src="<?php echo e(@$item); ?>">
	                            					<a href="javascript:void(0)" class="image__delete" onclick="urlFileMultiDelete(this)">
	                            						<i class="fa fa-times"></i>
	                            					</a>
	                            					<input type="hidden" name="content[gallery_2][list_image][]" value="<?php echo e(@$item); ?>">
		                            			</div>
		                            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                            	<?php endif; ?>
		                            </div>
		                        </div>

		                        <div class="col-sm-12">
		                        	<div class="form-group">
		                        		<label for="">Nội dung mô tả thư viện ảnh 2</label>
		                        		<textarea class="content" name="content[gallery_2][content]"><?php echo @$content->gallery_2->content; ?></textarea>
									</div>
		                        </div>

			            	</div>	
			            </div>
			           	
			           	<button type="submit" class="btn btn-primary">Lưu lại</button>
			        </div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/backend/pages/layout/services.blade.php ENDPATH**/ ?>