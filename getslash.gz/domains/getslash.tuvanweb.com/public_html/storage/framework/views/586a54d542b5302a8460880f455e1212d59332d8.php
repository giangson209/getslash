
<?php $__env->startSection('main'); ?>
<style>
    .c-group::before {
        top: 0;
        height: 100%;
    }
</style>
<main class="main">
    <section class="c-hero">
        <img class="element element-01" src="<?php echo e(__BASE_URL__); ?>/images/hero-2.jpg" />
        <div class="element element-02"></div>
        <img class="element element-03" src="<?php echo e(__BASE_URL__); ?>/images/hero.png" />
        <img class="element element-04" src="<?php echo e(__BASE_URL__); ?>/images/hero-1.png" />
        <img src="<?php echo e(__BASE_URL__); ?>/images/bn-home-ipad.jpg" class="img-fluid w-100 d-none d-ipad show-ipad" alt="" />
        <img src="<?php echo e(__BASE_URL__); ?>/images/bn-home-mb.jpg" class="img-fluid w-100 d-none hide-ipad" alt="" />

        <div class="container">
            <svg class="element element-05" width="232" height="400" viewBox="0 0 232 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3.59348 397.5L133.136 2.5H228.271L98.7608 397.5H3.59348Z" stroke="#00E889" stroke-width="5" />
            </svg>
            <div class="content">
                <h1><label>&nbsp;</label><?php echo @$contentPage->top->title_1; ?></h1>
                <h2><?php echo nl2br(@$contentPage->top->title_2); ?></h2>
                <p>
                    <?php echo nl2br(@$contentPage->top->desc); ?>

                </p>
                <a href="<?php echo e(@$contentPage->top->link); ?>" class="btn btn-01" type="button"><?php echo nl2br(@$contentPage->top->nut); ?></a>
            </div>
        </div>
    </section>
    <!-- hero -->

    <section class="c-guide" style="background: #FAFBFD;">
        <div class="container">
            <div class="heading">
                <p><?php echo e(@$site_info->khoi2->title); ?></p>
                <h2><?php echo nl2br(@$site_info->khoi2->sub_title); ?></h2>
            </div>
            <div class="row guide-box">
                <div class="col-12 col-lg-6">
                    <div class="slider slider-guide-content">
                        <?php if(!empty(@$site_info->about)): ?>
                            <?php $i=1; ?>
                            <?php $__currentLoopData = @$site_info->about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="slide-item">
                                    <div class="content">
                                        <div class="step">BƯỚC <?php echo e($i); ?></div>
                                        <h2><?php echo e(@$value->name); ?></h2>
                                        <p><?php echo @$value->desc; ?></p>
                                    </div>
                                </div>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <div class="slider slider-guide-images">
                        <?php if(!empty(@$site_info->about)): ?>
                            <?php $__currentLoopData = @$site_info->about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slide-item">
                                <div class="image-wrapper"><img src="<?php echo e(@$value->icon); ?>" title="<?php echo e(@$value->name); ?>" alt="<?php echo e(@$value->name); ?>"/></div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- guide -->

    <section class="c-group">
        <div class="container">
            <div class="box">
                <div class="heading">
                    <p><?php echo e(@$contentPage->khoi3->title_pro); ?></p>
                    <h2><?php echo e(@$contentPage->khoi3->sub_title_pro); ?></h2>
                </div>
                <!-- / heading -->
                <div class="slider slider-deal">
                    <?php if(isset($posttype['product'])): ?>
                    <?php $__currentLoopData = $posttype['product']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($k > 10): ?>
                            <?php break; ?>
                        <?php endif; ?>
                    <figure class="item">
                        <a class="item-wrapper" href="#">
                            <div class="sale">40%</div>
                            <div class="img"><img src="<?php echo e($pro->image); ?>" alt="<?php echo e($pro->name); ?>" /></div>
                            <div class="info">
                                <h3 class="title"><?php echo e($pro->name); ?></h3>
                                <div class="deal"><?php echo e($pro->price_old); ?><span>đ</span></div>
                                <div class="price">
                                    <div class="number"><?php echo e($pro->price); ?><span>đ</span></div>
                                    <div class="statu">
                                        <?php echo str_replace(['<p>', '</p>'], '', $pro->note ); ?>

                                    </div>
                                </div>
                            </div>
                        </a>
                    </figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <!-- / slider -->
            </div>
            <!-- box -->

            <div class="box">
                <div class="heading">
                    <p><?php echo e(@$contentPage->khoi3->title_pat); ?></p>
                    <h2><?php echo e(@$contentPage->khoi3->sub_title_pat); ?></h2>
                </div>
                <!-- / heading -->
                <div class="slider slider-partner">
                    <?php if(isset($posttype['partner'])): ?>
                    <?php $__currentLoopData = $posttype['partner']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($k > 10): ?>
                            <?php break; ?>
                        <?php endif; ?>
                    <div class="item">
                        <a href="<?php echo e($pro->slug); ?>"><img src="<?php echo e($pro->logo); ?>" /></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <!-- / slider -->
            </div>
            <!-- box -->

            <div class="box">
                <div class="heading">
                    <p><?php echo e(@$contentPage->khoi3->title_cat); ?></p>
                    <h2><?php echo e(@$contentPage->khoi3->sub_title_cat); ?></h2>
                </div>
                <!-- / heading -->
                <div class="slider slider-category">
                    <?php if(isset($posttype['category'])): ?>
                    <?php $__currentLoopData = $posttype['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($k > 4): ?>
                            <?php break; ?>
                        <?php endif; ?>
                    <div class="item">
                        <a href="<?php echo e($pro->slug); ?>">
                            <img src="<?php echo e($pro->image); ?>" />
                            <h3>
                                <?php echo e($pro->name); ?>

                            </h3>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <!-- / slider -->
            </div>
            <!-- box -->
        </div>
    </section>
    <!-- group -->

    <section class="c-video">
        <img class="element element-01" src="<?php echo e(__BASE_URL__); ?>/images/e-1.png" />
        <img class="element element-02" src="<?php echo e(__BASE_URL__); ?>/images/e-2.png" />
        <img class="element element-03" src="<?php echo e(__BASE_URL__); ?>/images/e-3.png" />
        <div class="container">
            <div class="heading">
                <h2>
                    <?php echo nl2br(@$contentPage->video->title_1); ?>

                </h2>
                <p><?php echo e(@$contentPage->video->title_2); ?></p>
            </div>
            <div class="video">
                <input type="text" class="rend-iframe d-none" value="<?php echo e(@$contentPage->video->link); ?>" id="url"/>
                <input type="button" class="btn_rend-iframe d-none" id="sendUrl"/>
                <div id="myVideo">
                    <iframe src="https://www.youtube.com/embed/<?php echo e(@$contentPage->video->link); ?>?rel=0&enablejsapi=1&autoplay=1=1&mute=1&loop=1"></iframe>
                </div>
                <!-- <img src="<?php echo e(@$contentPage->video->image); ?>" class="video-bg" />  -->
                <!-- <a class="play" data-fancybox="gallery-0" href="<?php echo e(@$contentPage->video->link); ?>"></a>  --> 
            </div>
        </div>
    </section>
    <!-- video -->

    <section class="c-review">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-5">
                    <div class="heading"> 
                        <p><?php echo e(@$contentPage->review->title_1); ?></p>
                        <h2><?php echo e(@$contentPage->review->title_2); ?></h2>
                    </div>
                    <!-- / header -->
                    <div class="slider slider-review">
                        <?php if(!empty(@$contentPage->partner)): ?>
                            <?php $__currentLoopData = @$contentPage->partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="iteam-wrapper">
                                    <div class="description"><?php echo e(@$value->content); ?></div>
                                    <div class="info-user">
                                        <div class="avata"><img src="<?php echo e(@$value->logo); ?>" alt="<?php echo e(@$value->name); ?>" /></div>
                                        <div class="name"><?php echo e(@$value->name); ?></div>
                                        <div class="info-other"><?php echo e(@$value->info); ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- / col -->
                <div class="col-12 col-lg-7">
                    <div class="row review-app">
                        <div class="col-md-6 col-12 item">
                            <div class="item-wrapper">
                                <div class="item-box">
                                    <div class="stars">
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                    </div>
                                    <div class="number">
                                        <?php echo @$contentPage->ios->sao; ?>

                                    </div>
                                    <a href="<?php echo e(@$contentPage->ios->link); ?>#" class="btn btn-02"><img src="<?php echo e(@$contentPage->ios->image); ?>" /></a>
                                </div>
                                <!-- / box -->
                                <div class="description"><?php echo e(@$contentPage->ios->note); ?></div>
                                <a href="<?php echo e(@$contentPage->ios->link); ?>" class="btn btn-03"><?php echo e(@$contentPage->ios->nut); ?></a>
                            </div>
                        </div>
                        <!-- / item -->
                        <div class="col-md-6 col-12 item">
                            <div class="item-wrapper">
                                <div class="item-box">
                                    <div class="stars">
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                        <svg width="30" height="29" viewBox="0 0 30 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M14.2874 1.39629C14.5843 0.814487 15.4157 0.814487 15.7126 1.39629L19.6113 9.03592C19.7276 9.2637 19.9457 9.42218 20.1982 9.46234L28.6688 10.8095C29.3138 10.9121 29.5707 11.7027 29.1092 12.1649L23.0482 18.2336C22.8675 18.4146 22.7842 18.671 22.824 18.9236L24.1603 27.3958C24.2621 28.041 23.5895 28.5297 23.0074 28.2335L15.3627 24.3445C15.1348 24.2286 14.8652 24.2286 14.6373 24.3445L6.99264 28.2335C6.41046 28.5297 5.7379 28.041 5.83967 27.3958L7.17597 18.9236C7.21581 18.671 7.1325 18.4146 6.95179 18.2336L0.890847 12.1649C0.429273 11.7027 0.686165 10.9121 1.33124 10.8095L9.80175 9.46234C10.0543 9.42218 10.2724 9.2637 10.3887 9.03592L14.2874 1.39629Z"
                                                fill="#FFAF00"
                                            />
                                        </svg>
                                    </div>
                                    <div class="number">
                                        <?php echo @$contentPage->android->sao; ?>

                                    </div>
                                    <a href="<?php echo e(@$contentPage->android->link); ?>#" class="btn btn-02"><img src="<?php echo e(@$contentPage->android->image); ?>" /></a>
                                </div>
                                <!-- / box -->
                                <div class="description"><?php echo e(@$contentPage->android->note); ?></div>
                                <a href="<?php echo e(@$contentPage->android->link); ?>" class="btn btn-03"><?php echo e(@$contentPage->android->nut); ?></a>
                            </div>
                        </div>
                        <!-- / item -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- review -->

   
    <section class="box-banner-shop">
        <div class="container">
            <div class="banner-shop">
                <div class="avr-banner">
                    <img src="<?php echo e(__BASE_URL__); ?>/images/bn-shop.png" class="img-fluid w-100 show-pc"  alt="Tải app ngay" />
                    <img src="<?php echo e(__BASE_URL__); ?>/images/bn-shop-mb.png" class="img-fluid w-100 show-mb d-none"  alt="Tải app ngay" />
                </div>
                <div class="caption">
                    <p><?php echo e(@$site_info->chung_title1); ?></p>
                    <h5><?php echo e(@$site_info->chung_title2); ?></h5>
                    <p><?php echo e(@$site_info->chung_title3); ?></p>
                    <div class="app-bn">
                        <div class="left">
                            <img src="<?php echo e(@$site_info->qr); ?>" class="img-fluid" alt="Tải app ngay" />
                        </div>
                        <div class="right">
                            <ul>
                                <li><a href="<?php echo e(@$site_info->chung_link_ios); ?>"><img src="<?php echo e(@$site_info->chung_logo_ios); ?>" class="img-fluid"  alt="Tải app ngay" /></a></li>
                                <li><a href="<?php echo e(@$site_info->chung_link_chplay); ?>"><img src="<?php echo e(@$site_info->chung_logo_chplay); ?>" class="img-fluid"  alt="Tải app ngay" /></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="phone-abs"><img src="<?php echo e(@$site_info->feapp); ?>" class="img-fluid" alt="" /></div>
            </div>
        </div>
    </section>
    <!-- voucher -->
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/slash/domains/getslash.tuvanweb.com/public_html/resources/views/frontend/pages/home/index.blade.php ENDPATH**/ ?>