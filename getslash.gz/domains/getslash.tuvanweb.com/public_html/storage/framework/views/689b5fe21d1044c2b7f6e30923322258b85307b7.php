<div class="side-bar-news">
	<div class="title-bar jose">Tin tức mới nhất</div>
	<div class="list-new-bar">
		<?php if(!empty($list_news)): ?>
			<?php $__currentLoopData = $list_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="item">
					<div class="avarta">
						<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>">
							<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>">
						</a>
					</div>
					<div class="info">
						<h4>
							<a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>">
								<?php echo e(text_limit($item->name, 9)); ?>...
							</a>
						</h4>
						<div class="date"><?php echo e($item->created_at->format('d/m/Y')); ?></div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>
</div><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/frontend/teamplate/side-bar.blade.php ENDPATH**/ ?>