<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="<?php echo e($site_info->favicon); ?>">
	<?php if(isset($site_info->index_google)): ?>
		<meta name="robots" content="<?php echo e($site_info->index_google == 1 ? 'index, follow' : 'noindex, nofollow'); ?>">
	<?php else: ?>
		<meta name="robots" content="noindex, nofollow">
	<?php endif; ?>
	<?php echo SEO::generate(); ?>

	<meta property="og:url" content="<?php echo e(url('/')); ?>" />
	<meta http-equiv="content-language" content="vi" />
	<meta name="geo.region" content="VN" />
    <meta name="geo.placename" content="Hà Nội" />
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
 	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
 	<link rel="canonical" href="<?php echo e(\Request::fullUrl()); ?>">

	<!--link css-->
	<link rel="stylesheet" type="text/css" title="" href="https://channel.mediacdn.vn/Magazine/web20200701032610/css/fancybox.min.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/font-awesome.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/slick.min.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/slick-theme.min.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/jquery.mmenu.all.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/animate.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/style.css">
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/css/responsive.css?v=1">

	<!--plugin by Trọng Học Giỏi-->
	<link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/plugin/jquery.toast.min.css">
    <script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/jquery.min.js"></script>

 	<?php if(!empty($site_info->google_analytics)): ?>
 		<?php echo $site_info->google_analytics; ?>

 	<?php endif; ?>

	<?php echo $__env->yieldContent('css'); ?>
	
 	<script>
 		var base_url = "<?php echo e(__BASE_URL__); ?>";
 		var base = "<?php echo e(url('/')); ?>";
 	</script>
</head> 
	<body>
		<?php echo $__env->make('frontend.teamplate.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->yieldContent('main'); ?>

		<?php echo $__env->make('frontend.teamplate.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<script type="text/javascript" src="https://channel.mediacdn.vn/Magazine/web20200701032610/js/fancybox.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/slick.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/wow.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/jquery.mmenu.all.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/private.js"></script>

		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/plugin/jquery.toast.min.js"></script>
		<?php echo $__env->yieldContent('script'); ?>
		<?php if(Session::has('toastr')): ?>
			<script>
				function showToast(text, heading){
				    $.toast({
				        text: text,
				        heading: heading,
				        icon: 'success',
				        showHideTransition: 'fade',
				        allowToastClose: false,
				        hideAfter: 3000,
				        stack: 5,
				        position: 'top-right',
				        textAlign: 'left', 
				        loader: true, 
				        loaderBg: '#9ec600',
				    });   
				}
				jQuery(document).ready(function($) {
					showToast('<?php echo e(Session::get('toastr')); ?>', 'Thông báo');
				});
			</script>
		<?php endif; ?>
	</body>
</html><?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/frontend/master.blade.php ENDPATH**/ ?>