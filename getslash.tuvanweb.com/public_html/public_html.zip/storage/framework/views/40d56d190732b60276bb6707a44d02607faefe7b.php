<?php $__env->startSection('main'); ?>
	<main class="page-wrapper bg-white">
		<section class="contact pd-60">
			<div class="container">
				<div class="contact-info">
					<div class="row">
						<div class="col-md-4">
							<h2 class="title title-lg">thông tin về chúng tôi</h2>
							<h3>Địa chỉ</h3>
							<p><?php echo @$site_info->address; ?></p>
							<h3 class="mgt-20">Số điện thoại</h3>
							<p><a href="tel:<?php echo @$site_info->hotline; ?>" title=""><?php echo @$site_info->hotline; ?></a> </p>
							<h3 class="mgt-20">Email</h3>
							<p><a href="" title=""><?php echo @$site_info->email; ?></a> </p>
						</div>
						<div class="col-md-6 offset-md-2">
							<div class="map">
								<?php echo @$site_info->script; ?>

							</div>
						</div>
					</div>
				</div>
				<div class="contact-form">
					<div class="row">
						<div class="col-md-4">
							<h2 class="title title-lg">Liên hệ với chúng tôi</h2>
							<h3 class="line-16">Hãy để lại thông tin của bạn cho chúng tôi. Chúng tôi sẽ liên hệ với bạn sớm nhất có thể.</h3>
						</div>
						<div class="col-md-5 offset-md-3">
							<form class="form-box" action="<?php echo e(route('home.contact.post')); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<input type="text" placeholder="Họ tên" class="form-control" name="name">
								<input type="email" placeholder="Email" class="form-control" name="email">
								<input type="text" placeholder="Số điện thoại" class="form-control" name="phone">
								<textarea placeholder="Nội dung" class="form-control" name="content"></textarea>
								<div class="text-right mgt-30"><button type="submit" class="btn-submit">Gửi</button> </div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\batdongsan\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>