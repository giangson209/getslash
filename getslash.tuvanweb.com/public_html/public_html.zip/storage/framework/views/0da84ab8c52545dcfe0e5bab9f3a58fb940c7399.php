
<?php $__env->startSection('main'); ?>
    <main class="page-wrapper bg-gray">
        <section class="products pd-60">
            <div class="container">
                <div class="products-nav flex-center-between">
                    <h1 class="title title-lg">sản phẩm</h1>
                </div>
                <div class="products-blocks">
                    <div class="row">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="products-item">
                                    <h4 class="pro-name"><a href="<?php echo e($item->url); ?>" title=""><?php echo e($item->name); ?></a> </h4>
                                    <div class="price">
                                        <?php if(!empty($item->sale)): ?>
                                            <span class="new-price"><?php echo e(number_format($item->sale_price, 0, '.','.')); ?> VND</span>
                                            <span class="old-price"><?php echo e(number_format($item->regular_price, 0, '.','.')); ?> VND</span>
                                        <?php else: ?>
                                            <span class="new-price"><?php echo e(number_format($item->regular_price, 0, '.','.')); ?> VND</span>
                                        <?php endif; ?>
                                    </div>
                                    <a href="<?php echo e($item->url); ?>" class="pro-image zoom" title="">
                                        <img src="<?php echo e($item->image); ?>" alt="">
                                    </a>
                                    <div class="text-center"><a href="<?php echo e($item->add_cart_url); ?>" title="" class="btn btn-blue mgt-30">Mua ngay</a></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="pagination mgt-30">
                    <ul class="list-inline w-100 text-right">
                        <?php echo $data->links(); ?>

                    </ul>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/home-tech/resources/views/frontend/pages/products/list-products.blade.php ENDPATH**/ ?>