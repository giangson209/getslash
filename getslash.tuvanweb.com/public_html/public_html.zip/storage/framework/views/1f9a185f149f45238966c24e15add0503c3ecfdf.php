<?php $id = isset($id) ? $id : (int) round(microtime(true) * 1000); ?>
<tr>
    <td class="index"><?php echo e($index); ?></td>
    <td>
        <div class="form-group">
            <label>Logo</label>
            <div class="image">
                <div class="image__thumbnail">
                    <img src="<?php echo e(!empty($value->logo) ?  $value->logo : __IMAGE_DEFAULT__); ?>"
                         data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
                    <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
                        <i class="fa fa-times"></i></a>
                    <input type="hidden" value="<?php echo e(@$value->logo); ?>" name="content[partner][<?php echo e($id); ?>][logo]"  />
                    <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
                </div>
            </div>
        </div>
    </td>
    <td>
        <div class="form-group">
            <label>Tiêu đề</label>
            <input type="text" name="content[partner][<?php echo e($id); ?>][name]" class="form-control" value="<?php echo e(@$value->name); ?>">
        </div>
        <div class="form-group">
            <label>Liên kết</label>
            <input type="text" name="content[partner][<?php echo e($id); ?>][link]" class="form-control" value="<?php echo e(@$value->link); ?>">
        </div>
    </td>
    <td style="text-align: center;">
        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
            <i class="fa fa-minus"></i>
        </a>
    </td>
</tr>
<?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/backend/repeater/row-partner.blade.php ENDPATH**/ ?>