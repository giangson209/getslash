<?php $__env->startSection('main'); ?>
    <section class="banner">
        <div class="slide-banner">
            <div class="item-banner">
                <div class="avarta"><img src="<?php echo e(@$content->top->banner); ?>" class="img-fluid w-100" alt=""></div>
                <div class="caption">
                    <div class="container">
                        <h3 class="text-uppercase "><?php echo e(@$content->top->title_1); ?></h3>
                        <h1><?php echo e(@$content->top->title_2); ?></h1>
                        <div class="desc"><?php echo e(@$content->top->desc); ?></div>
                        <div class="btn-beatay">
                            <a href="<?php echo e(@$content->top->link); ?>" class="text-uppercase"><?php echo app('translator')->getFromJson('site.explore_now'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="box-number">
        <div class="container">
            <div class="list-number">
                <div class="row">
                    <?php if(!empty(@$content->summary)): ?>
                        <?php $__currentLoopData = @$content->summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="item-number text-center">
                                    <div class="numb"><?php echo e(@$value->title); ?></div>
                                    <div class="desc"><?php echo e(@$value->desc); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <section class="box-trending">
        <div class="container">
            <div class="title">
                <h4 class="text-uppercase"><?php echo app('translator')->getFromJson('site.trending_styles'); ?></h4>
                <h2><?php echo app('translator')->getFromJson('site.for_your_space'); ?></h2>
            </div>
            <div class="list-trend">
                <?php $__currentLoopData = $styles ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-trend">
                    <div class="row align-items-center">
                        <div class="col-md-7">
                            <div class="avarta">
                                <a href="<?php echo e(route('styles.single', $item->slug)); ?>">
                                    <img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="txt-trend">
                                <div class="year"><?php echo e($item->created_at->format('Y')); ?></div>
                                <h3><a href="<?php echo e(route('styles.single', $item->slug)); ?>"><?php echo e($item->{ 'name_'.locale() }); ?></a></h3>
                                <div class="desc">
                                    <?php echo e($item->{ 'desc_'.locale() }); ?>

                                </div>
                                <div class="view-more">
                                    <a href="<?php echo e(route('styles.single', $item->slug)); ?>"><?php echo app('translator')->getFromJson('site.view_more'); ?>
                                        <img src="<?php echo e(__BASE_URL__); ?>/images/more.svg" class="img-fluid" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <section class="box-partner">
        <div class="avarta">
            <img src="<?php echo e(__BASE_URL__); ?>/images/partner.jpg" class="img-fluid w-100" alt="">
            <div class="title">
                <div class="container">
                    <h4 class="text-uppercase"><?php echo app('translator')->getFromJson('site.partners'); ?></h4>
                    <h2><?php echo app('translator')->getFromJson('site.proud_cooperations'); ?></h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="slide-part">
                <?php if(!empty(@$content->partner)): ?>
                    <?php $__currentLoopData = @$content->partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item-slide">
                            <div class="item-part">
                                <a href="<?php echo e($value->link); ?>"><img src="<?php echo e($value->logo); ?>" class="img-fluid" alt=""></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php echo $__env->make('frontend.pages.contact.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bestay\resources\views/frontend/pages/home/index.blade.php ENDPATH**/ ?>