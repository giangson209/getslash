<?php $__env->startSection('controller', 'Danh mục tin tức' ); ?>
<?php $__env->startSection('controller_route', route('categories-post.index')); ?>
<?php $__env->startSection('action', 'Danh sách'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
        	<div class="col-sm-5">
	        	<form action="<?php echo updateOrStoreRouteRender( @$module['action'], $module['module'], @$data); ?>" method="POST">
	        		<?php echo csrf_field(); ?>
					<?php if(isUpdate(@$module['action'])): ?>
				        <?php echo e(method_field('put')); ?>

				    <?php endif; ?>
	        		<div class="nav-tabs-custom">
		                <ul class="nav nav-tabs">
		                    <li class="active">
		                        <a href="#activity" data-toggle="tab" aria-expanded="true">Danh mục</a>
		                    </li>
		                    <?php if( request('type') !== 'faq' && request('type') !== 'faq-merchant'): ?>
		                    <li class="">
		                    	<a href="#setting1" data-toggle="tab" aria-expanded="true">Cấu hình seo </a>
		                    </li>
                             <?php endif; ?>
		                </ul>
		                <div class="tab-content">
		                    <div class="tab-pane active" id="activity">
								<div class="form-group">
									<label for="">Tên danh mục </label>
									<input type="text" class="form-control" name="name_vi" value="<?php echo e(old('name_vi', @$data->name_vi)); ?>">
								</div>
								<div class="form-group <?php echo e(request('type') == 'faq' ? 'hide' : ''); ?> <?php echo e(request('type') == 'faq-merchan' ? 'hide' : ''); ?>">
									<label for="">Đường dẫn tĩnh</label>
									<input type="text" class="form-control" name="slug" id="slug" value="<?php echo e(old('slug', @$data->slug)); ?>">
								</div>
		                        <?php if( request('type') == 'faq' || request('type') == 'faq-merchant'): ?>
                    			<div class="form-group">
                    				<label for="">Hình ảnh</label>
                    				 <div class="image">
			                            <div class="image__thumbnail">
			                                <img src="<?php echo e(!empty($data->icon) ? $data->icon : __IMAGE_DEFAULT__); ?>"
			                                     data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                <input type="hidden" value="<?php echo e(old('icon', @$data->icon)); ?>" name="icon"/>
			                                <div class="image__button" onclick="fileSelect(this)">
			                                	<i class="fa fa-upload"></i>
			                                    Upload
			                                </div>
			                            </div>
			                        </div>
                    			</div>
                                <?php endif; ?>
		                    </div>
		                    <div class="tab-pane" id="setting1">
		                    	<div class="row">
		                    		<div class="col-sm-12">
		                    			<div class="form-group">
		                    				<label for="">Hình ảnh</label>
		                    				 <div class="image">
					                            <div class="image__thumbnail">
					                                <img src="<?php echo e(!empty($data->image) ? $data->image : __IMAGE_DEFAULT__); ?>"
					                                     data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                <input type="hidden" value="<?php echo e(old('image', @$data->image)); ?>" name="image"/>
					                                <div class="image__button" onclick="fileSelect(this)">
					                                	<i class="fa fa-upload"></i>
					                                    Upload
					                                </div>
					                            </div>
					                        </div>
		                    			</div>
		                    		</div>
		                    		<div class="col-sm-12">
		                    			 <div class="form-group">
				                            <label>Title SEO</label>
				                            <input type="text" class="form-control" name="meta_title_vi" value="<?php echo old('meta_title_vi',  @$data->meta_title_vi); ?>">
				                        </div>

				                        <div class="form-group">
				                            <label>Meta Description</label>
				                            <textarea name="meta_description_vi" id="" class="form-control" rows="5"><?php echo old('meta_description_vi', @$data->meta_description_vi); ?></textarea>
				                        </div>

				                        <div class="form-group">
				                            <label>Meta Keyword</label>
				                            <input type="text" class="form-control" name="meta_keyword_vi" value="<?php echo old('meta_keyword_vi',@$data->meta_keyword_vi); ?>">
				                        </div>
		                    		</div>
		                    	</div>
		                    </div>
		                    <button type="submit" class="btn btn-primary">Lưu lại</button>
		                </div>
		            </div>
	        	</form>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\slash\resources\views/backend/categories-post/edit.blade.php ENDPATH**/ ?>