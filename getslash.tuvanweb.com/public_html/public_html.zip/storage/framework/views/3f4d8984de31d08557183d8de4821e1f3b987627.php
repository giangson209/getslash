
<?php $__env->startSection('main'); ?>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Tìm kiếm từ khóa: <?php echo e(request()->get('q')); ?></a></li>
				</ul>
			</div>
		</div>
	</section>


	<section id="product">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="right-product">
							<div class="tab-pane pane-prd active" style="background: #fff;">
								<div class="list-product">
									<div class="row">
										<?php if(count($data)): ?>
											<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="col-lg-2 col-sm-2 col-6">
													<?php $__env->startComponent('frontend.components.product', ['item' => $item]); ?>
													    
													<?php echo $__env->renderComponent(); ?>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
											<div class="col-sm-12">
												<div class="alert alert-success" role="alert">
												  	Không có sản phẩm nào phù hợp.
												</div>
											</div>
										<?php endif; ?>
										
										
										<div class="col-sm-12">
											<div class="pagination" style="padding-top: 30px; padding-bottom: 30px">
												<ul class="list-inline text-center">
													<?php echo $data->appends(request()->except('page'))->links(); ?>

												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu2/resources/views/frontend/pages/search.blade.php ENDPATH**/ ?>