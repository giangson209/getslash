
<?php $__env->startSection('main'); ?>
	<h1 style="display: none;"><?php echo e(@$dataSeo->title_h1); ?></h1>
	<?php echo $__env->make('frontend.teamplate.breadcrumbs', [ 
		'config' => [
			'banner' => @$dataSeo->banner,
			'title' => 'Thiết kế website'
		] 
	], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<section id="feed-back" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="list-feedback">
					<div class="row">
						<?php if(!empty($data)): ?>
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4 col-sm-4">
									<div class="item">
										<div class="avarta">
											<a href="<?php echo e($item->link); ?>" target="_blank" title="<?php echo e($item->name); ?>">
												<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" 
												alt="<?php echo e($item->name); ?>">
											</a>
											<div class="view-abs">
												<div class="btn-view">
													<a href="<?php echo e($item->link); ?>" target="_blank" title="Xem chi tiết">Xem Chi tiết</a>
												</div>
											</div>
										</div>
										<div class="info">
											<h3><a href="<?php echo e($item->link); ?>" target="_blank" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a></h3>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<div class="col-md-12">
							<div class="pagination">
								<?php echo $data->links(); ?>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/pages/projects.blade.php ENDPATH**/ ?>