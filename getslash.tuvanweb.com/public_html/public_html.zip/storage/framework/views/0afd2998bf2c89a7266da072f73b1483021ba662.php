<?php if(count($data)): ?>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $__env->startComponent('frontend.components.product-style-3', ['item'=> $item]); ?>

		<?php echo $__env->renderComponent(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/bephungphu/public_html/resources/views/frontend/components/loop-products-brand/loop-brand-style-2.blade.php ENDPATH**/ ?>