
<?php $__env->startSection('controller', 'Thuộc tính' ); ?>
<?php $__env->startSection('controller_route', route('product-attributes.index', ['type' => request('type')])); ?>
<?php $__env->startSection('action', 'Thêm mới'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
        <div class="clearfix"></div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
        	<div class="col-sm-5">
	        	<form action="<?php echo e(route('product-attributes.store')); ?>" method="POST">
	        		<?php echo csrf_field(); ?>
	        		<input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
	        		<div class="nav-tabs-custom">
		                <ul class="nav nav-tabs">
		                    <li class="active">
		                        <a href="#activity" data-toggle="tab" aria-expanded="true">Thuộc tính</a>
		                    </li>
		                </ul>
		                <div class="tab-content">
		                    <div class="tab-pane active" id="activity">
								<div class="form-group">
									<label for="">Tên thuộc tính</label>
									<input type="text" class="form-control" name="name" id="name" required="" value="<?php echo e(old('name')); ?>">
								</div>
								<?php if(request('type') == 'color_attributes'): ?>
									<div class="form-group">
										<label for="">Chọn màu sắc</label>
										<input id="color-picker" name="desc" value="" class="form-control" required="">
									</div>
								<?php endif; ?>
		                    </div>
		                    <button type="submit" class="btn btn-primary">Lưu lại</button>
		                </div>
		            </div>
	        	</form>
	        </div>
	        <div class="col-sm-7">
	        	<div class="box box-primary">
	                <div class="box-body">
	                    <table id="example1" class="table table-bordered table-striped table-hover">
	                        <thead>
	                            <tr>
	                                <th style="width: 15px"><input type="checkbox" name="chkAll" id="chkAll"></th>
	                                <th style="width: 15px">STT</th>
	                                <th>Tiêu đề</th>
	                                <th style="width: 150px">Thao tác</th>
	                            </tr>
	                        </thead>
	                        <tbody>
	                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <tr>
	                                    <td><input type="checkbox" name="chkItem[]" value="<?php echo e($item->id); ?>"></td>
	                                    <td><?php echo e($loop->index + 1); ?></td>
	                                    <td><?php echo e($item->name); ?></td>
	                                    <td>
	                                        <a href="<?php echo e(route('product-attributes.edit', ['id' => $item->id, 'type' => $item->type])); ?>" title="Sửa">
	                                            <i class="fa fa-pencil fa-fw"></i> Sửa
	                                        </a> &nbsp; &nbsp; &nbsp;
	                                        <a href="javascript:;" class="btn-destroy" data-href="<?php echo e(route('product-attributes.destroy', $item->id)); ?>"
				                            data-toggle="modal" data-target="#confim">
				                            <i class="fa fa-trash-o fa-fw"></i> Xóa</a>
	                                    </td>
	                                </tr>
	                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                        </tbody>
	                    </table>
	                </div>
	            </div>
	        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/spectrum-colorpicker2@2.0.0/dist/spectrum.min.css">
	<script src="https://cdn.jsdelivr.net/npm/spectrum-colorpicker2@2.0.0/dist/spectrum.min.js"></script>
	<script>
		jQuery(document).ready(function($) {
			$('#color-picker').spectrum({
			  	type: "text"
			});
		});	
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/vongtay/resources/views/backend/product-attributes/index.blade.php ENDPATH**/ ?>