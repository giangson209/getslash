<?php if(count($menuCategory)): ?>
    <?php $__currentLoopData = $menuCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($item->parent_id == null): ?>
            <li>
                <a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>">
                    <img data-src="<?php echo e($item->icon); ?>" class="img-fluid lazyload" alt="<?php echo e($item->title); ?>"><?php echo e($item->title); ?>

                </a>
                <?php if(count($item->get_child_cate())): ?>
                    <div class="mega-menu">
                        <div class="row">
                            <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->index == 0): ?>
                                    <div class="col-md-3">
                                        <div class="item">
                                            <div class="mega-tt"><?php echo e($value->title); ?></div>
                                            <?php if(count($value->get_child_cate())): ?>
                                                <ul>
                                                    <?php $__currentLoopData = $value->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a title="<?php echo e($child->title); ?>" href="<?php echo e(url($child->url)); ?>"><?php echo e($child->title); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-9">
                                        <div class="item">
                                            <div class="mega-tt"><?php echo e($value->title); ?></div>
                                            <div class="mega-right">
                                                <?php if(count($value->get_child_cate())): ?>
                                                    <ul>
                                                        <?php $__currentLoopData = $value->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a title="<?php echo e($child->title); ?>" href="<?php echo e(url($child->url)); ?>"><?php echo e($child->title); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </li>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu2/resources/views/frontend/teamplate/parts-header/category-list.blade.php ENDPATH**/ ?>