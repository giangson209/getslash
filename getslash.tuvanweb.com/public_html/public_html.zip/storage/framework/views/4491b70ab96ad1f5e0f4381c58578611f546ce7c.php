
<?php $__env->startSection('controller', getTitleServiceBackend()['title'] ); ?>
<?php $__env->startSection('controller_route', getTitleServiceBackend()['linkList']); ?>
<?php $__env->startSection('action','Danh sách'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('accompanied-services.postMultiDel')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="<?php echo e(request()->get('type')); ?>">
                    <div class="btnAdd">
                        <a href="<?php echo e(getTitleServiceBackend()['linkAdd']); ?>">
                            <fa class="btn btn-primary"><i class="fa fa-plus"></i> Thêm</fa>
                        </a>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa ?')"><i class="fa fa-trash-o"></i> Xóa
                        </button>

                        <?php if( request()->get('type') == 'hosting' || request()->get('type') == 'vps'): ?>
                            <a href="<?php echo e(route('accompanied-services.index', ['type' => 'additional-'.request()->get('type') ])); ?>" 
                                class="btn btn-success">
                                <i class="fa fa-tags"></i> Dịch vụ bổ sung
                            </a>
                        <?php endif; ?>
                    </div>

                    <table id="example1" class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="50px"><input type="checkbox" name="chkAll" id="chkAll"></th>
                                <th width="50px">STT</th>
                                <th width="">Tên dịch vụ</th>
                                <th width="">Giá</th>
                                <th width="">Trạng thái</th>
                                <th width="<?php echo e(request()->get('type') == 'hosting' || request()->get('type') == 'email' ? '250px' : '150px'); ?>">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input type="checkbox" name="chkItem[]" value="<?php echo $item['id']; ?>"></td>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td>
                                        <?php echo $item->name; ?>

                                        <?php if(count($item->get_servives_child())): ?>
                                            ( <?php echo e(count($item->get_servives_child())); ?> gói theo tháng )
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(number_format($item->price)); ?>đ</td>
                                    <td>
                                        <?php if($item->status == 1 ): ?>
                                            <span class="label label-success">Đang hiển thị</span>
                                        <?php else: ?>
                                            <span class="label label-danger">Đang ẩn</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div>
                                            <a href="<?php echo e(route('accompanied-services.edit', ['id'=> $item->id, 'type' => $item->type])); ?>" title="Sửa">
                                                <i class="fa fa-pencil fa-fw"></i> Sửa
                                            </a> &nbsp; &nbsp; &nbsp;
                                              <a href="javascript:void(0);" class="btn-destroy" 
                                              data-href="<?php echo e(route( 'accompanied-services.destroy',  $item->id )); ?>"
                                              data-toggle="modal" data-target="#confim">
                                              <i class="fa fa-trash-o fa-fw"></i> Xóa
                                            </a>
                                            <?php if($item->type == 'hosting' || $item->type == 'email'): ?>
                                                &nbsp; &nbsp; &nbsp;
                                                <a href="<?php echo e(route('package.list', ['parent_id'=> $item->id, 'type' => $item->type])); ?>" title="Thêm gói theo tháng">
                                                    <i class="fa fa-plus fa-fw"></i> Thêm gói theo tháng
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/backend/services/accompanied-services/list.blade.php ENDPATH**/ ?>