<footer>
	<div class="clc-backtop">
		<a href="javascript:0"><i class="fa fa-angle-up"></i></a>
	</div> 
	<div class="footer-top">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-4">
						<div class="logo">
							<a href="<?php echo e(url('/')); ?>" title="<?php echo e(@$site_info->site_title); ?>">
								<img src="<?php echo e(@$site_info->footer_logo); ?>" class="img-fluid" 
								alt="<?php echo e(@$site_info->site_title); ?>">
							</a>
						</div>
					</div>
					
						
							
	                            
	                                
	                                    
	                                
	                            
	                        
						
					
				</div>
			</div>
			<div class="list-place">
				<div class="row">
					<?php if(!empty($site_info->address)): ?>
						<?php $__currentLoopData = $site_info->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-lg-3 col-md-6 col-sm-6">
								<div class="item">
									<h3><?php echo e(@$value->title); ?></h3>
									<ul>
										<li><i class="fa fa-map-marker"></i><?php echo e(@$value->address); ?></li>
										<li><i class="fa fa-phone"></i><?php echo e(@$value->phone); ?></li>
										<li><i class="fa fa-envelope"></i><?php echo e(@$value->email); ?></li>
									</ul>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
	<div class="reserved">
		<div class="container">
			<div class="content">
				<div class="row">
					<div class="col-md-6">
						<div class="left">
							<?php echo e(@$site_info->copyright); ?>

						</div>
					</div>
					<div class="col-md-6">
						<div class="social">
							<ul class="list-inline text-right">
								<?php if(!empty($site_info->social)): ?>
									<?php $__currentLoopData = $site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="list-inline-item">
											<a href="<?php echo e(@$value->link); ?>" title="<?php echo e(@$value->name); ?>" target="_blank">
												<i class="<?php echo e(@$value->icon); ?>"></i>
											</a>
										</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?> 
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/teamplate/footer.blade.php ENDPATH**/ ?>