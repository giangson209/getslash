<?php $__env->startSection('controller','Trang'); ?>
<?php $__env->startSection('controller_route',route('pages.list')); ?>
<?php $__env->startSection('action','Danh sách'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo e(route('pages.build.post')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input name="type" value="<?php echo e($data->type); ?>" type="hidden">

					<div class="row">
						<div class="col-sm-12">
							<div class="form-group">
								<label for="">Trang</label>
								<input type="text" class="form-control" value="<?php echo e($data->name_page); ?>" disabled="">
				 				
								<?php if(\Route::has($data->route)): ?>
									<h5>
										<a href="<?php echo e(route($data->route)); ?>" target="_blank">
					                        <i class="fa fa-hand-o-right" aria-hidden="true"></i>
					                        Link: <?php echo e(route($data->route)); ?>

					                    </a>
									</h5>
				                <?php endif; ?>
							</div>
							
						</div>
					</div>
					<div class="nav-tabs-custom">
				        <ul class="nav nav-tabs">
				            <li class="active">
				            	<a href="#activit1" data-toggle="tab" aria-expanded="true">Tại sao chọ dimaweb</a>
				            </li>
				            <li class="">
				            	<a href="#activit2" data-toggle="tab" aria-expanded="true">Dịch vụ dimaweb</a>
				            </li>
				        </ul>
				    </div>
				    <?php if(!empty($data->content)){
						$content = json_decode($data->content);
					} ?>
				    <div class="tab-content">
			            <div class="tab-pane active" id="activit1">
			            	<div class="row">
			            		<div class="col-sm-12">
			            			<div class="form-group">
			            				<label for="">Tiêu đề khối</label>
			            				<input type="text" class="form-control" name="content[sec_why][title]"
			            				value="<?php echo e(@$content->sec_why->title); ?>">
			            			</div>
			            		</div>
								
								<div class="col-sm-12">
	                       			<label for="">Thông tin</label>
	                       			<div class="repeater" id="repeater">
	        			                <table class="table table-bordered table-hover">
	        			                    <thead>
	        				                    <tr>
	        				                    	<th style="width: 30px;">STT</th>
	        				                    	<th style="width: 200px;">Icon</th>
	        				                    	<th>Nội dung</th>
	        				                    	<th style="width: 30px;"></th>
	        				                    </tr>
	        			                	</thead>
	        			                    <tbody id="sortable">
												<?php if(!empty($content->sec_why->content)): ?>
													<?php $__currentLoopData = $content->sec_why->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<td class="index"><?php echo e($loop->index + 1); ?></td>
															<td>
														       <label>Icon</label>
														       <div class="image">
														           <div class="image__thumbnail">
														               <img src="<?php echo e(!empty($value->icon) ? $value->icon : __IMAGE_DEFAULT__); ?>"  
														               data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
														               <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
														                <i class="fa fa-times"></i></a>
														               <input type="hidden" 
														               value="<?php echo e(@$value->icon); ?>" 
														               name="content[sec_why][content][<?php echo e($key); ?>][icon]"  />
														               <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
														           </div>
														       </div>
															</td>
															<td>
																<div class="form-group">
																	<label for="">Tiêu đề</label>
																	<input type="text" name="content[sec_why][content][<?php echo e($key); ?>][title]" class="form-control" value="<?php echo e(@$value->title); ?>">
																</div>
																<div class="form-group">
																	<label for="">Mô tả</label>
																	<textarea class="form-control" name="content[sec_why][content][<?php echo e($key); ?>][desc]" rows="5"><?php echo @$value->desc; ?></textarea>
																</div>
															</td>
														<td style="text-align: center;">
													        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
													            <i class="fa fa-minus"></i>
													        </a>
													    </td>
														</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
	        			                    </tbody>
	        			                </table>

	        			                <div class="text-right">
	        			                    <button class="btn btn-primary" onclick="repeater(event,this,'<?php echo e(route('get.layout')); ?>','.index', 'services-home')">Thêm</button>
	        			                </div>
	        			            </div>
	                       		</div>

			            	</div>
			            </div>
			            <div class="tab-pane" id="activit2">
			            	<div class="row">
			            		<div class="col-sm-12">
			            			<div class="form-group">
			            				<label for="">Tiêu đề khối</label>
			            				<input type="text" class="form-control" name="content[sec_services][title]"
			            				value="<?php echo e(@$content->sec_services->title); ?>">
			            			</div>
			            		</div>
			            		<div class="col-sm-4">
			            			<div class="row">
			            				<div class="col-sm-6">
			            					<div class="form-group">
					                           <label>Icon màu</label>
					                           <div class="image">
					                               <div class="image__thumbnail">
					                                   <img src="<?php echo e(@$content->sec_services->service_1->icon ? @$content->sec_services->service_1->icon  : __IMAGE_DEFAULT__); ?>"  
					                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                   <input type="hidden" value="<?php echo e(@$content->sec_services->service_1->icon); ?>" 
					                                   name="content[sec_services][service_1][icon]"  />
					                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
					                               </div>
					                           </div>
					                       </div>
			            				</div>
			            				<div class="col-sm-6">
			            					<div class="form-group">
					                           <label>Icon trắng</label>
					                           <div class="image">
					                               <div class="image__thumbnail">
					                                   <img src="<?php echo e(@$content->sec_services->service_1->icon_white ?  @$content->sec_services->service_1->icon_white : __IMAGE_DEFAULT__); ?>"  
					                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                   <input type="hidden" value="<?php echo e(@$content->sec_services->service_1->icon_white); ?>" name="content[sec_services][service_1][icon_white]"  />
					                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
					                               </div>
					                           </div>
					                       </div>
			            				</div>
			            			</div>
			            			<div class="form-group">
			            				<label for="">Tiêu đề</label>
			            				<input type="text" class="form-control" name="content[sec_services][service_1][title]" value="<?php echo e(@$content->sec_services->service_1->title); ?>">
			            			</div>
			            			<div class="form-group">
			            				<label for="">Mô tả</label>
			            				<textarea class="form-control" name="content[sec_services][service_1][desc]" rows="7"><?php echo @$content->sec_services->service_1->desc; ?></textarea>
			            			</div>
			            			<div class="form-group">
			            				<label for="">Liên kết</label>
			            				<input type="text" class="form-control" name="content[sec_services][service_1][link]" value="<?php echo @$content->sec_services->service_1->link; ?>">
			            			</div>
			            		</div>
			            		<div class="col-sm-4">
			            			<div class="row">
			            				<div class="col-sm-6">
			            					<div class="form-group">
					                           <label>Icon màu</label>
					                           <div class="image">
					                               <div class="image__thumbnail">
					                                   <img src="<?php echo e(@$content->sec_services->service_2->icon ? @$content->sec_services->service_2->icon  : __IMAGE_DEFAULT__); ?>"  
					                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                   <input type="hidden" value="<?php echo e(@$content->sec_services->service_2->icon); ?>" 
					                                   name="content[sec_services][service_2][icon]"  />
					                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
					                               </div>
					                           </div>
					                       </div>
			            				</div>
			            				<div class="col-sm-6">
			            					<div class="form-group">
					                           <label>Icon trắng</label>
					                           <div class="image">
					                               <div class="image__thumbnail">
					                                   <img src="<?php echo e(@$content->sec_services->service_2->icon_white ?  @$content->sec_services->service_2->icon_white : __IMAGE_DEFAULT__); ?>"  
					                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                   <input type="hidden" value="<?php echo e(@$content->sec_services->service_2->icon_white); ?>" name="content[sec_services][service_2][icon_white]"  />
					                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
					                               </div>
					                           </div>
					                       </div>
			            				</div>
			            			</div>
			            			<div class="form-group">
			            				<label for="">Tiêu đề</label>
			            				<input type="text" class="form-control" name="content[sec_services][service_2][title]" value="<?php echo e(@$content->sec_services->service_2->title); ?>">
			            			</div>
			            			<div class="form-group">
			            				<label for="">Mô tả</label>
			            				<textarea class="form-control" name="content[sec_services][service_2][desc]" rows="7"><?php echo @$content->sec_services->service_2->desc; ?></textarea>
			            			</div>
			            			<div class="form-group">
			            				<label for="">Liên kết</label>
			            				<input type="text" class="form-control" name="content[sec_services][service_2][link]" value="<?php echo @$content->sec_services->service_2->link; ?>">
			            			</div>
			            		</div>
			            		<div class="col-sm-4">
			            			<div class="row">
			            				<div class="col-sm-6">
			            					<div class="form-group">
					                           <label>Icon màu</label>
					                           <div class="image">
					                               <div class="image__thumbnail">
					                                   <img src="<?php echo e(@$content->sec_services->service_3->icon ? @$content->sec_services->service_3->icon  : __IMAGE_DEFAULT__); ?>"  
					                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                   <input type="hidden" value="<?php echo e(@$content->sec_services->service_3->icon); ?>" 
					                                   name="content[sec_services][service_3][icon]"  />
					                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
					                               </div>
					                           </div>
					                       </div>
			            				</div>
			            				<div class="col-sm-6">
			            					<div class="form-group">
					                           <label>Icon trắng</label>
					                           <div class="image">
					                               <div class="image__thumbnail">
					                                   <img src="<?php echo e(@$content->sec_services->service_3->icon_white ?  @$content->sec_services->service_3->icon_white : __IMAGE_DEFAULT__); ?>"  
					                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                   <input type="hidden" value="<?php echo e(@$content->sec_services->service_3->icon_white); ?>" name="content[sec_services][service_3][icon_white]"  />
					                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
					                               </div>
					                           </div>
					                       </div>
			            				</div>
			            			</div>
			            			<div class="form-group">
			            				<label for="">Tiêu đề</label>
			            				<input type="text" class="form-control" name="content[sec_services][service_3][title]" value="<?php echo e(@$content->sec_services->service_3->title); ?>">
			            			</div>
			            			<div class="form-group">
			            				<label for="">Mô tả</label>
			            				<textarea class="form-control" name="content[sec_services][service_3][desc]" rows="7"><?php echo @$content->sec_services->service_3->desc; ?></textarea>
			            			</div>
			            			<div class="form-group">
			            				<label for="">Liên kết</label>
			            				<input type="text" class="form-control" name="content[sec_services][service_3][link]" value="<?php echo @$content->sec_services->service_3->link; ?>">
			            			</div>
			            		</div>
			            	</div>
			            </div>
			           <button type="submit" class="btn btn-primary">Lưu lại</button>
			        </div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/backend/pages/layout/home.blade.php ENDPATH**/ ?>