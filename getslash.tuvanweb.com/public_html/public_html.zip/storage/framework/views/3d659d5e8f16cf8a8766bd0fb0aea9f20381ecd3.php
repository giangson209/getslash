 <header>
    <div class="header-top">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 col-sm-6">
                    <div class="hotline">
                        <img src="<?php echo e(__BASE_URL__); ?>/images/hotline.png" class="img-fluid" alt=""> <span><?php echo e(@$site_info->hotline); ?></span>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 text-right">
                    <h2 class="text-uppercase"><?php echo e(@$site_info->name_company); ?></h2>
                </div>
            </div>
        </div>
    </div>
    <div class="header-cent">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>" title="<?php echo e(@$site_info->site_title); ?>">
                            <img src="<?php echo e(@$site_info->logo); ?>" class="img-fluid" alt="<?php echo e(@$site_info->site_title); ?>">
                        </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <form action="<?php echo e(route('home.search')); ?>">
                        <div class="box-search">
                            <input type="text" name="key" value="<?php echo e(request('key')); ?>" required="" placeholder="Tìm kiếm sản phẩm bạn yêu thích">
                            <button type="submit"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                    
                </div>
                <div class="col-md-3">
                    <div class="head-cart">
                        <a href="<?php echo e(route('home.cart')); ?>">Giỏ hàng 
                            <img src="<?php echo e(__BASE_URL__); ?>/images/cart.png" class="img-fluid" alt="">
                            <?php if(Cart::count()): ?>
                                <span><?php echo e(Cart::count()); ?></span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-menu">
        <div class="container">
            <div class="row">
                <div class="list-category">
                    <a href="javascript:void(0)">DANH MỤC SẢN PHẨM <i class="fa fa-bars"></i></a>
                    <?php if(count($menuMainMobile)): ?>
                        <ul>
                            <?php $__currentLoopData = $menuMainMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <div class="menu-right">
                    <?php if(count($menuMain)): ?>
                        <ul>
                            <?php $__currentLoopData = $menuMain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(empty($item->parent_id)): ?>
                                    <li>
                                        <a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?> <?php echo count($item->get_child_cate()) ? '<i class="fa fa-angle-down"></i>' : null; ?></a>
                                        <?php if(count($item->get_child_cate())): ?>
                                            <ul>
                                                <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                    
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="menu-mobile" style="display: none;">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-6 col-sm-6">
                    <div class="logo"> 
                        <a title="" href="<?php echo e(url('/')); ?>"><img alt="" src="<?php echo e(@$site_info->logo); ?>" class="img-fluid avarta-logo" alt=""></a>
                    </div>
                </div>
                <div class="col-md-6 col-6 col-sm-6">
                    <div class="right">
                        <div class="cart">
                            <a href="<?php echo e(route('home.cart')); ?>">
                                <img src="<?php echo e(__BASE_URL__); ?>/images/cart.png" class="img-fluid" alt="">
                                <?php if(Cart::count()): ?>
                                    <span><?php echo e(Cart::count()); ?></span>
                                <?php endif; ?>
                            </a>
                        </div>
                        <div class="header">
                            <a title="" href="#menu"><i class="fa fa-bars"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav id="menu">
            <ul>
                <li>
                    <form action="<?php echo e(route('home.search')); ?>">
                        <input type="text" name="key" value="<?php echo e(request('key')); ?>" required="" placeholder="Tìm kiếm sản phẩm bạn yêu thích">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </li>

                 <?php if(count($menuMain)): ?>
                
                    <?php $__currentLoopData = $menuMain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(empty($item->parent_id)): ?>
                            <li>
                                <a href="<?php echo e(url($item->url)); ?>"><?php echo e($item->title); ?></a>
                                <?php if(count($item->get_child_cate())): ?>
                                    <ul>
                                        <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/frontend/teamplate/header.blade.php ENDPATH**/ ?>