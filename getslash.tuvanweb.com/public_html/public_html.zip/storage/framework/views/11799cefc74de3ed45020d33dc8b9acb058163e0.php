<?php $__env->startSection('controller', getTitleServiceBackend()['title'] ); ?>
<?php $__env->startSection('controller_route', getTitleServiceBackend()['linkList']); ?>
<?php $__env->startSection('action','Thêm mới'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('accompanied-services.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="<?php echo e(request()->get('type')); ?>">
                   	<div class="row">
                   		<div class="col-sm-12">
                   			<div class="form-group">
                   				<label for="">Tên gói dịch vụ</label>
                   				<input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>">
                   			</div>
                   			<div class="form-group">
                   				<label for="">Giá</label>
                   				<input type="number" name="price" class="form-control" value="<?php echo e(old('price')); ?>">
                   			</div>
                            
                            <?php if( request()->get('type') == 'additional-vps' || 
                                request()->get('type') == 'additional-hosting' ): ?>
                                
                       		<?php else: ?>
                                <div class="form-group">
                                    <label for="">Nhãn Giá</label>
                                    <input type="text" name="label_price" class="form-control" 
                                    value="<?php echo e(old('label_price')); ?>">
                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label class="custom-checkbox">
                                    <input type="checkbox" name="status" value="1" checked=""> Hiển thị
                                </label>
                            </div>
                   		</div>
                        <?php if( request()->get('type') == 'additional-vps' || request()->get('type') == 'additional-hosting' ): ?>

                        <?php else: ?>
                       		<div class="col-sm-12">
                       			<label for="">Thông tin</label>
                       			<div class="repeater" id="repeater">
        			                <table class="table table-bordered table-hover">
        			                    <thead>
        				                    <tr>
        				                    	<th style="width: 30px;">STT</th>
        				                    	<th>Tiêu đề</th>
        				                    	<th>Giá trị</th>
        				                    	<th style="width: 30px;"></th>
        				                    </tr>
        			                	</thead>
        			                    <tbody id="sortable">

        			                    </tbody>
        			                </table>

        			                <div class="text-right">
        			                    <button class="btn btn-primary" onclick="repeater(event,this,'<?php echo e(route('get.layout')); ?>','.index', 'services-meta')">Thêm</button>
        			                </div>
        			            </div>
                       		</div>
                        <?php endif; ?>
                   		<div class="col-sm-12">
                   			<button type="submit" class="btn btn-primary">Lưu lại</button>
                   		</div>
                   	</div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/backend/services/accompanied-services/add.blade.php ENDPATH**/ ?>