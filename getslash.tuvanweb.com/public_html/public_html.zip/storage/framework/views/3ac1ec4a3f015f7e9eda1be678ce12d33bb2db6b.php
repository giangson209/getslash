<?php $__env->startSection('controller', $module['name'] ); ?>
<?php $__env->startSection('controller_route', route('projects.edit', $idProject)); ?>
<?php $__env->startSection('action', renderAction(@$module['action'])); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php
            $route = route('projects.detail.store', $idProject);
            if(isUpdate(@$module['action'])){
                $route = route('projects.detail.update', ['idProject' => $idProject, 'id' => $data->id]);
            }
        ?>
        <form action="<?php echo e($route); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isUpdate(@$module['action'])): ?>
                <?php echo e(method_field('put')); ?>

            <?php endif; ?>
            <div class="row">
                <div class="col-sm-9">
                    <div class="nav-tabs-custom">
                        <ul class="nav nav-tabs">
                            <li class="active">
                                <a href="#activity" data-toggle="tab" aria-expanded="true">Thông tin</a>
                            </li>
                        </ul>
                        <div class="tab-content">

                            <div class="tab-pane active" id="activity">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Tiêu đề Tiếng Việt</label>
                                                    <input type="text" class="form-control" name="name_vi" id="name"
                                                           value="<?php echo old('name_vi', @$data->name_vi); ?>" required="">
                                                </div>

                                                <div class="form-group">
                                                    <label>Tiêu đề phụ Tiếng Việt</label>
                                                    <input type="text" class="form-control" name="sub_name_vi" id="name"
                                                           value="<?php echo old('sub_name_vi', @$data->sub_name_vi); ?>">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label>Tiêu đề Tiếng Anh</label>
                                                    <input type="text" class="form-control" name="name_en"
                                                           value="<?php echo old('name_en', @$data->name_en); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label>Tiêu đề phụ Tiếng Anh</label>
                                                    <input type="text" class="form-control" name="sub_name_en"
                                                           value="<?php echo old('sub_name_en', @$data->sub_name_en); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="image">
                                            <label for="">Thư viện ảnh</label><br>
                                            <button type="button" class="btn btn-success" onclick="fileMultiSelect(this)"><i class="fa fa-upload"></i>
                                                Chọn hình ảnh
                                            </button>
                                            <br><br>
                                            <div class="image__gallery">
                                                <?php
                                                    if(isUpdate(@$module['action'])){
                                                        $gallery = @$data->getGalleryProjectDetail();
                                                    }
                                                ?>
                                                <?php if(!empty($gallery)): ?>
                                                    <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="image__thumbnail image__thumbnail--style-1">
                                                            <img src="<?php echo e($item->path); ?>">
                                                            <a href="javascript:void(0)" class="image__delete" onclick="urlFileMultiDelete(this)">
                                                                <i class="fa fa-times"></i>
                                                            </a>
                                                            <input type="hidden" name="gallery[]" value="<?php echo e($item->path); ?>">
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title">Đăng</h3>
                        </div>
                        <div class="box-body">
                            <div class="form-group">
                                <label class="custom-checkbox">
                                    <?php if(isUpdate(@$module['action'])): ?>
                                        <input type="checkbox" name="status"
                                               value="1" <?php echo e(@$data->status == 1 ? 'checked' : null); ?>> Hiển thị
                                    <?php else: ?>
                                        <input type="checkbox" name="status" value="1" checked> Hiển thị
                                    <?php endif; ?>
                                </label>
                            </div>
                            <div class="form-group text-right">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-save" style="padding-right: 5px"></i>Đăng
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="box box-success">
                        <div class="box-header with-border">
                            <h3 class="box-title">Banner</h3>
                        </div>
                        <div class="box-body">
                            <div class="form-group" style="text-align: center;">
                                <div class="image">
                                    <div class="image__thumbnail">
                                        <img src="<?php echo e(!empty($data->banner) ? $data->banner : __IMAGE_DEFAULT__); ?>"
                                             data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
                                        <a href="javascript:void(0)" class="image__delete"
                                           onclick="urlFileDelete(this)">
                                            <i class="fa fa-times"></i></a>
                                        <input type="hidden" value="<?php echo e(old('banner', @$data->banner)); ?>" name="banner"/>
                                        <div class="image__button" onclick="fileSelect(this)">
                                            <i class="fa fa-upload"></i>
                                            Upload
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bestay\resources\views/backend/projects/projects-detail/create-edit.blade.php ENDPATH**/ ?>