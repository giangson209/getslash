<?php $id = isset($id) ? $id : (int) round(microtime(true) * 1000); ?>
<tr>
	<td class="index"><?php echo e($index); ?></td>
	<td>
        <div class="form-group">
            <label for="">Tiêu đề</label>
            <input type="text" name="content[list][<?php echo e($id); ?>][title]" class="form-control" value="<?php echo e(@$value->title); ?>">
        </div>
        <div class="form-group">
            <label for="">Nội dung</label>
            <textarea name="content[list][<?php echo e($id); ?>][content]" id="content<?php echo e($id); ?>"><?php echo @$value->content; ?></textarea>
        </div>
    </td>
    <td style="text-align: center;">
        <a href="javascript:void(0);" onclick="$(this).closest('tr').remove()" class="text-danger buttonremovetable" title="Xóa">
            <i class="fa fa-minus"></i>
        </a>
    </td>
</tr>

<script>
    CKEDITOR.replace( 'content<?php echo e($id); ?>');
</script><?php /**PATH C:\xampp\htdocs\fashion\resources\views/backend/repeater/row-post-path.blade.php ENDPATH**/ ?>