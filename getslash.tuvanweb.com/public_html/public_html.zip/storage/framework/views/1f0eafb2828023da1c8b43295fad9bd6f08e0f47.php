<div class="item-cart">
	<div class="item">
		<div class="info-cart"><?php echo e($loop->index + 1); ?></div>
		<div class="info-cart">
			<a href="javascript:0" class="link-info"><?php echo e($item->name); ?></a>
			<div class="sub-cart sub-link" style="display: block;">
				<ul>
					<?php $__currentLoopData = @$item->options->module; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idModule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $moduleParent = \App\Models\ModuleWebsite::where('id', @$idModule['parent'])->first(); ?>
						<?php if(!empty($moduleParent)): ?>
							<li style="font-weight: bold;"><?php echo e($moduleParent->name); ?></li>
							<?php if(!empty(@$idModule['child'])): ?>
								<ul style="padding-left: 10px">
									<?php $__currentLoopData = @$idModule['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php $moduleChild = \App\Models\ModuleWebsite::where('id', @$child)->first(); ?>
										<?php if(!empty($moduleChild)): ?>
											<li><?php echo e($moduleChild->name); ?> - <?php echo e(number_format($moduleChild->price)); ?>đ</li>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							<?php endif; ?>
						<?php endif; ?>
						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>	
		</div>
		<div class="info-cart">
			<div class="price">
				<span><?php echo e(number_format($item->price)); ?>đ</span>
			</div>
		</div>
		<div class="info-cart">
			<div class="remove text-center">
				<a href="javascript:0" class="btnRemove" data-id="<?php echo e($item->rowId); ?>">
					<img src="<?php echo e(__BASE_URL__); ?>/images/remove.png" alt="remove">
				</a>
			</div>
		</div>
	</div>
</div><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/teamplate/cart/website.blade.php ENDPATH**/ ?>