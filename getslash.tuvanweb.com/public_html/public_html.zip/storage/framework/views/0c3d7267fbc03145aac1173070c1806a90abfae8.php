<?php if(count($data)): ?>
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-lg-3 col-6 col-sm-3">
			<?php $__env->startComponent('frontend.components.product-style-2', ['item'=> $item]); ?>

			<?php echo $__env->renderComponent(); ?>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu2/resources/views/frontend/components/loop-products-brand/loop-brand-style-1.blade.php ENDPATH**/ ?>