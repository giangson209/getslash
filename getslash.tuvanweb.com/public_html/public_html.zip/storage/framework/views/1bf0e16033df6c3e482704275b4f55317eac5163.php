<div class="item">
	<div class="avarta">
		<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>">
			<img src="<?php echo e($item->image); ?>" class="img-fluid" width="100%" alt="<?php echo e($item->name); ?>">
		</a>
	</div>
	<div class="info">
		<h3><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>"><?php echo e($item->name); ?></a></h3>
		<div class="time"><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?>  - <?php echo e(@$item->Author->name); ?></div>
		<div class="desc">
			<?php echo e($item->desc); ?>

		</div>
		<div class="link-more">
			<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>" class="text-uppercase">Chi tiết</a>
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/components/post.blade.php ENDPATH**/ ?>