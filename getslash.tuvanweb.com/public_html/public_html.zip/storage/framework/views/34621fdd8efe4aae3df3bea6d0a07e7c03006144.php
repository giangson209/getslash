<?php $__env->startSection('controller','Filter'); ?>
<?php $__env->startSection('controller_route', route('product.filter.price')); ?>
<?php $__env->startSection('action', 'Cập nhật'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
            	<form action="<?php echo e(route( 'product.filter.price.post' )); ?>" method="POST">
            		
            		<?php echo csrf_field(); ?>
            		
			       	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			       	<div class="row">
			       		<div class="col-sm-12">
			       			<div class="form-group">
				       			<label for="">Tiêu đề bộ lọc</label>
				       			<input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control">
				       		</div>

				       		<div class="form-group">
				       			<label for="">Loại bộ lọc: </label>
				       			<label for="">
					       			Giá
	              				</label>
				       		</div>
				       		<?php if(!empty($data->content)){
				       			$content = json_decode( $data->content );
				       		} ?>
							
							<div class="repeater" id="repeater">
							    <table class="table table-bordered table-hover">
							        <thead>
							            <tr>
							            	<th style="width: 30px;">STT</th>
							            	<th>Tiêu đề</th>
							            	<th>Giá trị nhỏ nhất</th>
							            	<th>Giá trị lớn nhất</th>
							            	<th style="width: 30px;"></th>
							            </tr>
							    	</thead>
							        <tbody id="sortable">
										<?php if(!empty($content->filter)): ?>
							                <?php $__currentLoopData = $content->filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    <?php $index = $loop->index +1  ?>
							                    <?php echo $__env->make('backend.repeater.row-filter-price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							            <?php endif; ?>
							        </tbody>
							    </table>
							    <div class="text-right">
							        <button class="btn btn-primary" onclick="repeater(event,this,'<?php echo e(route('get.layout')); ?>','.index', 'filter-price')">Thêm</button>
							    </div>
							</div>
				           

				           <button class="btn-primary btn">Lưu lại</button>
			       		</div>
			       	</div>
			    </form>
		    </div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/backend/products/filter.blade.php ENDPATH**/ ?>