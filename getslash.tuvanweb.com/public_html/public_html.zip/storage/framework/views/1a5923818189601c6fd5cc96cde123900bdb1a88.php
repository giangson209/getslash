<div class="modal fade" id="exampleModalCenter" 
    tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Thông báo</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="icon-ss">
                    <i class="fa fa-check-circle-o" aria-hidden="true"></i>
                    <h3>ĐƠN HÀNG CỦA BẠN ĐÃ ĐƯỢC ĐẶT THÀNH CÔNG</h3>
                </div>
                <div class="note-ss">
                    <p>Chúng tôi sẽ liên hệ lại với bạn để xác nhận đơn hàng trong thời gian sớm nhất. Xin cảm ơn !</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/frontend/teamplate/modal.blade.php ENDPATH**/ ?>