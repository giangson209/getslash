<section id="search-tags" class="pb-80">
	<div class="container">
		<div class="content">
			<div class="info-tags">
				<ul class="list-inline">
					<li class="list-inline-item"><span>Tìm kiếm nhiều nhất: </span></li>
					<?php if(!empty($tags_link->content)): ?>
						<?php $content_tags = json_decode( $tags_link->content ); ?>
						<?php if(!empty($content_tags->tags)): ?>
							<?php $__currentLoopData = $content_tags->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li class="list-inline-item">
									<a title="<?php echo e($value->title); ?>" href="<?php echo e($value->link); ?>"><?php echo e($value->title); ?></a>
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					<?php endif; ?>
				</ul>
			</div>
		</div>
	</div>
</section><?php /**PATH C:\xampp\htdocs\hungphu\resources\views/frontend/teamplate/parts/tags.blade.php ENDPATH**/ ?>