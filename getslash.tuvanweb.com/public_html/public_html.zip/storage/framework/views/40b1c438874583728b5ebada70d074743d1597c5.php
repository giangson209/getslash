<?php $__env->startSection('main'); ?>
	<section id="breadcrumbs">
		<div class="avarta">
			<?php if($dataSeo->banner): ?>
				<img src="<?php echo e($dataSeo->banner); ?>" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php else: ?>
				<img src="<?php echo e(__BASE_URL__); ?>/images/bread.png" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php endif; ?>
			
		</div>
		<div class="info">
			<div class="container text-center">
				<h2 class="text-uppercase">tin tức</h2>
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ <span>/</span></a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Tin tức</a></li>
				</ul>
			</div>
		</div>
	</section>
	<section id="mews" class="pt-100 pb-100">
		<h1 class="d-none"><?php echo e(@$dataSeo->title_h1); ?></h1>
		<div class="container">
			<div class="content">
				<div class="list-news">
					<div class="row">
						<?php if(count($data)): ?>
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4 col-sm-4 col-6">
									<?php $__env->startComponent('frontend.components.post', ['item' => $item]); ?> <?php echo $__env->renderComponent(); ?>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
							<div class="col-sm-12">
								<div class="alert alert-success" role="alert">
								  	Nội dung đang được cập nhật.
								</div>
							</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="news-bott">
					<div class="pagination">
						<div class="row">
							<div class="col-md-6 col-sm-6">
								<ul class="list-inline">
									<?php echo $data->links(); ?>

								</ul>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="right text-right"><span>Hiển thị <?php echo e($data->count()); ?> trên <?php echo e($data->total()); ?> bài viết</span></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/pages/archives-news.blade.php ENDPATH**/ ?>