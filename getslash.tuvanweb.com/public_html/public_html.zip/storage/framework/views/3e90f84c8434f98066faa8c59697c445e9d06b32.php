<?php $__env->startSection('controller','Tài khoản'); ?>
<?php $__env->startSection('controller_route', route('users.index')); ?>
<?php $__env->startSection('action','Chỉnh sửa'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo e(route('users.update', $data->id)); ?>" method="POST" autocomplete="off">
               		<?php echo method_field('PUT'); ?>

	           		<div class="col-md-8">
		                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
		                <div class="form-group">
		                    <label>Họ và tên</label>
		                    <input type="text" class="form-control" name="name" 
		                    value="<?php echo old('name', isset($data->name) ? $data->name : null); ?>">
		                </div>
		                <div class="form-group">
		                    <label>Số điện thoại</label>
		                    <input type="text" class="form-control" name="phone" 
		                    value="<?php echo old('phone', isset($data->phone) ? $data->phone : null); ?>">
		                </div>
		                <div class="form-group">
		                    <label>Tài khoản</label>
		                    <input type="text" class="form-control" name="user_name" 
		                    value="<?php echo old('user_name', isset($data->user_name) ? $data->user_name : null); ?>" readonly="">
		                </div>
		                <div class="form-group">
		                    <label>Email</label>
		                    <input type="text" class="form-control" name="email" 
		                    value="<?php echo old('email', isset($data->email) ? $data->email : null); ?>">
		                </div>
		                <?php if(Auth::user()->user_name != $data->user_name): ?>
		                <div class="form-group">
		                    <label>Vai trò</label>
		                    <select name="level" class="form-control" >
		                        <option value="1" <?php echo e($data->level == 1 ? 'selected' : null); ?>>Người quản lý</option>
		                        <option value="2" <?php echo e($data->level == 2 ? 'selected' : null); ?>>Biên tập viên</option>
		                    </select>
		                </div>
		                <?php endif; ?>
		                	<div id="pass" class="hidden">
			                    <div class="form-group">
			                      <label>Mật khẩu</label>
			                      <input type="password" class="form-control" name="password" value="">
			                  </div>
			                <div class="form-group">
			                      <label>Nhập lại mật khẩu</label>
			                      <input type="password" class="form-control" name="repassword" value="">
			                </div>
		                </div>
		                <?php if(Auth::user()->user_name != $data->user_name): ?>
		                  <div class="form-check">
		                      <input class="form-check-input" type="checkbox" value="1" id="status" 
		                      <?php echo e($data->status == 1 ? 'checked' : null); ?> name="status">
		                      <label class="form-check-label" for="status">
		                          Kích hoạt
		                      </label>
		                  </div>
		                <?php endif; ?>
		                <div class="form-group">
		                	<button type="submit" class="btn btn-primary">Cập nhật</button>
		                	 <button type="button" id="chanePass" class="btn bg-olive margin">Thay đổi mật khẩu</button>
		                </div>
		            </div>
		            <div class="col-sm-4">
		                <div class="form-group">
	                      	<div class="form-group">
	                           <label>Hình ảnh</label>
	                           <div class="image">
	                               <div class="image__thumbnail">
	                                   <img src="<?php echo e(!empty($data->image) ? $data->image :  __IMAGE_DEFAULT__); ?>"  data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
	                                   <a href="javascript:void(0)" class="image__delete" 
	                                   onclick="urlFileDelete(this)">
	                                    <i class="fa fa-times"></i></a>
	                                   <input type="hidden" value="<?php echo e($data->image); ?>" name="image"  />
	                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
	                               </div>
	                           </div>
	                       </div>
		                </div>
		            </div>
	            </form>
           </div>
        </div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	  <script>
	    jQuery(document).ready(function($) {
	      $('#chanePass').click(function(event) {
	        $('#pass').toggleClass('hidden');
	      });
	    });
	  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/backend/users/edit.blade.php ENDPATH**/ ?>