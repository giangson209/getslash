<?php $__env->startSection('main'); ?>
	<h1 style="display: none;"><?php echo e(@$typeWebsite->name); ?></h1>
	<?php echo $__env->make('frontend.teamplate.breadcrumbs', [ 
		'config' => [
			'banner' => @$dataSeo->banner,
			'title' => 'Báo giá'
		] 
	], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<section class="vk-content">
        <section class="vk-content">
            <form class="" action="<?php echo e(route('home.addCart.post')); ?>" method="POST">
                <input type="hidden" name="services" value="<?php echo e($typeWebsite->name); ?>">
                <input type="hidden" name="type" value="website">
                <?php echo csrf_field(); ?>
                <div class="vk-page pt-0">
                    <div class="vk-category">
                        <ul class="vk-list vk-list--inline vk-category__list">
                            <li class="vk-list__item d-none d-lg-inline-block">
                                <a href="#"><i class="fa fa-th"></i></a>
                            </li>
                            <?php if(count($allTypeWebsite)): ?> 
                                <?php $__currentLoopData = $allTypeWebsite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="vk-list__item active">
                                        <a href="<?php echo e(route('home.services.website', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php if(count($typeWebsite->ModuleWebsite()->where('parent_id', null)->get())): ?>
                    <?php $moduleParent = $typeWebsite->ModuleWebsite()->where('parent_id', null)->orderBy('position')->get();  ?>
                    <div class="container-fix">
                        <div class="vk-price">
                            <div class="vk-price__total">Tổng giá trị: &nbsp;<span class="vk-text--orange-1"> <span id="totalPrice">0</span> đ</span>
                            </div>
                            <input type="hidden" name="amount" id="amount" value="0">
                            <div class="vk-price__list row no-gutters">
                                <?php if(!empty($moduleParent)): ?>
                                    <?php $__currentLoopData = $moduleParent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $idParent = $item->id; ?>
                                       <div class="col-lg-4 col-sm-6 _item">
                                            <div class="vk-price__box">
                                                <div class="vk-price__choice">
                                                    <h2 class="vk-price__title vk-price__title--main">
                                                        <a href="#<?php echo e($idParent); ?>" class="_collapse collapsed" 
                                                        data-toggle="collapse">
                                                            <?php echo e($item->name); ?>

                                                        </a>
                                                    </h2>
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input parent" name="funcParent[]" 
                                                        value="<?php echo e($idParent); ?>" data-target="#<?php echo e($idParent); ?>" 
                                                        id="customCheck<?php echo e($item->id); ?>" 
                                                        data-price="<?php echo e(getTotalModule($idParent)); ?>">
                                                        <label class="custom-control-label" for="customCheck<?php echo e($item->id); ?>"></label>
                                                    </div>
                                                </div>
                                                <div class="collapse" id="<?php echo e($idParent); ?>">
                                                    <?php if(count($item->get_child())): ?>
                                                        <?php $__currentLoopData = $item->get_child(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="vk-price__choice">
                                                                <label class="vk-price__title" for="customCheck<?php echo e($value->id); ?>">
                                                                    <?php echo e($value->name); ?>

                                                                </label>
                                                                <div class="custom-control custom-checkbox">
                                                                    <input type="checkbox" class="custom-control-input child" name="funcChild[<?php echo e($idParent); ?>][]" id="customCheck<?php echo e($value->id); ?>" data-parent="#<?php echo e($idParent); ?>" value="<?php echo e($value->id); ?>" 
                                                                    data-price="<?php echo e($value->price); ?>">
                                                                    <label class="custom-control-label" for="customCheck<?php echo e($value->id); ?>"></label>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                        <div class="container">
                             Nội dung đang được cập nhật.
                        </div>
                    <?php endif; ?>
                </div>

                <div class="container text-center">
                    <div class="btn-view text-center">
                        <button type="submit">Cho vào giỏ hàng</button>
                    </div>
                </div>
            </form>
        </section>
        <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script> 
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/frontend/pages/services/website.blade.php ENDPATH**/ ?>