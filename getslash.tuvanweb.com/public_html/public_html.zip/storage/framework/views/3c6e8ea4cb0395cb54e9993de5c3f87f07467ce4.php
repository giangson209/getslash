<?php $__env->startSection('main'); ?>
	<section id="breadcrumbs">
		<div class="avarta">
			<?php if($dataSeo->banner): ?>
				<img src="<?php echo e($dataSeo->banner); ?>" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php else: ?>
				<img src="<?php echo e(__BASE_URL__); ?>/images/bread.png" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php endif; ?>
		</div>
		<div class="info">
			<div class="container text-center">
				<h2 class="text-uppercase">Dự án</h2>
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ <span>/</span></a></li>
					<?php if(\Request::route()->getName() == 'home.project'): ?>
						<li class="list-inline-item"><a title="" href="javascript:0">Dự án</a></li>
					<?php else: ?>
						<li class="list-inline-item"><a title="Dự án" href="<?php echo e(route('home.project')); ?>">Dự án <span>/</span></a></li>
						<li class="list-inline-item"><a title="" href="javascript:0"><?php echo e($info->name); ?></a></li>
					<?php endif; ?>
				</ul>
			</div>
		</div>
	</section>

	<section id="project" class="">
		<h1 class="d-none"><?php echo e($dataSeo->title_h1); ?></h1>
		<?php if(\Request::route()->getName() == 'home.project'): ?>
			<div class="desc-project pt-100 pb-100">
				<div class="content">
					<div class="container">
						<?php if(!empty($dataSeo->content)){
							$content = json_decode($dataSeo->content);
						} ?>
						<?php echo @$content->desc; ?>

					</div>
				</div>
			</div>
		<?php endif; ?>
		<div class="project-child pt-100 pb-100" style="background: #fafafa">
			<div class="container">
				<div class="content">
					<div class="title text-center text-uppercase">
						<?php if(\Request::route()->getName() == 'home.project'): ?>
							<h2>Các dự án tiêu biểu</h2>
						<?php else: ?>
							<h2><?php echo e($info->name); ?></h2>
						<?php endif; ?>
					</div>
					<div class="list-product">
						<div class="row">
							<?php if(count($data)): ?>
								<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-md-6 col-sm-6">
										<?php if(\Request::route()->getName() == 'home.category-project'): ?>
											<?php $__env->startComponent('frontend.components.project', ['item' => $item, 'info'=> $info ]); ?> <?php echo $__env->renderComponent(); ?>
										<?php else: ?>
											<?php $__env->startComponent('frontend.components.project', ['item' => $item ]); ?> <?php echo $__env->renderComponent(); ?>
										<?php endif; ?>
										
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								<div class="col-sm-12">
									<div class="alert alert-success" role="alert">
									  	Nội dung đang được cập nhật.
									</div>
								</div>
							<?php endif; ?>
							<div class="col-md-12">
								<div class="pagination">
									<ul class="list-inline text-center">
										<?php echo $data->links(); ?>

									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<script>
		jQuery(document).ready(function($) {
			$('.project_menu').addClass('active');
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/pages/archives-projects.blade.php ENDPATH**/ ?>