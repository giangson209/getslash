<?php $__env->startSection('controller', getTitleServiceBackend()['title'] ); ?>
<?php $__env->startSection('controller_route', getTitleServiceBackend()['linkList']); ?>
<?php $__env->startSection('action','Edit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('package.update', $data->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="<?php echo e($data->type); ?>">
                    <input type="hidden" name="parent_id" value="<?php echo e($data->parent_id); ?>">
					<div class="row">
                   		<div class="col-sm-12">
                   			<div class="form-group">
                   				<label for="">Tên gói dịch vụ</label>
                   				<input type="text" name="name" class="form-control" value="<?php echo e(old('name', @$data->name )); ?>">
                   			</div>
                   			<div class="form-group">
                   				<label for="">Giá</label>
                   				<input type="number" name="price" class="form-control" value="<?php echo e(old('price', @$data->price)); ?>">
                   			</div>

                   			<div class="form-group">
                                <label for="">Nhãn Giá</label>
                                <input type="text" name="label_price" class="form-control" 
                                value="<?php echo e(old('label_price', @$data->label_price)); ?>">
                            </div>
                            <div class="form-group">
                                <label for="">Số tháng</label>
                                <input type="number" name="meta" class="form-control" 
                                value="<?php echo e(old('meta', @$data->meta)); ?>">
                            </div>
                            <div class="form-group">
                                <label for="">Số thự tự</label>
                                <input type="number" name="order" class="form-control" 
                                value="<?php echo e(old('order', @$data->order)); ?>">
                            </div>
                            <div class="form-group">
                                <label class="custom-checkbox">
                                    <input type="checkbox" name="status" value="1" checked=""> Hiển thị
                                </label>
                            </div>
                   		</div>
                   		<div class="col-sm-12">
                   			<button type="submit" class="btn btn-primary">Lưu lại</button>
                   		</div>
                   	</div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/backend/services/package/edit.blade.php ENDPATH**/ ?>