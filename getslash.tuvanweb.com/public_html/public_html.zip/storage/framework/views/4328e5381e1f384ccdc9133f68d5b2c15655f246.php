<?php $__env->startSection('controller','Đơn hàng'); ?>
<?php $__env->startSection('action','Chi tiết'); ?>
<?php $__env->startSection('controller_route', route('orders.list')); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo route('orders.edit.post', $data->id); ?>" method="POST">
			        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
					<div class="row">
		                <div class="col-md-3"><label>Mã đơn hàng</label></div>
		                <div class="col-md-5">
		                  <a href="#"><?php echo '#ORDER_'.$data['id']; ?></a></span>
		                </div>
		              </div>

		              <div class="row">
		                <div class="col-md-3"><label>Khách hàng</label></div>
		                <div class="col-md-5"><?php echo isset($data->customer) ? $data->customer['name'] : null; ?></div>
		              </div>

		              

		              <div class="row">
		                <div class="col-md-3"><label>Email</label></div>
		                <div class="col-md-5"><?php echo isset($data->customer) ? $data->customer['email'] : null; ?></div>
		              </div>
		              <div class="row">
		                <div class="col-md-3"><label>Số điện thoại</label></div>
		                <div class="col-md-5"><?php echo isset($data->customer) ? $data->customer['phone'] : null; ?></div>
		              </div>
		              <div class="row">
		                <div class="col-md-3"><label>Địa chỉ</label></div>
		                <div class="col-md-5">
		                  	<?php echo e(@$data->customer->address); ?> <br>
		                  	<?php echo getAddressCustomer(@$data->customer->province_id, @$data->customer->district_id); ?>

		                </div>
		              </div>
		                <hr>
		                <div class="row">
		                    <div class="col-md-3"><label>Tổng tiền</label></div>
		                    <div class="col-md-5"><b><?php echo number_format($data['price_total'],0,',','.' ); ?> VND</b></div>
		                </div>
		                <hr>
		                <div class="row">
		                    <div class="col-md-3"><label>Ngày đặt</label></div>
		                    <div class="col-md-5">
		                        <?php echo Carbon\Carbon::parse($data['created_at'])->format('d-m-Y H:i:s'); ?>

		                    </div>
		                </div>
		                <div class="row">
		                    <div class="col-md-3"><label>Ghi chú</label></div>
		                    <div class="col-md-5">
		                      <?php echo e($data->note); ?>

		                    </div>
		                </div>

		                <div class="row">
		                <div class="col-md-3"><label>Hình thức thanh toán</label></div>
			                <div class="col-md-5">
			                	<?php if($data->typePay ==  1): ?>
			                		Thanh toán trực tiếp
			                	<?php else: ?>
			                	 	Thanh toán qua ngân hàng
			                	 	<?php $bank = \App\Models\Bank::find($data->id_bank); ?>
			                	 	<?php if(!empty($bank)): ?>
			                	 		<ul>
			                	 			<li>Tên ngân hàng: <?php echo e($bank->name); ?></li>
			                	 			<li>Chủ tài khoản: <?php echo e($bank->account_holder); ?></li>
			                	 			<li>Số tài khoản: <?php echo e($bank->account_number); ?></li>
			                	 			<li>Chi nhánh: <?php echo e($bank->account_number); ?></li>
			                	 		</ul>
			                	 	<?php endif; ?>
			                	<?php endif; ?>
			                </div>
			              </div>
		              <hr>
		              <br>
		              <div class="row">
		                <div class="col-md-3"><label>Trạng thái</label></div>
		                <div class="col-md-5">
		                    <select class="form-control" name="status">
		                        <option value="1" <?php if($data['status'] == 1): ?> selected <?php endif; ?>>Mới đặt</option>
		                        <option value="2" <?php if($data['status'] == 2): ?> selected <?php endif; ?>>Xác nhận</option>
		                        <option value="4" <?php if($data['status'] == 4): ?> selected <?php endif; ?>>Hoàn thành</option>
		                        <option value="5" <?php if($data['status'] == 5): ?> selected <?php endif; ?>>Hủy</option>
		                    </select>
		                    <br><button type="submit" class="btn btn-primary">Cập nhật</button><br><br>
		                </div>
		              </div>
		              <hr>
		              	<h3 class='text-center'>CHI TIẾT ĐƠN HÀNG</h3>
						<?php $services_website = $data->OrderDetail()->where('type', 'website')->get(); ?>
						<?php if(!empty($services_website)): ?>
							<?php $__currentLoopData = $services_website; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="row">
						    		<div class="col-sm-12">
						    			<h4 class='text-center' style="font-weight: 700; text-transform: uppercase;">
						    				<?php echo e($value->meta); ?>

						    			</h4>
						    			<label for="">Chức năng website</label>
										<?php if(!empty($value->content)){
											$content = json_decode($value->content);
										} ?>
										<ul>
											<?php if(!empty($content->module)): ?>
												<?php $__currentLoopData = $content->module; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idModule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php $moduleParent = \App\Models\ModuleWebsite::where('id', @$idModule->parent)
															->first(); ?>
													<?php if(!empty($moduleParent)): ?>
														<li style="font-weight: bold;"><?php echo e($moduleParent->name); ?> - <?php echo e(number_format(getTotalModule($moduleParent->id))); ?>đ</li>
														<?php if(!empty(@$idModule->child)): ?>
															<ul style="padding-left: 10px">
																<?php $__currentLoopData = @$idModule->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<?php $moduleChild = \App\Models\ModuleWebsite::where('id', @$child)->first(); ?>
																	<?php if(!empty($moduleChild)): ?>
																		<li><?php echo e($moduleChild->name); ?> - <?php echo e(number_format($moduleChild->price)); ?>đ</li>
																	<?php endif; ?>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															</ul>
														<?php endif; ?>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</ul>
						    		</div>
						    	</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						<?php $accompanied_services = $data->OrderDetail()->where('type','!=','website')->get(); ?>
						<?php if(count($accompanied_services)): ?>
						<h4 class='text-center' style="font-weight: 700; text-transform: uppercase;">
		    				Dịch Vụ
		    			</h4>
						<table class="table table-bordered table-striped">
			                <thead>
			                    <tr>
			                        <th>STT</th>
			                        <th>Dịch vụ</th>
			                        <th>Số lượng</th>
			                        <th>Đơn giá</th>
			                        <th>Thành tiền</th>
			                    </tr>
			                </thead>
			                <tbody>
			                  	<?php $__currentLoopData = $accompanied_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                  		<tr>
			                  			<td><?php echo e($loop->index+1); ?></td>
			                  			<td>
			                  				<?php $services_info = \App\Models\Services::find($item->services_id) ?>
			                  				<?php if(!empty($services_info)): ?>
			                  					<?php echo e($services_info->name); ?>

			                  				<?php else: ?>
			                  					Dịch vụ đã xóa.
			                  				<?php endif; ?>
			                  			</td>
			                  			<td><?php echo e($item->services_quantity); ?></td>
			                  			<td><?php echo e(number_format($item->price)); ?></td>
			                  			<td><?php echo e(number_format($item->price * $item->services_quantity )); ?></td>
			                  		</tr>
			                  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                </tbody>
			            </table>
			            <?php endif; ?>
			    </form>


			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/backend/orders/edit.blade.php ENDPATH**/ ?>