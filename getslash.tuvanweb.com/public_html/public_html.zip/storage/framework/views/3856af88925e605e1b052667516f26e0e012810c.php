<?php $__env->startSection('controller', 'Bài viết'); ?>
<?php $__env->startSection('controller_route', route('posts.index') ); ?>
<?php $__env->startSection('action','Thêm mới'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
		<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<form action="<?php echo e(route('posts.store')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<input type="hidden" value="blog" name="type">
			<div class="row">
				<div class="col-sm-9">
		            <div class="nav-tabs-custom">
		                <ul class="nav nav-tabs">
		                    <li class="active">
		                        <a href="#activity" data-toggle="tab" aria-expanded="true">Bài viết Tiếng Việt</a>
		                    </li>
							<li class="">
								<a href="#activity1" data-toggle="tab" aria-expanded="true">Bài viết Tiếng Anh</a>
							</li>
		                    <li class="">
		                    	<a href="#setting" data-toggle="tab" aria-expanded="true">Cấu hình seo</a>
		                    </li>
		                </ul>
		                <div class="tab-content">
		                    <div class="tab-pane active" id="activity">
		                        <div class="row">
		                            <div class="col-sm-12">
		                                <div class="form-group">
		                                    <label>Tiêu đề</label>
		                                    <input type="text" class="form-control" name="name_vi" id="name" value="<?php echo old('name_vi'); ?>" required="">
		                                </div>
		                                <div class="form-group" style="display: none;">
		                                    <label>Đường dẫn tĩnh</label>
		                                    <input type="text" class="form-control" name="slug" id="slug" value="<?php echo old('slug'); ?>">
		                                </div>
		                                
		                                <div class="form-group">
		                                    <label>Mô tả ngắn</label>
		                                    <textarea class="form-control" rows="5" name="desc_vi"><?php echo old('desc_vi'); ?></textarea>
		                                </div>
		                                
		                                <div class="form-group">
		                                    <label>Nội dung</label>
		                                    <textarea class="content" name="content_vi"><?php echo old('content_vi'); ?></textarea>
		                                </div>
		                            </div>
		                        </div>
		                    </div>

							<div class="tab-pane" id="activity1">
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<label>Tiêu đề</label>
											<input type="text" class="form-control" name="name_en" value="<?php echo old('name_en'); ?>">
										</div>

										<div class="form-group">
											<label>Mô tả ngắn</label>
											<textarea class="form-control" rows="5" name="desc_en"><?php echo old('desc_en'); ?></textarea>
										</div>

										<div class="form-group">
											<label>Nội dung</label>
											<textarea class="content" name="content_en"><?php echo old('content_en'); ?></textarea>
										</div>
									</div>
								</div>
							</div>

		                    <div class="tab-pane" id="setting">
		                        <div class="form-group">
		                            <label>Title SEO</label>
		                            <input type="text" class="form-control" name="meta_title" value="<?php echo old('meta_title'); ?>">
		                        </div>
		                        <div class="form-group">
		                            <label>Meta Description</label>
		                            <textarea name="meta_description" id="" class="form-control" rows="5"><?php echo old('meta_description'); ?></textarea>
		                        </div>

		                        <div class="form-group">
		                            <label>Meta Keyword</label>
		                            <input type="text" class="form-control" name="meta_keyword" value="<?php echo old('meta_keyword'); ?>">
		                        </div>
		                    </div>
		                </div>
		            </div>
				</div>
				<div class="col-sm-3">
					<div class="box box-success">
		                <div class="box-header with-border">
		                    <h3 class="box-title">Đăng</h3>
		                </div>
		                <div class="box-body">
		                    
		                    <label class="custom-checkbox">
                                <input type="checkbox" name="status" value="1" checked=""> Hiển thị
                            </label>
		                    
		                    
	                    	<label class="custom-checkbox">
                                <input type="checkbox" name="hot" value="1" checked=""> Nổi bật
                            </label>
                            
		                    <div class="form-group text-right">
		                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Lưu lại</button>
		                    </div>
		                </div>
		            </div>

					<div class="box box-success">
						<div class="box-header with-border">
							<h3 class="box-title">Tags</h3>
						</div>
						<div class="box-body">
							<input type="text" class="demo-default" id="tags-input" name="tags" data-role="tagsinput">
						</div>
					</div>

		            <div class="box box-success category-box">
		                <div class="box-header with-border">
		                    <h3 class="box-title">Danh mục bài viết </h3>
		                </div>
		                <div class="box-body checkboxlist">
		                    <?php if(!empty($categories)): ?>
		                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                            <?php if($item->parent_id == 0): ?>
		                                <label class="custom-checkbox">
		                                    <input type="checkbox" class="category" name="category[]" value="<?php echo e($item->id); ?>"> <?php echo e($item->name_vi); ?>

		                                 </label>
		                            <?php endif; ?>
		                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    <?php endif; ?>
		                </div>
		            </div>
		            <div class="box box-success">
		                <div class="box-header with-border">
		                    <h3 class="box-title">Ảnh đại diện</h3>
		                </div>
		                <div class="box-body">
		                    <div class="form-group" style="text-align: center;">
		                        <div class="image">
		                            <div class="image__thumbnail">
		                                <img src="<?php echo e(old('image') ?  old('image') : __IMAGE_DEFAULT__); ?>"
		                                     data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
		                                <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
		                                    <i class="fa fa-times"></i></a>
		                                <input type="hidden" value="<?php echo e(old('image')); ?>" name="image"/>
		                                <div class="image__button" onclick="fileSelect(this)">
		                                	<i class="fa fa-upload"></i>
		                                    Upload
		                                </div>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>



				</div>
			</div>
		</form>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<link rel="stylesheet" href="<?php echo e(url('public/backend/plugins/taginput/bootstrap-tagsinput.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/typeahead.js/0.11.1/typeahead.bundle.min.js"></script>
	<script src="<?php echo e(url('public/backend/plugins/taginput/bootstrap-tagsinput.min.js')); ?>"></script>
	<script>
		jQuery(document).ready(function($) {
			$('input[name="time_published"]').click(function(){
			   	if($(this).val() == 2){
			   		$('.time_published_value').show('slow/400/fast');
			   	}else{
			   		$('.time_published_value').hide('slow/400/fast');
			   	}
			});
			$('#tags-input').tagsinput({
			  	
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bestay\resources\views/backend/posts/add.blade.php ENDPATH**/ ?>