
<?php $__env->startSection('controller','Trang'); ?>
<?php $__env->startSection('controller_route',route('pages.list')); ?>
<?php $__env->startSection('action','Danh sách'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo e(route('pages.build.post')); ?>" method="POST">
					<?php echo e(csrf_field()); ?>

					<input name="type" value="<?php echo e($data->type); ?>" type="hidden">

	               	<div class="row">
						<div class="col-sm-12">
							<div class="form-group">
								<label for="">Trang</label>
								<input type="text" class="form-control" value="<?php echo e($data->name_page); ?>" disabled="">
				 				
								<?php if(\Route::has($data->route)): ?>
									<h5>
										<a href="<?php echo e(route($data->route)); ?>" target="_blank">
					                        <i class="fa fa-hand-o-right" aria-hidden="true"></i>
					                        Link: <?php echo e(route($data->route)); ?>

					                    </a>
									</h5>
				                <?php endif; ?>
							</div>
							
						</div>
					</div>
					<div class="nav-tabs-custom">
				        <ul class="nav nav-tabs">
				        	<li class="active">
				            	<a href="#about" data-toggle="tab" aria-expanded="true">Về chúng tôi</a>
				            </li>
				            <li class="">
				            	<a href="#seo" data-toggle="tab" aria-expanded="true">Cấu hình trang</a>
				            </li>
				        </ul>
				    </div>
				    <?php if(!empty($data->content)){
				    	$content = json_decode($data->content);

				    } ?>
				    <div class="tab-content">
						
						<div class="tab-pane active" id="about">
							<div class="row">
								<div class="col-sm-12">
									<div class="form-group">
										<label for="">Tiêu đề</label>
										<input type="text" name="content[about][title]" value="<?php echo e(@$content->about->title); ?>" class="form-control">
									</div>
									<div class="form-group">
										<label for="">Nội dung</label>
										<textarea class="content" name="content[about][desc]"><?php echo @$content->about->desc; ?></textarea>
									</div>
								</div>
								<div class="col-sm-2">
									<div class="form-group">
			                           <label>Hình ảnh đại diện video</label>
			                           <div class="image">
			                               <div class="image__thumbnail">
			                                   <img src="<?php echo e(!empty($content->video->image) ?  $content->video->image : __IMAGE_DEFAULT__); ?>"  
			                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                   <input type="hidden" value="<?php echo e(@$content->video->image); ?>" name="content[video][image]"  />
			                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
			                               </div>
			                           </div>
			                       	</div>
								</div>
								<div class="col-sm-10">
									<div class="form-group">
										<label for="">Iframe</label>
										<textarea class="form-control" rows="4" name="content[video][iframe]"><?php echo e(@$content->video->iframe); ?></textarea>
									</div>
								</div>
							</div>
						</div>

			            <div class="tab-pane" id="seo">
							<div class="row">
								<div class="col-sm-2">
									<div class="form-group">
			                           <label>Hình ảnh</label>
			                           <div class="image">
			                               <div class="image__thumbnail">
			                                   <img src="<?php echo e($data->image ?  $data->image : __IMAGE_DEFAULT__); ?>"  
			                                   data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
			                                   <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
			                                    <i class="fa fa-times"></i></a>
			                                   <input type="hidden" value="<?php echo e(@$data->image); ?>" name="image"  />
			                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
			                               </div>
			                           </div>
			                       </div>
								</div>
								
								<div class="col-sm-10">
									<div class="form-group">
										<label for="">Tiêu đề trang</label>
										<input type="text" name="meta_title" class="form-control" value="<?php echo e(@$data->meta_title); ?>">
									</div>
									<div class="form-group">
										<label for="">Mô tả trang</label>
										<textarea name="meta_description" 
										class="form-control" rows="5"><?php echo @$data->meta_description; ?></textarea>
									</div>
									<div class="form-group">
										<label for="">Từ khóa</label>
										<input type="text" name="meta_keyword" class="form-control" value="<?php echo @$data->meta_keyword; ?>">
									</div>
									
									

								</div>
							</div>
			            </div>
			           <button type="submit" class="btn btn-primary">Lưu lại</button>
			        </div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/backend/pages/layout/about.blade.php ENDPATH**/ ?>