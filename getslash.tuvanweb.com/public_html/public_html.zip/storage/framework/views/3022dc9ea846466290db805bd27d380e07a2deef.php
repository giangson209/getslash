<?php $__env->startSection('main'); ?>
	<main>
		<section class="breadrumbs">
			<div class="container">
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home" aria-hidden="true"></i></a></li>
				    <li class="breadcrumb-item"><a href="<?php echo e(route('home.archive-news')); ?>">Tin tức</i></a></li>
				    <li class="breadcrumb-item active" aria-current="page"><?php echo e($data->name); ?></li>
				  </ol>
				</nav>
			</div>
		</section>
		<section class="news-detail pd-60">
		    <div class="container">
		        <div class="row">
		            <div class="col-md-9">
		                <div class="news-art">
		                    <h1><?php echo e($data->name); ?></h1>
		                    <div class="news-action flex-center-between">
		                        <div class="time">
		                            <span><?php echo e($data->created_at->format('d/m/Y')); ?></span>
		                            <span><i class="fa fa-file"></i> Tin tức thời trang</span>
		                        </div>
		                        <div class="share">
		                        	<div class="fb-like" data-href="<?php echo e(route('home.post.single', $data->slug)); ?>" data-width="" data-layout="button" data-action="like" data-size="small" data-share="true"></div>
		                        </div>
		                    </div>
							
							<?php if($data->type == 'path'): ?>
			                    <div class="news-menu">
			                    	
			                    		<h3>Danh mục</h3>
			                    		<?php
			                        		$content = json_decode( $data->content );
			                        	?>
				                        <ul>
				                        	<?php if(!empty($content->list)): ?>
												<?php $__currentLoopData = $content->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><a href="javascript:;" class="clickToDiv" data-id="<?php echo e($id); ?>" title="<?php echo e($value->title); ?>"><?php echo e(numberToRomanRepresentation($loop->index + 1)); ?>. <?php echo e($value->title); ?></a> </li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
					                    </ul>
			                    	
			                        
			                    </div>
		                    <?php endif; ?>
		                    <div class="news-desc" style="margin-top: 10px">
		                    	<?php echo e($data->desc); ?>

		                    </div>
		                   	<?php if($data->type == 'path'): ?>
		                   		<?php
	                        		$content = json_decode( $data->content );
	                        	?>


	                        	<?php if(!empty($content->list)): ?>
									<?php $__currentLoopData = $content->list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="news-content" id="<?php echo e($id); ?>">
				                    		<?php echo $value->content; ?>

				                    	</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
		                    <?php else: ?>
		                    	<div class="news-content">
		                    		<?php echo $data->content; ?>

		                    	</div>
		                    <?php endif; ?>
		                    <div class="commnets">
		                    	<div class="fb-comments" data-href="<?php echo e(route('home.post.single', $data->slug)); ?>" data-numposts="5" data-width="100%"></div>
		                    </div>
		                    
		                    	
		                   
		                    <div class="news-bottom">
		                        <div class="row">
		                        	<?php if(count($related_posts)): ?>
			                            <div class="col-md-6 col-sm-6">
			                                <h5 class="title-sm"><span>Bài viết mới nhất</span></h5>
											<?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="news-item-sm">
				                                    <div class="row">
				                                        <div class="col-md-4">
				                                            <a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom"><img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>"> </a>
				                                        </div>
				                                        <div class="col-md-8">
				                                            <div><a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a> </div>
				                                            <p><?php echo e($item->created_at->format('d/m/Y')); ?></p>
				                                        </div>
				                                    </div>
				                                </div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                            </div>
		                            <?php endif; ?>

		                            <?php if(count($related_posts_orther)): ?>
			                            <div class="col-md-6 col-sm-6">
			                                <h5 class="title-sm"><span>Bài viết cũ hơn</span></h5>
											<?php $__currentLoopData = $related_posts_orther; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="news-item-sm">
				                                    <div class="row">
				                                        <div class="col-md-4">
				                                            <a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom"><img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>"> </a>
				                                        </div>
				                                        <div class="col-md-8">
				                                            <div><a href="<?php echo e(route('home.post.single', $item->slug)); ?>" title="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></a> </div>
				                                            <p><?php echo e($item->created_at->format('d/m/Y')); ?></p>
				                                        </div>
				                                    </div>
				                                </div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                            </div>
		                            <?php endif; ?>
		                        </div>
		                    </div>
		                </div>
		            </div>
		            <div class="col-md-3">
		                <?php echo $__env->make('frontend.pages.blog.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		            </div>
		        </div>
		    </div>
		</section>
		</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
	<div id="fb-root"></div>
	<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v7.0&appId=1620283888101801&autoLogAppEvents=1" nonce="2cf7TTY9"></script>
	<script>
		jQuery(document).ready(function($) {
			$('.clickToDiv').click(function(event) {
				id = $(this).data('id');
				$('html,body').animate({
			        scrollTop: $("#" + id).offset().top - 40
			    }, 'slow');
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/pages/blog/single.blade.php ENDPATH**/ ?>