<?php $__env->startSection('main'); ?>
	<section class="breadcrumbs pb-40">
		<div class="container">
			<ul class="list-inline">
				<li class="list-inline-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i><span>/</span></a></li>
				<li class="list-inline-item"><a href="javascript:void(0)">Liên hệ</a></li>
			</ul>
		</div>
	</section>
	<section class="contact">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<h3>Gửi thắc mắc về chúng tôi</h3>
					<form action="<?php echo e(route('home.contact.post')); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="type" value="contact">
						<div class="form-contact">
							<div class="row">
								<div class="col-md-12">
									<div class="item"><input type="text" placeholder="Họ và tên" name="name"></div>
								</div>
								<div class="col-md-6">
									<div class="item"><input type="text" placeholder="Email" name="email"></div>
								</div>
								<div class="col-md-6">
									<div class="item"><input type="text" placeholder="Số điện thoại" name="phone"></div>
								</div>
								<div class="col-md-12">
									<div class="item"><input type="text" placeholder="Địa chỉ" name="address"></div>
								</div>
								<div class="col-md-12">
									<div class="item"><textarea name="content" cols="30" rows="10" placeholder="Nội dung" required=""></textarea></div>
								</div>
								<div class="col-md-12">
									<div class="item"><input type="submit" class="btn-contact" value="GỬI"></div>
								</div>
							</div>
						</div>
					</form>
				</div>
				<div class="col-md-6">
					<h3>LIÊN HỆ</h3>
					<div class="txt-contact">
						<ul>
							<li>
								<p><?php echo @$site_info->desc_sort; ?></p>
							</li>
							<li>
								<p><strong>Địa chỉ </strong></p>
								<p><?php echo @$site_info->address; ?></p>
							</li>
							<li>
								<p><strong>Số điện thoại</strong></p>
								<p><?php echo @$site_info->hotline; ?></p>
							</li>
							<li>
								<p><strong>Email</strong></p>
								<p><?php echo @$site_info->email; ?></p>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-md-12">
					<div class="maps">
						<?php echo @$site_info->script; ?>

					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>