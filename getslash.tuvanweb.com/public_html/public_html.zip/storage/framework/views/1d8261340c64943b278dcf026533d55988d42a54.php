<?php $__env->startSection('main'); ?>
	<main>
		<section class="breadcrumbs pb-40">
			<div class="container">
				<ul class="list-inline">
					<li class="list-inline-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i><span>/</span></a></li>
					<li class="list-inline-item"><a href="<?php echo e(route('home.archive-news')); ?>">Tin tức<span>/</span></a></li>
					<li class="list-inline-item"><a href="javascript:void(0)"><?php echo e($data->name); ?></a></li>
				</ul>
			</div>
		</section>
		<section class="news pb-100">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="detail pb-60">
							<div class="title-detail">
								<h1><?php echo e($data->name); ?></h1>
								<div class="date"><i class="fa fa-clock-o" aria-hidden="true"></i><span><?php echo e($data->created_at->format('d/m/Y')); ?></span></div>
								<div class="desc">
									<?php echo $data->desc; ?>

								</div>
							</div>
							<div class="info-detail">
								<?php echo $data->content; ?>

							</div>
						</div>
						<div class="other">
							<div class="title-other">BÀI VIẾT LIÊN QUAN</div>
							<div class="slide-news-other">
								<?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="item-slide">
										<div class="prd-sale">
											<div class="avarta">
												<a href="<?php echo e(route('home.post.single', $item->slug)); ?>">
													<img src="<?php echo e($item->image); ?>" class="img-fluid w-100" alt="<?php echo e($item->name); ?>">
												</a>
											</div>
											<div class="info">
												<h4><a href="<?php echo e(route('home.post.single', $item->slug)); ?>"><?php echo e($item->name); ?></a></h4>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<?php echo $__env->make('frontend.pages.blog.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/frontend/pages/blog/single.blade.php ENDPATH**/ ?>