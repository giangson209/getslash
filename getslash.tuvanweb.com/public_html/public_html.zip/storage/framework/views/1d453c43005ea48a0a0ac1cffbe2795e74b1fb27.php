
<?php $__env->startSection('main'); ?>
    <?php if(!empty($data->projectDetail) && count($data->projectDetail)): ?>
        <?php $__currentLoopData = $data->projectDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="box-partner box-project">
                <div class="avarta">
                    <img src="<?php echo e($item->banner); ?>" class="img-fluid w-100" alt="" style="height: auto;">
                    <div class="title text-center">
                        <div class="container">
                            <h4 class="text-uppercase  wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s"><?php echo e($item->{ 'name_'.locale() }); ?></h4>
                            <h2 class=" wow fadeInUp wHighlight" data-aos-duration=".25" data-wow-delay=".25s"><?php echo e($item->{ 'sub_name_'.locale() }); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="list-project">
                        <div class="row">
                            <?php $index = 2; ?>
                            <?php $__currentLoopData = $item->getGalleryProjectDetail() ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->index > 4): ?>
                                    <?php break; ?>
                                <?php endif; ?>
                                <div class="col-md-4 wow fadeIn wHighlight" data-wow-delay=".<?php echo $index++ ?>5s" data-index="<?php echo e($loop->index); ?>">
                                    <div class="item-project">
                                        <div class="avarta-pr">
                                            <a href="<?php echo e($gallery->path); ?>" data-fancybox="winner-<?php echo e($item->id); ?>">
                                                <img src="<?php echo e($gallery->path); ?>" class="img-fluid w-100" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(count($item->getGalleryProjectDetail()) > 5): ?>
                                 <?php $__currentLoopData = $item->getGalleryProjectDetail() ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->index < 4): ?>
                                        <?php continue; ?>
                                    <?php endif; ?>

                                    <?php if($loop->index == 5): ?>
                                        <div class="col-md-4 wow fadeIn wHighlight" data-wow-delay=".<?php echo $index++ ?>5s" data-index="<?php echo e($loop->index); ?>">
                                            <div class="item-project pr-all">
                                                <div class="avarta-pr">
                                                    <a href="<?php echo e($gallery->path); ?>" data-fancybox="winner-<?php echo e($item->id); ?>">
                                                        <img src="<?php echo e($gallery->path); ?>" class="img-fluid w-100" alt="">
                                                    </a>
                                                </div>
                                                <div class="clc-all">
                                                    <div class="info text-center">
                                                        <div class="num-pr">+<?php echo e(count($item->getGalleryProjectDetail()) - 4); ?></div>
                                                        <a href="<?php echo e($gallery->path); ?>" data-fancybox="winner-<?php echo e($item->id); ?>">View all</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="col-md-4" style="display: none" data-index="<?php echo e($loop->index); ?>">
                                            <div class="item-project">
                                                <div class="avarta-pr">
                                                    <a href="<?php echo e($gallery->path); ?>" data-fancybox="winner-<?php echo e($item->id); ?>">
                                                        <img src="<?php echo e($gallery->path); ?>" class="img-fluid w-100" alt="">
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/admin/domains/deployweb.info/public_html/befurni/resources/views/frontend/pages/projects/index.blade.php ENDPATH**/ ?>