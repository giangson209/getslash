<?php $__env->startSection('main'); ?>

<main class="fqa">
    <section class="box-banner banner-about">
        <div class="avarta">
            <img src="<?php echo e(@$contentPage->banner->pc); ?>" class="img-fluid w-100 show-pc" alt="<?php echo e(@$contentPage->banner->title); ?>" />
            <img src="<?php echo e(@$contentPage->banner->mobile); ?>" class="img-fluid w-100 d-none show-mb" alt="<?php echo e(@$contentPage->banner->title); ?>" />
        </div>
        <div class="caption-banner">
            <div class="container">
                <div class="info-caption caption-about">
                    <div class="icon-kep"><img src="<?php echo e(__BASE_URL__); ?>/images/kep-white.png" class="img-fluid" alt="<?php echo e(@$contentPage->banner->title); ?>" /></div>
                    <p class="text-uppercase mb-0"><?php echo e(@$contentPage->banner->title); ?></p>
                    <h2 class="mb-0">
                        <?php echo nl2br(@$contentPage->banner->sub_title); ?>

                    </h2>
                    <div class="btn-main">
                        <a href="<?php echo e(@$contentPage->banner->link); ?>"><?php echo e(@$contentPage->banner->nut); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="box-service-about">
        <div class="container">
            <div class="list-service">
                <div class="row">
                    <?php if(!empty(@$contentPage->about)): ?>
                        <?php $__currentLoopData = @$contentPage->about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="item-srv text-center">
                                    <div class="icon"><img src="<?php echo e(@$value->icon); ?>" alt="<?php echo e(@$value->name); ?>" /></div>
                                    <div class="desc">
                                        <h5><?php echo e(@$value->name); ?></h5>
                                        <p><?php echo @$value->desc; ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="banner-qr" style="background-image: url('<?php echo e(__BASE_URL__); ?>/images/background_qr.svg');">
        <div class="container">
            <div class="row">
                <div class="col-md-7">
                    <div class="slider slide-banner-qr slide-img-about">
                        <div class="item-banner">
                            <img src="<?php echo e(@$contentPage->khoi3->banner); ?>" alt="<?php echo e(@$contentPage->khoi3->title); ?>" />
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="info">
                        <h3 class="title-bannerqr">
                            <?php echo e(@$contentPage->khoi3->title); ?>

                        </h3>
                        <span class="content-qr">
                            <?php echo nl2br(@$contentPage->khoi3->sub_title); ?>

                        </span>
                        <div class="image-qr row">
                            <div class="col-md-4">
                                <img src="<?php echo e(@$site_info->qr); ?>" />
                            </div>
                            <div class="col-md-7 btn-qr">
                                <a href="<?php echo e(@$contentPage->khoi3->link); ?>" class="download-qr"><?php echo e(@$contentPage->khoi3->nut); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\slash\resources\views/frontend/pages/about/index.blade.php ENDPATH**/ ?>