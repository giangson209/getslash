<footer>
	<div class="back-top"><a href="javascript:0"><i class="fa fa-chevron-up"></i></a></div>
	<div class="container">
		<div class="content">
			<div class="info-footer">
				<div class="row">
					<div class="col-md-3 col-sm-6">
						<div class="item">
							<div class="title-ft"><?php echo @$site_info->col_footer_1->title; ?></div>
							<div class="link-supp">
								<?php echo @$site_info->col_footer_1->value; ?>

							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="item">
							<div class="title-ft"><?php echo @$site_info->col_footer_2->title; ?></div>
							<div class="hotline">
								<?php echo @$site_info->col_footer_2->value; ?>

							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
						<div class="item">
							<div class="title-ft">Kết nối</div>
							<div class="social">
								<ul>
									<?php if(!empty(@$site_info->social)): ?>
										<?php $__currentLoopData = @$site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li><a title="<?php echo e(@$val->name); ?>" href="<?php echo e(@$val->link); ?>" target="_blank"><i class="<?php echo e(@$val->icon); ?>"></i><?php echo e(@$val->name); ?></a></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6"> 
						<div class="item">
							<div class="title-ft">Fanpage</div>
							<div class="fanpages">
								<?php echo @$site_info->code_facebook; ?>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="callnow" class="hotline">
	    <div class="hotline-phone-ring-wrap">
	        <div class="hotline-phone-ring" id="call-now-1">
	            <div class="hotline-phone-ring-circle"></div>
	            <div class="hotline-phone-ring-circle-fill"></div>
	            <div class="hotline-phone-ring-img-circle">
	                <a href="tel:<?php echo e(@$site_info->hotline); ?>" class="pps-btn-img"> <img src="<?php echo e(__BASE_URL__); ?>/images/quick.png" alt="Gọi điện thoại" width="50" data-lazy-src="" data-pin-no-hover="true" class="lazyloaded" data-was-processed="true">
	                </a>
	            </div>
	        </div>
	        <div class="hotline-bar">
	            <a href="tel:<?php echo e(@$site_info->hotline); ?>"> <span class="text-hotline" id="call-now-1"><?php echo e(@$site_info->hotline); ?></span> </a>
	        </div>
	    </div>
	</div>
</footer><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/hungphu/resources/views/frontend/teamplate/footer.blade.php ENDPATH**/ ?>