<footer class="pd-60">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h4>Thông tin</h4>
                <ul>
                    <li><a href="" title=""><i class="fa fa-map-marker"></i> <?php echo e(@$site_info->address); ?></a> </li>
                    <li><a href="" title=""><i class="fa fa-phone"></i> <?php echo e(@$site_info->hotline); ?></a> </li>
                    <li><a href="" title=""><i class="fa fa-envelope"></i> <?php echo e(@$site_info->email); ?></a> </li>
                </ul>
                <p><?php echo @$site_info->desc_sort; ?></p>
            </div>
            <div class="col-md-2 offset-md-1 col-6">
                <h4>Menu</h4>
                <ul>
                    <?php $__currentLoopData = $menuMain ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url($item->url)); ?>" title=""><?php echo e($item->title); ?></a> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-md-2 col-6">
                <h4>Mạng xã hội</h4>
                <div class="footer-social flex-center">
                    <?php $__currentLoopData = $site_info->social ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(@$value->link); ?>" title="" class="<?php echo e(@$value->icon); ?>"></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-3 offset-md-1">
                <div class="fanpage">
                    <h4>Fanpage</h4>
                    <?php echo @$site_info->code_facebook; ?>

                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH /home/admin/domains/deployweb.info/public_html/home-tech/resources/views/frontend/teamplate/footer.blade.php ENDPATH**/ ?>