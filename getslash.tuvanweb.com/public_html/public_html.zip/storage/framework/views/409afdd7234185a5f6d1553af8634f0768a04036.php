<?php $__env->startSection('controller', $module['name'] ); ?>
<?php $__env->startSection('controller_route', route($module['module'].'.index')); ?>
<?php $__env->startSection('action', 'Chỉnh sửa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo updateOrStoreRouteRender( @$module['action'], $module['module'], @$data); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(isUpdate(@$module['action'])): ?>
                        <?php echo e(method_field('put')); ?>

                    <?php endif; ?>
                	<div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="">Tên người bình buận</label>
                                <input type="text" name="name_customer" class="form-control" value="<?php echo e(old('name_customer', $data->name_customer)); ?>" required="">
                            </div>
                            <div class="form-group">
                                <label for="">Sao</label>
                                <select name="vote" class="form-control">
                                    <?php for($i = 1; $i < 6; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e($i == $data->vote ? 'selected' : null); ?>><?php echo e($i); ?> sao</option>
                                    <?php endfor; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="">Nội dung bình luận</label>
                                <textarea class="form-control" name="content" required="" rows="8"><?php echo e(old('content', $data->content)); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Lưu lại</button>
                        </div>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
	<style>
		.row-upload .col-upload {
		    padding: 0 7px;
		}
		.row-upload {
		    display: inline-flex;
		    width: 100%;
		    flex-wrap: wrap;
		    margin: 0 -7px;
		}
		.row-upload .col-upload img {
		    width: 70px;
		    height: 70px;
		    object-fit: cover;
		    border-radius: 3px;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/backend/comments/edit.blade.php ENDPATH**/ ?>