
<?php $__env->startSection('main'); ?>
	<section id="bread">
		<div class="container">
			<div class="content">
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ</a></li>
					<li class="list-inline-item"><a title="Thương hiệu" href="<?php echo e(route('home.brand')); ?>">Thương hiệu</a></li>
					<li class="list-inline-item"><a title="<?php echo e($data->name); ?>" href="javascript:0"><?php echo e($data->name); ?></a></li>
				</ul>
				<div class="avar-bread">
					<div class="avarta">
						<img data-src="<?php echo e(!empty($data->banner) ? $data->banner : __BASE_URL__.'/images/thuonghieu.jpg'); ?>" class="img-fluid lazyload" alt="<?php echo e($data->name); ?>">
					</div>
					<div class="caption text-center">
						<h1><?php echo e($data->name); ?></h1>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section id="product" class="pb-80">
		<div class="container">
			<div class="content">
				<div class="tab-hot-sale slide-th">
					<div class="grid-tabs">
						<div class="row">
							<div class="col-md-2">
								<div class="grid text-center">
									<div class="item-grid"><a title="" href="javascript:0" class="clc-gird active"><i class="fa fa-th"></i></a></div>
									<div class="item-grid"><a title="" href="javascript:0" class="clc-list"><i class="fa fa-bars"></i></a></div>
								</div>
							</div>
							<div class="col-md-10" style="padding-left: 0;">
								<ul class="tabs" style="border: 0;">
									<li class="">
										<a class="tab-prd active" href="javascript:0" data-tab="tab-1-1" >Nổi bật</a>
									</li>
									<?php if(!empty($category_display)): ?>
										<?php $__currentLoopData = $category_display; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li class="">
												<a class="tab-prd" href="<?php echo e(route('home.products.category.brand', ['category' => $item->slug, 'brand' => $data->slug])); ?>" data-tab="tab-c-<?php echo e($item->id); ?>-<?php echo e($loop->index + 1); ?>" ><?php echo e($item->name); ?></a>
											</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					</div>
					<div class="tab-content">
						<div class="tab-pane pane-prd active" id="tab-1-1">
							<div class="list-product prd-list">
								<div class="row list-product-hot-style-1">
									<?php if(count($products_hot_by_brand)): ?>
										<?php $__currentLoopData = $products_hot_by_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="col-lg-3 col-6 col-sm-3">
												<?php $__env->startComponent('frontend.components.product-style-2', ['item'=> $item]); ?>
							    
												<?php echo $__env->renderComponent(); ?>
											</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<div class="col-sm-12">
											<div class="alert alert-success" role="alert">
											  	Không có sản phẩm nào phù hợp.
											</div>
										</div>
									<?php endif; ?>
								</div>
							</div>
							<div class="grid-prd list-product-hot-style-2">
								<?php if(count($products_hot_by_brand)): ?>
									<?php $__currentLoopData = $products_hot_by_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php $__env->startComponent('frontend.components.product-style-3', ['item'=> $item]); ?>
							    
										<?php echo $__env->renderComponent(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									<div class="item">
										<div class="alert alert-success" style="width: 100%;" role="alert">
										  	Không có sản phẩm nào phù hợp.
										</div>
									</div>
								<?php endif; ?>
							</div>
							<div class="load-more text-center pt-50" style="background: #f9f9f9;">
								<a title="Xem thêm" href="javascript:;" class="loadMoreHot">Xem thêm</a>
								<input type="hidden" value="12">
							</div>
						</div>
						<?php if(!empty($category_display)): ?>
							<?php $__currentLoopData = $category_display; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php 
									$list_id_children = get_list_ids($item);
						            $list_id_children[] = $item->id;
						            $list_id_product = \App\Models\ProductCategory::whereIn('id_category', $list_id_children)->get()->pluck('id_product')->toArray();
						            $dataProductsByCategory = \App\Models\Products::whereIn('id', $list_id_product )->active()->where('brand_id', $data->id)->order()->take(12)->get();
								?>

								<div class="tab-pane pane-prd" id="tab-c-<?php echo e($item->id); ?>-<?php echo e($loop->index + 1); ?>">
									<div class="list-product prd-list">
										<div class="row list-product-category-style-1-<?php echo e($item->id); ?>">
											<?php if(count($dataProductsByCategory)): ?>
												<?php $__currentLoopData = $dataProductsByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class="col-lg-3 col-6 col-sm-3">
														<?php $__env->startComponent('frontend.components.product-style-2', ['item'=> $value]); ?>
														<?php echo $__env->renderComponent(); ?>
													</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php else: ?>
												<div class="col-sm-12">
													<div class="alert alert-success" role="alert">
													  	Không có sản phẩm nào phù hợp.
													</div>
												</div>
											<?php endif; ?>
										</div>
									</div>
									<div class="grid-prd list-product-category-style-2-<?php echo e($item->id); ?>">
										<?php if(count($dataProductsByCategory)): ?>
											<?php $__currentLoopData = $dataProductsByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php $__env->startComponent('frontend.components.product-style-3', ['item'=> $value]); ?>
												<?php echo $__env->renderComponent(); ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
											<div class="item">
												<div class="alert alert-success" style="width: 100%;" role="alert">
												  	Không có sản phẩm nào phù hợp.
												</div>
											</div>
										<?php endif; ?>
									</div>
									<div class="load-more text-center pt-50" style="background: #f9f9f9;">
										<a title="Xem thêm" href="javascript:;" class="loadMoreCategory" data-id="<?php echo e($item->id); ?>">Xem thêm</a>
										<input type="hidden" value="12">
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
				<div class="other-partner pt-80">
					<div class="title-prt text-center"><h2 class="text-uppercase">Các thương hiệu khác</h2></div>
					<div class="slide-prt text-center">
						<?php $__currentLoopData = $list_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="item">
								<a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single.brand', $item->slug)); ?>">
									<img data-src="<?php echo e($item->image); ?>" class="img-fluid lazyload" alt="<?php echo e($item->name); ?>">
								</a>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</section> 


	<?php echo $__env->make('frontend.teamplate.parts.modal-emty-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
		jQuery(document).ready(function($) {
			$('.loadMoreHot').click(function(event) {
				brand_id = '<?php echo e($data->id); ?>';
				var offset = parseInt($(this).next().val());
				btn = $(this);
				$('.loadingcover').show();
				$.get('<?php echo e(route('home.load.products.brand.ajax')); ?>', { offset : offset, brand_id : brand_id } , function(data) {
					$('.loadingcover').hide();
					btn.next().val(offset + 12);
					if(data.style_1 != '' && data.style_2 != ''){
						$('.list-product-hot-style-1').append(data.style_1);
						$('.list-product-hot-style-2').append(data.style_2);
					}else{
						$('#exampleModal').modal('show');
						btn.remove();
					}
				});
			});

			$('.loadMoreCategory').click(function(event) {
				brand_id = '<?php echo e($data->id); ?>';
				var offset = parseInt($(this).next().val());
				btn = $(this);
				category = $(this).data('id');
				$('.loadingcover').show();
				$.get('<?php echo e(route('home.load.products.brand.ajax')); ?>', { offset : offset, brand_id : brand_id, category : category } ,function(data) {
					$('.loadingcover').hide();
					btn.next().val(offset + 12);
					if(data.style_1 != '' && data.style_2 != ''){
						$('.list-product-category-style-1-'+category).append(data.style_1);
						$('.list-product-category-style-2-'+category).append(data.style_2);
					}else{
						$('#exampleModal').modal('show');
						btn.remove();
					}
				});
			});

		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bephungphu/public_html/resources/views/frontend/pages/single-brand.blade.php ENDPATH**/ ?>