<?php $__env->startSection('controller','Developer'); ?>
<?php $__env->startSection('action','Upadte'); ?>
<?php $__env->startSection('controller_route', route('backend.options.developer-config')); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo e(route('backend.options.developer-config.post')); ?>" method="POST">
               		<?php echo csrf_field(); ?>
               		<div class="row">
               			<div class="col-lg-2">
	                        <div class="form-group">
	                           <label>Favicon</label>
	                           <div class="image">
	                               <div class="image__thumbnail">
	                                   <img src="<?php echo e(!empty($content->favicon) ? $content->favicon :  __IMAGE_DEFAULT__); ?>"  data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
	                                   <a href="javascript:void(0)" class="image__delete" 
	                                   onclick="urlFileDelete(this)">
	                                    <i class="fa fa-times"></i></a>
	                                   <input type="hidden" value="<?php echo e(@$content->favicon); ?>" name="content[favicon]"  />
	                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
	                               </div>
	                           </div>
	                       </div>
	                    </div>
	                    <div class="col-lg-2">
	                        <div class="form-group">
	                           <label>Logo</label>
	                           <div class="image">
	                               <div class="image__thumbnail">
	                                   <img src="<?php echo e(!empty($content->logo) ? $content->logo :  __IMAGE_DEFAULT__); ?>"  data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
	                                   <a href="javascript:void(0)" class="image__delete" 
	                                   onclick="urlFileDelete(this)">
	                                    <i class="fa fa-times"></i></a>
	                                   <input type="hidden" value="<?php echo e(@$content->logo); ?>" name="content[logo]"  />
	                                   <div class="image__button" onclick="fileSelect(this)"><i class="fa fa-upload"></i> Upload</div>
	                               </div>
	                           </div>
	                       </div>
	                    </div>

	                    <div class="col-sm-8">
	                    	<div class="form-group">
	                    		<label for="">Tiêu đề trang quản trị</label>
	                    		<input type="text" name="content[title]" required="" class="form-control" 
	                    		value="<?php echo e(@$content->title); ?>">
	                    	</div>
	                    	<div class="form-group">
	                    		<label for="">Tiêu đề trang đăng nhập</label>
	                    		<input type="text" name="content[title_login]" required="" class="form-control"
	                    		value="<?php echo e(@$content->title_login); ?>">
	                    	</div>
	                    </div>
               		</div>
               		<button type="submit" class="btn btn-primary">Lưu lại</button>	
               	</form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/backend/options/developer-config.blade.php ENDPATH**/ ?>