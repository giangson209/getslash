<?php $__env->startSection('main'); ?>
	<h1 style="display: none;"><?php echo e(@$dataSeo->title_h1); ?></h1>
	<?php echo $__env->make('frontend.teamplate.breadcrumbs', [ 
		'config' => [
			'banner' => @$dataSeo->banner,
			'title' => 'Hosting + vps'
		] 
	], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<section id="hosting" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase jose"><h2>Bảng giá hosting</h2></div>
				<div class="list-hosting">
					<div class="row">
						<?php 
							$color = [
								'#3498db', '#1abc9c', '#f7a13e', '#e74c3c'
							];
						?>
						<?php if(!empty($service_hosting)): ?>
							<?php $__currentLoopData = $service_hosting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-lg-3 col-sm-6">
									<div class="item">
										<div class="title-host text-center jose" 
										style="background: <?php echo e(@$color[$loop->index]); ?>"><?php echo $item->name; ?></div>
										<div class="price text-center"><?php echo $item->label_price; ?></div>
										<div class="info-hosting">
											<?php if(!empty($item->content)){
												$content = json_decode($item->content);
											} ?>
											<ul class="r">
												<?php if(!empty($content->meta)): ?>
													<?php $__currentLoopData = $content->meta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<li>
															<span><?php echo e($value->title); ?></span>
															<label><?php echo e($value->value); ?></label>
														</li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>
											</ul>
										</div>
										<div class="add_to_cart that_data_service-<?php echo e($loop->index + 1); ?>">
		                                    <div class="select_popup">
		                                        <a class="popup-with-move-anim" href="javascript:0" data-toggle="modal" data-target="#myModal-check-<?php echo e($loop->index + 1); ?>"><span>Chọn gói thời gian</span>
		                                            <i class="fa fa-calendar"></i>
		                                        </a>
		                                    </div>
		                                    <input type="hidden" name="cycle" class="cycle" value="">
		                                    <input type="hidden" name="id" class="idServiceChild" value="">
		                                </div>
		                                <div class="btn-buy text-center">
											<a href="javascript:;" data-parent="<?php echo e($item->id); ?>" class="addCart" >ĐẶT MUA</a>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						
						
						<div class="col-md-12">
							<div class="btn-view text-center">
								<a href="javascript:0" data-toggle="modal" data-target="#myModal-host">Dịch vụ bổ sung</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade hosting-vps" id="myModal-host">
			<div class="modal-dialog">
			    <div class="modal-content">
				    <div class="modal-body">
				      	<button type="button" class="close d-none" data-dismiss="modal">&times;</button>
				        <form action="<?php echo e(route('home.addCart.post')); ?>" method="POST">
				        	<?php echo csrf_field(); ?>
				        	<input type="hidden" name="type" value="additional-vps">
				        	<div class="content-popup">
					        	<div class="title text-center text-uppercase jose"><h2>Dịch vụ bổ sung Hosting</h2></div>
					        	<div class="list-add">
					        		<?php if(!empty($service_additional_hosting)): ?>
					        			<?php $__currentLoopData = $service_additional_hosting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        				<p>
							        			<input type="checkbox"  
							        			class="add-qtt add-2-1" id="fruit<?php echo e($loop->index + 1); ?>-1" 
							        			name="services[]" value="<?php echo e($item->id); ?>">
			  									<label for="fruit<?php echo e($loop->index + 1); ?>-1"><?php echo e($item->name); ?></label>
							        		</p>
					        				<p>
							        			<span>Số lượng cần thêm</span> 
							        			<select name="qtt-<?php echo e($item->id); ?>" id="quantt">
							        				<option value="1" selected>1</option>
							        				<option value="2">2</option>
							        				<option value="3">3</option>
							        				<option value="4">4</option>
							        				<option value="5">5</option>
							        			</select>
							        		</p>
					        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        		<?php endif; ?>
					        	</div>
					        	<div class="price-cart">
					        		<ul>
					        			<li>
					        				<div class="price">Tổng tiền: <span class="base">0</span>.000đ</div>
					        			</li>
					        			<li>
					        				<div class="cart text-center">
					        					<button type="submit">
					        						<img src="<?php echo e(__BASE_URL__); ?>/images/cart.png" class="img-fluid" class="add-cart" alt="add-cart">Thêm vào giỏ hàng
					        					</button>
					        				</div>
					        			</li>
					        		</ul>
					        	</div>
					        </div>
				        </form>
				    </div>
			    </div>
			</div>
		</div>
		
		<?php if(!empty($service_hosting)): ?>
			<?php $__currentLoopData = $service_hosting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="modal fade hosting-vps" id="myModal-check-<?php echo e($loop->index + 1); ?>">
					<div class="modal-dialog">
					    <div class="modal-content">
					    	<div class="modal-body">
								<div class="pop">
									<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times"></i></button>
						        	<div class="mfp-hide">
						        		<div class="title-buy text-center">CHỌN THỜI GIAN CHO GÓI <?php echo e($item->name); ?></div>
						        		<div class="row">
						        			<?php $indexClass = $loop->index + 1 ?>
						        			<?php if(count($item->get_servives_child())): ?>
						        				<?php $__currentLoopData = $item->get_servives_child(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						        					<div class="col-md-4">
								        				<div class="item check_service_email_cycle" 
								        				data-cycle="<?php echo e(@$value->meta); ?>" data-id-child="<?php echo e(@$value->id); ?>"
								        				data-price="<?php echo e(number_format(@$value->price)); ?> đ" data-class="that_data_service-<?php echo e($indexClass); ?>">
								        					 <figure class="box time">
									                            <h2><?php echo e(@$value->meta); ?> Tháng</h2>
									                            <ul>
									                                <li class="price-month"><?php echo @$value->label_price; ?></li>
									                                <li class="price">Tổng: <?php echo e(number_format(@$value->price)); ?> đ</li>
									                            </ul>
									                        </figure>
								        				</div>
								        			</div>
						        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						        			<?php else: ?>
						        				<h3 class="title-buy">Nội dung đang được cập nhật</h3>
						        			<?php endif; ?>
						        			<div class="col-md-12">
						        				<div class="close-pop text-center">
						        					<a href="javascript:0">Không, cảm ơn !</a>
						        				</div>
						        			</div>
						        		</div>
						            </div>
						        </div>
					    	</div>
					    </div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
		<div class="modal fade" tabindex="-1" role="dialog"  id="exampleModal">
		    <div class="modal-dialog" role="document">
		        <div class="modal-content">
		            <div class="modal-header">
		                <h5 class="modal-title">Thông báo</h5>
		                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		                    <span aria-hidden="true">&times;</span>
		                </button>
		            </div>
		            <div class="modal-body">
		                <p>Mời bạn chọn thời gian sử dụng</p>
		            </div>
		            <div class="modal-footer">
		                <button type="button" class="btn btn-secondary" data-dismiss="modal">OK</button>
		            </div>
		        </div>
		    </div>
		</div>

	</section>

	<section id="vps" class="pt-100 pb-100" style="background: #f9f9f9;">
		<div class="container">
			<div class="content">
				<div class="title text-center text-uppercase jose"><h2>Bảng giá VPS</h2></div>
				<div class="list-vps">
					<div class="row">
						<?php if(!empty($service_vps)): ?>
							<?php $__currentLoopData = $service_vps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-2">
									<div class="item text-center">
										<div class="title-vps text-center jose"><?php echo e($item->name); ?></div>
										<div class="price"><?php echo $item->label_price; ?></div>
										<?php if(!empty($item->content)){
											$content = json_decode($item->content);
										} ?>
										<ul>
											<?php if(!empty($content->meta)): ?>
												<?php $__currentLoopData = $content->meta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><?php echo e(@$value->title); ?> : <?php echo e(@$value->value); ?></li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
										</ul>
										<div class="btn-buy text-center">
											<a href="<?php echo e(route('home.addCart' , [ 'type' => 'vps', 'id' => $item->id ])); ?>" title="Đặt Mua">ĐẶT MUA</a>
										</div>
									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
						
						<div class="col-md-12">
							<div class="btn-view text-center">
								<a href="javascript:0" data-toggle="modal" data-target="#myModal-vps">Dịch vụ bổ sung</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade hosting-vps" id="myModal-vps">
			<div class="modal-dialog">
			    <div class="modal-content">
				    <div class="modal-body">
				      	<button type="button" class="close d-none" data-dismiss="modal">&times;</button>
				        <form action="<?php echo e(route('home.addCart.post')); ?>" method="POST">
				        	<?php echo csrf_field(); ?>
				        	<input type="hidden" name="type" value="additional-vps">
				        	<div class="content-popup">
					        	<div class="title text-center text-uppercase jose"><h2>Dịch vụ bổ sung VPS</h2></div>
					        	<div class="list-add">
					        		<?php if(!empty($service_additional_vps)): ?>
					        			<?php $__currentLoopData = $service_additional_vps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        				<p>
							        			<input type="checkbox"  
							        			class="add-qtt add-2-1" id="fruit<?php echo e($loop->index + 1); ?>-1" 
							        			name="services[]" value="<?php echo e($item->id); ?>">
			  									<label for="fruit<?php echo e($loop->index + 1); ?>-1"><?php echo e($item->name); ?></label>
							        		</p>
					        				<p>
							        			<span>Số lượng cần thêm</span> 
							        			<select name="qtt-<?php echo e($item->id); ?>" id="quantt">
							        				<option value="1" selected>1</option>
							        				<option value="2">2</option>
							        				<option value="3">3</option>
							        				<option value="4">4</option>
							        				<option value="5">5</option>
							        			</select>
							        		</p>
					        			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        		<?php endif; ?>
					        	</div>
					        	<div class="price-cart">
					        		<ul>
					        			<li>
					        				<div class="price">Tổng tiền: <span class="base">0</span>.000đ</div>
					        			</li>
					        			<li>
					        				<div class="cart text-center">
					        					<button type="submit">
					        						<img src="<?php echo e(__BASE_URL__); ?>/images/cart.png" class="img-fluid" class="add-cart" alt="add-cart">Thêm vào giỏ hàng
					        					</button>
					        				</div>
					        			</li>
					        		</ul>
					        	</div>
					        </div>
				        </form>
				    </div>
			    </div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script>
		jQuery(document).ready(function($) {
			$('.addCart').click(function(event) {
				var idServiceChild = $(this).parent().prev().find('.idServiceChild').val();
				var idServiceParent = $(this).data('parent');
				if($.trim(idServiceChild).length){
					$(this).off('click');
					$(this).html('<i class="fa fa-refresh fa-spin fa-fw"></i>');
					$.ajax({
						url: '<?php echo e(route('home.addCart')); ?>',
						type: 'GET',
						data: {
							type: 'hosting',
							idServiceChild: idServiceChild,
							idServiceParent : idServiceParent,
						},
					})
					.done(function(data) {
						showToast('Thêm thành công dịch vụ vào giỏ hàng', 'Thông báo');
						setInterval(function(){
							location.reload();
						}, 2000);
					})
				}else{
					$('#exampleModal').modal('show');
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/frontend/pages/services/hosting-vps.blade.php ENDPATH**/ ?>