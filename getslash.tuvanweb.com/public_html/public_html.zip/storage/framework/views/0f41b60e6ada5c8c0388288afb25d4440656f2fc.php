<div class="list-news-bar">
	<?php if($type == 'news'): ?>
		<div class="item">
			<div class="avarta"><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>">
				<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($item->name); ?>"></a>
			</div>
			<div class="info">
				<h4><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.post.single', $item->slug)); ?>"><?php echo e(text_limit($item->name, 7)); ?>...</a></h4>
				<div class="date"><?php echo e($item->created_at->format('d/m/yy')); ?></div>
			</div>
		</div>
	<?php else: ?>
		<div class="item">
			<div class="avarta"><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single-project', $item->slug)); ?>">
				<img src="<?php echo e($item->image); ?>" class="img-fluid" alt="<?php echo e($item->name); ?>"></a>
			</div>
			<div class="info">
				<h4><a title="<?php echo e($item->name); ?>" href="<?php echo e(route('home.single-project', $item->slug)); ?>"><?php echo e(text_limit($item->name, 7)); ?>...</a></h4>
				<div class="date"><?php echo e($item->created_at->format('d/m/yy')); ?></div>
			</div>
		</div>	
	<?php endif; ?>
</div><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/bacviet/resources/views/frontend/components/side-bar.blade.php ENDPATH**/ ?>