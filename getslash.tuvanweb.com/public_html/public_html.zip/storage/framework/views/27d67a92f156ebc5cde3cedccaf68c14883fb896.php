
<?php $__env->startSection('controller','Loại website'); ?>
<?php $__env->startSection('controller_route', route('backend.services.getListType')); ?>
<?php $__env->startSection('action',''); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<div class="row">
                    <div class="col-sm-12">
                        <h4>Xây dựng mô đun trang: <?php echo e($typeWebsite->name); ?></h4>
                        <p>Liên kết: <a href="<?php echo e(route('home.services.website', $typeWebsite->slug)); ?>" target="_blank">
                            <?php echo e(route('home.services.website', $typeWebsite->slug)); ?></a>
                        </p>
                    </div>
	               	<div class="col-sm-12" style="padding-bottom: 30px; padding-top: 10px;">
			            <button class="btn btn-info" data-toggle="modal" data-target="#addMenu" type="button">
			            	Thêm mới mô đun
			            </button>
			            <input type="hidden" id="nestable-output" name="jsonMenu">
			            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>" id="token">
			        </div>
			        <div class="col-sm-12">
			        	<?php if(count($moduleByType)): ?>
				            <div class="dd" id="nestable">
				                <ol class="dd-list">
									<?php $__currentLoopData = $moduleByType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(empty($item->parent_id)): ?>
				                            <li class="dd-item" data-id="<?php echo e($item->id); ?>">
				                                <div class="dd-handle">
				                                    <?php echo e($item->name); ?> (<i><?php echo e(number_format($item->price)); ?>đ</i>)
				                                </div>
				                                <div class="button-group">
				                                    <a href="javascript:;" class="modalEditMenu" data-id="<?php echo e($item->id); ?>"> 
				                                        <i class="fa fa-pencil fa-fw"></i> Sửa
				                                    </a> &nbsp; &nbsp; &nbsp;
				                                    <a class="text-danger" href="<?php echo route('backend.services.build.getDeleteModule',$item['id']); ?>" onclick="return confirm('Bạn có chắc chắn xóa không ?')" title="Xóa"> <i class="fa fa-trash-o fa-fw"></i> Xóa</a>
				                                </div>

				                                <?php if(count($item->get_child())): ?>
				                                	<ol class="dd-list">
					                                	<?php $__currentLoopData = $item->get_child(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                                		<li class="dd-item" data-id="<?php echo e($value->id); ?>">
					                                			<div class="dd-handle">
								                                    <?php echo e($value->name); ?> (<i><?php echo e(number_format($value->price)); ?>đ</i>)
								                                </div>
						                                		<div class="button-group">
								                                    <a href="javascript:;" class="modalEditMenu" data-id="<?php echo e($value->id); ?>"> 
								                                        <i class="fa fa-pencil fa-fw"></i> Sửa
								                                    </a> &nbsp; &nbsp; &nbsp;
								                                    <a class="text-danger" href="<?php echo route('backend.services.build.getDeleteModule',$value['id']); ?>" onclick="return confirm('Bạn có chắc chắn xóa không ?')" title="Xóa"> <i class="fa fa-trash-o fa-fw"></i> Xóa</a>
								                                </div>
							                                </li>
					                                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                                </ol>
				                                <?php endif; ?>
				                            </li>
			                        	<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				                </ol>
				            </div>
			            <?php endif; ?>
			        </div>
		        </div>
            </div>
        </div>
    </div>


    <div class="modal" id="addMenu">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Thêm mới</h4>
                    <form action="<?php echo e(route('backend.services.build.postAddModule', $id)); ?>" method="POST">
                    	<div class="modal-body" style="padding-left: 0px; padding-right: 0px;">
	                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
	                        <div class="form-group">
	                        	<label for="">Tên mô đun</label>
	                        	<input type="text" name="name" class="form-control" required="" placeholder="Nhập tên mô đun">
	                        </div>
	                        <div class="form-group">
	                        	<label for="">Giá</label>
	                        	<input type="number" name="price" class="form-control" required="" placeholder="Nhập giá">
	                        </div>
	                    </div>
	                    <div class="modal-footer">
	                        <button type="submit" class="btn btn-success">Thêm mới</button>
	                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
	                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

	<div class="modal" id="editMenu">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Chỉnh sửa</h4>
                    <form action="<?php echo e(route('backend.services.build.postUpdateInfoModule')); ?>" method="POST">
                    	<div class="modal-body" style="padding-left: 0px; padding-right: 0px;">
	                        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
	                        <div class="form-group">
	                        	<label for="">Tên mô đun</label>
	                        	<input type="text" name="name" class="form-control" required="" placeholder="Nhập tên mô đun" id="editTitle">
	                        </div>
	                        <div class="form-group">
	                        	<label for="">Giá</label>
	                        	<input type="number" name="price" class="form-control" required="" placeholder="Nhập giá" id="editPrice">
	                        </div>
	                    </div>
	                    <div class="modal-footer">
	                    	<input type="hidden" id="editID" value="" name="idM">
	                        <button type="submit" class="btn btn-success">Chỉnh sửa</button>
	                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
	                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        jQuery(document).ready(function($) {
            var updateOutput = function(e){
                var list   = e.length ? e : $(e.target),
                    output = list.data('output');
                if (window.JSON) {
                    output.val(window.JSON.stringify(list.nestable('serialize')));//, null, 2));
                    var param = window.JSON.stringify(list.nestable('serialize'));
                    $.ajax({
                        url: '<?php echo e(route('backend.services.build.postUpdateModule')); ?>',
                        type: 'POST',
                        data: {
                            _token : $('#token').val(),
                            jsonMenu: param
                        },
                    }).done(function() {
                            $.toast({
                            text: "Cập nhật thành công !",
                            heading: 'Thông báo',
                            icon: 'success',
                            showHideTransition: 'fade',
                            allowToastClose: true, // Boolean value true or false
                            hideAfter: 1000, 
                            stack: 5, 
                            position: 'top-right', 
                            textAlign: 'left',
                            loader: true,
                            loaderBg: '#9ec600',
                        });
                    })
                } else {
                    output.val('JSON browser support required for this demo.');
                }
            };
            $('#nestable').nestable({
                group: 3,
                maxDepth : 2
            }).on('change', updateOutput);
            updateOutput($('#nestable').data('output', $('#nestable-output')));
        });


        $('.modalEditMenu').click(function(event) {
            var id = $(this).attr("data-id");
            $.get('<?php echo e(route('backend.services.build.getViewModule')); ?>?id='+id, function(data) {
                if(data.status == "success"){
                    $('#editTitle').val(data.data.name);
                    $('#editPrice').val(data.data.price);
                    $('#editID').val(data.data.id);
                    $('#editMenu').modal('show')
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/dimaweb/resources/views/backend/services/website/build-module.blade.php ENDPATH**/ ?>