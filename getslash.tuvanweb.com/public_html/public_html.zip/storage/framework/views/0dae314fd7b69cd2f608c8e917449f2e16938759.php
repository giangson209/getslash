<?php $__env->startSection('main'); ?>
	<section class="breadrumbs">
        <div class="container">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home" aria-hidden="true"></i></a></li>
                <li class="breadcrumb-item active" aria-current="page">Tìm kiếm từ khóa: <?php echo e(request('search')); ?></li>
              </ol>
            </nav>
        </div>
    </section>

     <section class="product-list">
        <div class="container">
            <div class="block-top flex-center-between">
                <h1 class="product-title">Tìm kiếm từ khóa: <?php echo e(request('search')); ?></h1>
            </div>
            <div class="row no-mr product-items">
                <?php if(count($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 no-pd">
                            <div class="product-item text-center">
                                <div class="product-photo">
                                    <a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom">
                                        <img data-src="<?php echo e($item->image); ?>" class="lazyload" alt="<?php echo e($item->name); ?>">
                                    </a>
                                </div>
                                <h3 class="product-name">
                                    <a href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="<?php echo e($item->name); ?>" class="zoom"><?php echo e($item->name); ?></a>
                                </h3>
                                <div class="price-wrapper">
                                    <?php if(!empty($item->sale_price)): ?>
                                        <span class="old-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                                        <span class="special-price"><?php echo e(number_format($item->sale_price, 0, '.', '.')); ?>đ</span>
                                    <?php else: ?>
                                        <span class="special-price"><?php echo e(number_format($item->regular_price, 0, '.', '.')); ?>đ</span>
                                    <?php endif; ?>
                                </div>
                                <div class="product-action">
                                    <a class="product-view" href="<?php echo e(route('home.single.product', $item->slug)); ?>" title="Chi tiết">Chi tiết</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="alert alert-primary" role="alert" style="width: 100%">
                        Không tìm thấy sản phẩm phù hợp.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section class="paginations">
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center">
                <?php echo $data->appends(request()->all())->links(); ?>

            </ul>
        </nav>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/pages/products/search.blade.php ENDPATH**/ ?>