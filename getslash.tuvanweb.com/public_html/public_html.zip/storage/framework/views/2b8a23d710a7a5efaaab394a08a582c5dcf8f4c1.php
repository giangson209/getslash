<?php $__env->startSection('controller','Loại website'); ?>
<?php $__env->startSection('controller_route', route('backend.services.getListType')); ?>
<?php $__env->startSection('action','Chỉnh sửa'); ?>
<?php $__env->startSection('content'); ?>
	<div class="content">
		<div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
               	<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<form action="<?php echo e(route('backend.services.postEditType', $data->id)); ?>" method="POST">
               		<?php echo csrf_field(); ?>
		            <div class="nav-tabs-custom">
		                <ul class="nav nav-tabs">
		                    <li class="active">
		                        <a href="#activity" data-toggle="tab" aria-expanded="true">Loại website</a>
		                    </li>
		                    <li class="">
		                    	<a href="#setting" data-toggle="tab" aria-expanded="true">Cấu hình seo</a>
		                    </li>
		                </ul>
		                <div class="tab-content">
		                    <div class="tab-pane active" id="activity">

		                    	<div class="form-group">
                                    <label>Tiêu đề</label>
                                    <input type="text" class="form-control" name="name" id="name" 
                                    value="<?php echo old('name', $data->name); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Đường dẫn tĩnh</label>
                                    <input type="text" class="form-control" 
                                    name="slug" id="slug" value="<?php echo old('slug', $data->slug); ?>">
                                </div>

                                <label class="custom-checkbox">
		                            <input type="checkbox" name="status" value="1" <?php echo e($data->status == 1 ? 'checked' : null); ?>> Hiển thị
		                        </label>

		                    </div>

		                    <div class="tab-pane" id="setting">

		                    	<div class="row">
		                    		<div class="col-sm-2">
		                    			<div class="form-group">
		                    				<label for="">Hình ảnh</label>
					                        <div class="image">
					                            <div class="image__thumbnail">
					                                <img src="<?php echo e(!empty($data->image) ? $data->image : __IMAGE_DEFAULT__); ?>"
					                                     data-init="<?php echo e(__IMAGE_DEFAULT__); ?>">
					                                <a href="javascript:void(0)" class="image__delete" onclick="urlFileDelete(this)">
					                                    <i class="fa fa-times"></i></a>
					                                <input type="hidden" value="<?php echo e(old('image', @$data->image )); ?>" name="image"/>
					                                <div class="image__button" onclick="fileSelect(this)">
					                                	<i class="fa fa-upload"></i>
					                                    Upload
					                                </div>
					                            </div>
					                        </div>
					                    </div>
		                    		</div>
		                    		<div class="col-sm-10">
		                    			<div class="form-group">
				                            <label>Title SEO</label>
				                            <input type="text" class="form-control" name="meta_title" 
				                            value="<?php echo old('meta_title', @$data->meta_title ); ?>">
				                        </div>

				                        <div class="form-group">
				                            <label>Meta Description</label>
				                            <textarea name="meta_description" id="" class="form-control"
				                                      rows="5"><?php echo old('meta_description', @$data->meta_description); ?></textarea>
				                        </div>

				                        <div class="form-group">
				                            <label>Meta Keyword</label>
				                            <input type="text" class="form-control" name="meta_keyword"
				                                   value="<?php echo old('meta_keyword', @$data->meta_keyword); ?>">
				                        </div>
		                    		</div>
		                    	</div>
		                    	
		                    </div>

		                    <div class="row">
		                    	<div class="col-sm-12">
		                    		<button type="submit" class="btn btn-primary">Lưu lại</button>
		                    	</div>
		                    </div>

		                </div>
		            </div>
               	</form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimaweb\resources\views/backend/services/website/type/edit.blade.php ENDPATH**/ ?>