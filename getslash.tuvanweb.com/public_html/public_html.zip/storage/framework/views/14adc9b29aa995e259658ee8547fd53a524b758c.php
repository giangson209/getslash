<div class="filter">
    <div class="box-filter">
        <div class="title-filt">Khoảng giá</div>
        <?php $filterPrice = \App\Models\Filter::where('type', 'price')->first();
            if(!empty($filterPrice->content)){
                $filterContent = json_decode( $filterPrice->content );
            }
         ?>
        <ul>
            <li class="fillter">
                <?php
                    $url_query_render = url_query_render('price', 'all' );
                    $url = $url_query_render['url']  ;
                    $active = $url_query_render['active'] ? 'checked' : null ;
                ?>
                <input type="radio" id="f-1-1" name="filt-1" <?php echo e($active); ?> <?php echo e(empty(request('price')) ? 'checked' : null); ?> data-link="<?php echo e($url); ?>"><label for="f-1-1">Tất cả</label>
            </li>
            <?php if(!empty($filterContent->filter)): ?>
                <?php $__currentLoopData = $filterContent->filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $url_query_render = url_query_render('price', $value->min_value.'-'.$value->max_value );
                        $url = $url_query_render['url']  ;
                        $active = $url_query_render['active'] ? 'checked' : null ;
                    ?>
                    <li class="fillter">
                        <input type="radio" id="<?php echo e($key); ?>" name="filt-1" <?php echo e($active); ?> data-link="<?php echo e($url); ?>">
                        <label for="<?php echo e($key); ?>"><?php echo e($value->name); ?></label>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
    </div>
    <?php $colorFilter = \App\Models\Categories::where('type', 'color_attributes')->get(); ?>
    <?php if(!empty($colorFilter)): ?>
        <div class="box-filter">
            <div class="title-filt">Màu sắc</div>
            <ul class="filt-color">
                <?php $__currentLoopData = $colorFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <style>
                        #f-2-<?php echo e($loop->index); ?>:before {
                            background: <?php echo e($item->desc); ?>;
                        }
                    </style>
                    <li class="fillter">
                        <?php
                            $url_query_render = url_query_render('color', $item->id );
                            $url = $url_query_render['url']  ;
                            $active = $url_query_render['active'] ? 'checked' : null ;
                        ?>

                        <input type="radio" id="f-2-<?php echo e($loop->index); ?>" name="filt-2" <?php echo e($active); ?> data-link="<?php echo e($url); ?>">
                        <label for="f-2-<?php echo e($loop->index); ?>" id="f-2-<?php echo e($loop->index); ?>" class="lab-color"><?php echo e($item->name); ?></label>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php $fateFilter = \App\Models\Categories::where('type', 'fate_attributes')->get(); ?>
    <?php if(!empty($fateFilter)): ?>
        <div class="box-filter">
            <div class="title-filt">Theo mệnh</div>
            <ul>
                <?php $__currentLoopData = $fateFilter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $url_query_render = url_query_render('fate', $item->id );
                        $url = $url_query_render['url']  ;
                        $active = $url_query_render['active'] ? 'checked' : null ;
                    ?>
                    <li class="fillter">
                        <input type="radio" id="f-3-<?php echo e($loop->index); ?>" name="filt-3" <?php echo e($active); ?> data-link="<?php echo e($url); ?>">
                        <label for="f-3-<?php echo e($loop->index); ?>"><?php echo e($item->name); ?></label>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\vongtay\resources\views/frontend/pages/products/path/filter.blade.php ENDPATH**/ ?>