<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="<?php echo e($site_info->favicon); ?>">
	<?php if(isset($site_info->index_google)): ?>
		<meta name="robots" content="<?php echo e($site_info->index_google == 1 ? 'index, follow' : 'noindex, nofollow'); ?>">
	<?php else: ?>
		<meta name="robots" content="noindex, nofollow">
	<?php endif; ?>

	

	<?php echo SEOMeta::generate(); ?>

    <?php echo OpenGraph::generate(); ?>

    <?php echo Twitter::generate(); ?>



	<script type='application/ld+json'>{
    "@context":"http://schema.org",
    "@type":"WebSite",
    "@id":"#website",
    "url":"<?php echo e(url('/')); ?>",
    "name":"<?php echo e(@$site_info->site_title); ?>",
    "alternateName":"<?php echo e(@$site_info->site_title); ?>",
    "potentialAction":{"@type":"SearchAction",
    "target":"<?php echo e(url('tim-kiem')); ?>?search={search_term_string}",
    "query-input":"required name=search_term_string"}}</script>
    <script type='application/ld+json'>{"@context":"http://schema.org",
      "@type":"Organization",
      "url":"<?php echo e(url('/')); ?>",
      "sameAs":[],
      "@id":"#organization",
      "name":"<?php echo e(@$site_info->site_title); ?>",
      "logo":"<?php echo e(@$site_info->logo); ?>"}
    </script>

	<meta property="og:url" content="<?php echo e(url('/')); ?>" />
	<meta http-equiv="content-language" content="vi" />
	<meta name="geo.region" content="VN" />
    <meta name="geo.placename" content="Hà Nội" />
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
 	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
 	<link rel="canonical" href="<?php echo e(\Request::fullUrl()); ?>">
 	<!--link css-->
   
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/jquery.fancybox.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/slick.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/slick-theme.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/jquery.mmenu.all.css"> 
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/styles.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/cus.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(__BASE_URL__); ?>/css/responsive.css">
    <link rel="stylesheet" type="text/css" title="" href="<?php echo e(__BASE_URL__); ?>/plugin/jquery.toast.min.css">

    <script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/jquery.min.js"></script>
	<style>
		.list-category > ul ul{
			    left: 230px;
		}
	</style>
 	<?php if(!empty($site_info->google_analytics)): ?>
 		<?php echo $site_info->google_analytics; ?>

 	<?php endif; ?>

 	<script>
 		var base_url = "<?php echo e(__BASE_URL__); ?>";
 		var base = "<?php echo e(url('/')); ?>";
 	</script>
	
</head> 
	<body>
		<div class="loadingcover" style="display: none;">
		    <p class="csslder">
		        <span class="csswrap">
		            <span class="cssdot"></span>
		            <span class="cssdot"></span>
		            <span class="cssdot"></span>
		        </span>
		    </p>
		</div>

		<?php echo $__env->make('frontend.teamplate.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<main>
				<?php echo $__env->yieldContent('main'); ?>
			</main>
		<?php echo $__env->make('frontend.teamplate.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<!--Link js-->
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/jquery.fancybox.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/jquery.mmenu.all.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/slick.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/js/private.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/plugin/jquery.toast.min.js"></script>
		<script type="text/javascript" src="<?php echo e(__BASE_URL__); ?>/plugin/lazysizes.min.js"></script>

		<?php echo $__env->yieldContent('script'); ?>

		<?php if(!empty($site_info->script)): ?>
			<?php echo $site_info->script; ?>

		<?php endif; ?>



		<?php if(Session::has('toastr')): ?>
			<script>
				function showToast(text, heading){
				    $.toast({
				        text: text,
				        heading: heading,
				        icon: 'success',
				        showHideTransition: 'fade',
				        allowToastClose: false,
				        hideAfter: 3000,
				        stack: 5,
				        position: 'top-right',
				        textAlign: 'left', 
				        loader: true, 
				        loaderBg: '#9ec600',
				    });   
				}
				jQuery(document).ready(function($) {
					showToast('<?php echo e(Session::get('toastr')); ?>', 'Thông báo');
				});
			</script>
		<?php endif; ?>
	</body>
</html><?php /**PATH C:\xampp\htdocs\fashion\resources\views/frontend/master.blade.php ENDPATH**/ ?>