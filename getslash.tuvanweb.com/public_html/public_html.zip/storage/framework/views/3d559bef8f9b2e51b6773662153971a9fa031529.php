<?php $__env->startSection('main'); ?>
    <section class="blog-cate">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="list-blog">
                        <div class="item-blog title-detail">
                            <div class="avarta"><a href="">
                                <img src="<?php echo e($data->image); ?>" class="img-fluid" alt=""></a>
                            </div>
                            <div class="info">
                                <div class="date-time"><?php echo e($data->created_at->format('F jS, Y')); ?></div>
                                <h1><?php echo e($data->{ 'name_'.locale() }); ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="content-detai">
                        <div class="detail detail-recruit">
                            <h5><?php echo app('translator')->getFromJson('site.job_des'); ?></h5>
                            <?php echo $data->{ 'desc_'.locale() }; ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="side-bar">
                        <div class="list-bar">
                            <div class="item-bar">
                                <div class="title-bar"><?php echo app('translator')->getFromJson('site.overview'); ?></div>
                                <div class="info-recruit">
                                    <ul>
                                        <li>
                                            <label><?php echo app('translator')->getFromJson('site.income'); ?></label>
                                            <div class="desc" style="color: #FE5202"><?php echo e($data->{ 'offers_'.locale() }); ?></div>
                                        </li>
                                        <li>
                                            <label><?php echo app('translator')->getFromJson('site.quantity'); ?></label>
                                            <div class="desc"><?php echo e($data->qty); ?></div>
                                        </li>
                                        <li>
                                            <label><?php echo app('translator')->getFromJson('site.office_address'); ?></label>
                                            <div class="desc"><?php echo e($data->{ 'address_'.locale() }); ?></div>
                                        </li>
                                        <li>
                                            <label><?php echo app('translator')->getFromJson('site.deadline'); ?></label>
                                            <div class="desc"><?php echo e($data->deadline); ?></div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="item-bar">
                                <div class="title-bar"><?php echo app('translator')->getFromJson('site.related_posts'); ?></div>
                                <ul class="list-cate">
                                    <?php $__currentLoopData = $recruitmentOther ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('pages.recruitments.single', $item->slug)); ?>"><?php echo e($item->{ 'name_'.locale() }); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bestay\resources\views/frontend/pages/recruitments/single.blade.php ENDPATH**/ ?>