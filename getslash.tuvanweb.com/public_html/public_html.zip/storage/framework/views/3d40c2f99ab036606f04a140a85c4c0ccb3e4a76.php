<?php $__env->startSection('main'); ?>
	<section id="breadcrumbs">
		<div class="avarta">
			<?php if($dataSeo->banner): ?>
				<img src="<?php echo e($dataSeo->banner); ?>" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php else: ?>
				<img src="<?php echo e(__BASE_URL__); ?>/images/bread.png" class="img-fluid" width="100%" alt="<?php echo e($dataSeo->meta_title); ?>">
			<?php endif; ?>
		</div>
		<div class="info">
			<div class="container text-center">
				<h2 class="text-uppercase">Giới thiệu</h2>
				<ul class="list-inline">
					<li class="list-inline-item"><a title="Trang chủ" href="<?php echo e(url('/')); ?>">Trang chủ <span>/</span></a></li>
					<li class="list-inline-item"><a title="" href="javascript:0">Giới thiệu</a></li>
				</ul>
			</div>
		</div>
	</section>

	<?php if(!empty($dataSeo->content)){
		$content = json_decode($dataSeo->content);
	} ?>

	<section id="about">
		<div class="container">
			<div class="content">
				<div class="info-about pt-100 pb-100">
					<div class="row">
						<div class="col-md-7">
							<div class="avarta">
								<img src="<?php echo e(@$content->about->image); ?>" class="img-fluid" width="100%" alt="<?php echo e(@$content->about->title); ?>">
							</div>
						</div>
						<div class="col-md-5">
							<div class="right">
								<h1><?php echo e(@$content->about->title); ?></h1>
								<div class="info-right">
									<?php echo @$content->about->desc; ?>

								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="history" style="background: #fafafa" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="title-history text-uppercase"><h2 class="mont-semi blue"><?php echo e(@$content->history->title); ?></h2></div>
				<div class="info-hist">
					<div class="slide-tab">
						<ul class="tabs">
							<?php if(!empty(@$content->history->content)): ?>
								<?php $__currentLoopData = @$content->history->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<a title="" href="javascript:0" data-tab="tab-<?php echo e($loop->index + 1); ?>" 
											class="<?php echo e($loop->index == 0 ? 'active' : null); ?>">
											<span><?php echo e(@$value->title); ?></span>
											<span class="aft text-center">
												<span>Năm</span>
												<span class="sans-bold"><?php echo e(@$value->title); ?></span>
											</span>
										</a>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</ul>
					</div>
					<div class="tab-content-his">
						<?php if(!empty(@$content->history->content)): ?>
							<?php $__currentLoopData = @$content->history->content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="tab-content <?php echo e($loop->index == 0 ? 'active' : null); ?>" id="tab-<?php echo e($loop->index + 1); ?>">
									<div class="info">
										<?php echo @$value->content; ?>

									</div>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="tamnhin" class="pt-100 pb-100">
		<div class="container">
			<div class="content">
				<div class="lis-tamnhin">
					<div class="row">
						<div class="col-md-6 col-sm-6">
							<div class="item text-center">
								<h3><?php echo e(@$content->vision->title); ?></h3>
								<div class="desc">
									<?php echo @$content->vision->content; ?>

								</div>
							</div>
						</div>
						<div class="col-md-6 col-sm-6">
							<div class="item text-center">
								<h3><?php echo e(@$content->mission->title); ?></h3>
								<div class="desc">
									<?php echo @$content->mission->content; ?>

								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="item-giatri">
								<div class="content-gt">
									<div class="title text-center text-uppercase">
										<h2><?php echo e(@$content->core_values->title); ?></h2>
										<div class="line"></div>
									</div>
									<div class="desc text-center">
										<?php echo @$content->core_values->content; ?>

									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="box-service" class="pb-100">
		<div class="tab-content">
			<div class="tab-pane active" id="tabs-1" role="tabpanel">
				<div class="list-srv slide-srv">
					<?php if(!empty($projects)): ?>
						<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__env->startComponent('frontend.components.project-style-2', ['item' => $item]); ?> <?php echo $__env->renderComponent(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>

	<section id="box-contact">
		<div class="container">
			<div class="content">
				<div class="info-price text-center">
					<h2 class="text-uppercase">Liên hệ tư vấn và báo giá</h2>
					<div class="hotline">
						<a title="<?php echo e($site_info->hotline); ?>" href="tel: <?php echo e($site_info->hotline); ?>">
							GỌI NGAY: <?php echo e($site_info->hotline); ?>

						</a>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/pages/about.blade.php ENDPATH**/ ?>