<header>
    <div class="header-top">
        <div class="container">
            <div class="content">
                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="left">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a title="<?php echo e(@$site_info->hotline); ?>" href="tel: <?php echo e(@$site_info->hotline); ?>">
                                        <i class="fa fa-phone"></i><?php echo e(@$site_info->hotline); ?>

                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a title="<?php echo e(@$site_info->email); ?>" href="mailto: <?php echo e(@$site_info->email); ?>">
                                        <i class="fa fa-envelope"></i><?php echo e(@$site_info->email); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="social">
                            <ul class="list-inline text-right">
                                <?php if(!empty(@$site_info->social)): ?>
                                    <?php $__currentLoopData = @$site_info->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-inline-item">
                                            <a title="<?php echo e($value->name); ?>" href="<?php echo e($value->link); ?>" target="_blank">
                                                <i class="<?php echo e($value->icon); ?>"></i>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-menu">
        <div class="container">
            <div class="content">
                <div class="row">
                    <div class="col-md-3">
                        <div class="logo">
                            <a title="<?php echo e(@$site_info->site_title); ?>" href="<?php echo e(url('/')); ?>">
                                <img src="<?php echo e(@$site_info->logo); ?>" class="img-fluid" alt="<?php echo e(@$site_info->site_title); ?>">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <ul>
                            <?php if(!empty($menuHeader)): ?>
                                <?php $__currentLoopData = $menuHeader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($item->parent_id == null): ?>
                                        <li>
                                            <a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>" 
                                                class="<?php echo e($item->class); ?> <?php echo e(url($item->url) == url()->current() ? 'active' : null); ?>"><?php echo e($item->title); ?>

                                            </a>
                                            <?php if(count($item->get_child_cate())): ?>
                                                <div class="submenu">
                                                    <ul>
                                                        <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <a title="<?php echo e($value->title); ?>" href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="menu-mobile d-none">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-6 col-sm-6">
                    <div class="logo"> 
                        <a title="<?php echo e(@$site_info->site_title); ?>" href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(@$site_info->logo); ?>" class="img-fluid avarta-logo" alt="<?php echo e(@$site_info->site_title); ?>">
                        </a>
                    </div>
                </div>
                <div class="col-md-6 col-6 col-sm-6">
                    <div class="right text-right">
                        <div class="header">
                            <a title="" href="#menu"><i class="fa fa-bars"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav id="menu">
            <ul>
                 <?php if(!empty($menuHeader)): ?>
                    <?php $__currentLoopData = $menuHeader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->parent_id == null): ?>
                            <li>
                                <a title="<?php echo e($item->title); ?>" href="<?php echo e(url($item->url)); ?>" 
                                    class="<?php echo e($item->class); ?> <?php echo e(url($item->url) == url()->current() ? 'active' : null); ?>"><?php echo e($item->title); ?>

                                </a>
                                <?php if(count($item->get_child_cate())): ?>
                                    <ul>
                                        <?php $__currentLoopData = $item->get_child_cate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a title="<?php echo e($value->title); ?>" href="<?php echo e(url($value->url)); ?>"><?php echo e($value->title); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header><?php /**PATH C:\xampp\htdocs\bacviet\resources\views/frontend/teamplate/header.blade.php ENDPATH**/ ?>