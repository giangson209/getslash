<?php $__env->startSection('main'); ?>
	<main class="page-wrapper bg-white">
		<section class="news-detail pd-60">
			<div class="container">
				<div class="row">
					<div class="col-md-10 offset-md-1">
						<div class="news-article-top">
							<h1 class="title title-lg"><?php echo e($data->name); ?></h1>
							<div class="date"><?php echo e($data->created_at->format('d/m/Y')); ?></div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-1">
						<div class="share sticky-top">
							<div>Chia sẻ</div>
							<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>" target="_blank" title="" class="fa fa-facebook"></a>
							<a href="https://twitter.com/intent/tweet?url=<?php echo e(url()->current()); ?>" target="_blank" class="fa fa-twitter"></a>
						</div>
					</div>
					<div class="col-md-10">
						<div class="news-article-detail">
							<div class="desc"><?php echo $data->desc; ?></div>
							<article>
								<?php echo $data->content; ?>

							</article>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section class="news-related">
			<div class="container">
				<div class="related pd-30">
					<h2 class="title title-lg">Bài viết liên quan</h2>
					<div class="row">
						<?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-3">
								<div class="news-item">
									<a href="<?php echo e($item->url); ?>" title="" class="news-image zoom">
										<img src="<?php echo e($item->image); ?>" alt="">
									</a>
									<div class="news-cache">
										<h4><a href="<?php echo e($item->url); ?>" title=""><?php echo e($item->name); ?></a> </h4>
										<div class="desc"><?php echo e($item->desc); ?></div>
										<a href="<?php echo e($item->url); ?>" title="" class="text-blue font-oswald">Xem thêm</a>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\batdongsan\resources\views/frontend/pages/blog/single.blade.php ENDPATH**/ ?>