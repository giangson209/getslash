<?php $__env->startSection('title', __('404 - Không tìm thấy')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Không tìm thấy trang này.')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/demo03gvn/public_html/beta.gcosoftware.vn/bacviet/resources/views/errors/404.blade.php ENDPATH**/ ?>