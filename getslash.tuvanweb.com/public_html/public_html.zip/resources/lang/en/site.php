<?php
return [
    'about'                => 'About',
    'job_des'              => 'JOB DESCRIPTION',
    'related_posts'        => 'Related Posts',
    'overview'             => 'Overview',
    'income'               => 'Income',
    'quantity'             => 'Quantity',
    'office_address'       => 'Office Address',
    'deadline'             => 'Deadline',
    'view_more'            => 'View more',
    'contact'              => 'Contact',
    'get_more_detail'      => 'Get more detail',
    'phone'                => 'Phone',
    'address'              => 'Address',
    'name'                 => 'Name',
    'form_contact_title_1' => 'THANKs FOR CONTACTing',
    'form_contact_title_2' => 'We have received your request and will get back to you as soon as possible.',
    'categories'           => 'Categories',
    'explore_now'          => 'EXPLORE NOW',
    'partners'             => 'partners',
    'proud_cooperations'   => 'Proud cooperations',
    'trending_styles'      => 'Trending Styles',
    'for_your_space'       => 'For your space',
    'get_in_touch'         => 'get in touch'

];